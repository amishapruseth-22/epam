package com.epam.edp.demo.repository;

import com.epam.edai.run8.team17.dto.DishDTO;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.DishResponseDTO;
import com.epam.edai.run8.team17.exception.DishNotFoundException;
import com.epam.edai.run8.team17.model.Dish;
import com.epam.edai.run8.team17.repository.DishRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;

import java.util.List;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DishRepositoryTest {
}

