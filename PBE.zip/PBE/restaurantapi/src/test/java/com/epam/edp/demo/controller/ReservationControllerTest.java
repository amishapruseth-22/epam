package com.epam.edp.demo.controller;


import com.epam.edai.run8.team17.controller.ReservationController;
import com.epam.edai.run8.team17.dto.ReservationDto;
import com.epam.edai.run8.team17.dto.WaiterReservationDto;
import com.epam.edai.run8.team17.exception.reservationException.ForbiddenException;
import com.epam.edai.run8.team17.service.BookingService;
import com.epam.edai.run8.team17.service.TokenContextService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class ReservationControllerTest {

    @Mock
    private BookingService bookingService;

    @Mock
    private TokenContextService tokenContextService;

    @InjectMocks
    private ReservationController reservationController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void testGetUserReservations_Success() {
        // Mock data
        List<ReservationDto> reservations = Arrays.asList(
                new ReservationDto("RES-1", "Confirmed", "Street 140", "2023-10-01",
                        "12:00-14:00", "None", "4", "122", "John Doe", "4.7"),
                new ReservationDto("RES-2", "Pending", "Street 140", "2023-10-02",
                        "14:00-15:00", "None", "2", "124", "Jane Doe", "4.8")
        );

        // Mock dependencies
        when(tokenContextService.getEmailFromToken()).thenReturn("user@example.com");
        when(bookingService.getListReservationDto("user@example.com")).thenReturn(reservations);

        // Execute
        ResponseEntity<List<ReservationDto>> responseEntity = reservationController.getUserReservations();

        // Assertions
        assertNotNull(responseEntity.getBody());
        assertEquals(2, responseEntity.getBody().size());
        assertEquals("RES-1", responseEntity.getBody().get(0).getId());
        assertEquals("Confirmed", responseEntity.getBody().get(0).getStatus());
        assertEquals("RES-2", responseEntity.getBody().get(1).getId());
        assertEquals("Pending", responseEntity.getBody().get(1).getStatus());

        // Verify mocks
        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(bookingService, times(1)).getListReservationDto("user@example.com");
    }
    @Test
    void testUpdateReservation_Success() {
        String reservationId = "RES-1";
        Map<String, String> updateFields = Map.of(
                "date", "2023-10-03",
                "timeFrom", "13:00",
                "timeTo", "14:00"
        );
        ReservationDto updatedReservation = new ReservationDto(
                "RES-1", "Confirmed", "Street 140", "2023-10-03",
                "13:00-14:00", "None", "4", "122", "John Doe", "4.7"
        );

        // Mock dependencies
        when(tokenContextService.getEmailFromToken()).thenReturn("user@example.com");
        when(bookingService.updateBookingDateAndTimeWithId(reservationId, "user@example.com", updateFields, false))
                .thenReturn(updatedReservation);

        // Execute
        ResponseEntity<ReservationDto> responseEntity = reservationController.updateReservation(reservationId, updateFields);

        // Assertions
        assertNotNull(responseEntity.getBody());
        assertEquals("RES-1", responseEntity.getBody().getId());
        assertEquals("2023-10-03", responseEntity.getBody().getDate());
        assertEquals("Confirmed", responseEntity.getBody().getStatus());
        assertEquals("13:00-14:00", responseEntity.getBody().getTimeSlot());

        // Verify mocks
        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(bookingService, times(1)).updateBookingDateAndTimeWithId(reservationId, "user@example.com", updateFields, false);
    }

    @Test
    void testDeleteReservation_Success() {
        String reservationId = "RES-1";

        // Mock dependencies
        when(tokenContextService.getEmailFromToken()).thenReturn("user@example.com");

        // Execute
        ResponseEntity<Map<String, String>> responseEntity = reservationController.deleteReservation(reservationId);

        // Assertions
        assertNotNull(responseEntity.getBody());
        assertEquals("Reservation deleted successfully", responseEntity.getBody().get("message"));

        // Verify mocks
        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(bookingService, times(1)).deleteReservationWithId(reservationId, "user@example.com", false);
    }


    @Test
    void testDeleteReservationByWaiter_Success() {
        String waiterId = "RES-1";

        // Mock dependencies
        when(tokenContextService.getEmailFromToken()).thenReturn("waiter@example.com");
        when(tokenContextService.getRoleFromToken()).thenReturn("waiter");

        // Execute
        ResponseEntity<String> responseEntity = reservationController.deleteReservationByWaiter(waiterId);

        // Assertions
        assertNotNull(responseEntity.getBody());
        assertEquals("Reservation cancelled successfully", responseEntity.getBody());

        // Verify mocks
        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(tokenContextService, times(1)).getRoleFromToken();
        verify(bookingService, times(1)).deleteReservationWithId(waiterId, "waiter@example.com", true);
    }

    @Test
    void testDeleteReservationByWaiter_Forbidden() {
        String waiterId = "RES-1";

        // Mock dependencies
        when(tokenContextService.getRoleFromToken()).thenReturn("admin");

        // Assertions
        ForbiddenException exception = assertThrows(ForbiddenException.class, () -> {
            // Execute
            reservationController.deleteReservationByWaiter(waiterId);
        });
        assertEquals("Only waiters can perform this operation", exception.getMessage());

        // Verify mocks
        verify(tokenContextService, times(1)).getRoleFromToken();
        verify(bookingService, never()).deleteReservationWithId(anyString(), anyString(), anyBoolean());
    }


    @Test
    void testGetWaiterReservations_Success() {
        String email = "waiter@example.com";
        List<WaiterReservationDto> reservations = List.of(
                new WaiterReservationDto("Street 140", "T1", "2023-10-01", "12:00-14:00", "John Doe", "4", "RES-1", "Confirmed", "W1"),
                new WaiterReservationDto("Street 140", "T2", "2023-10-01", "14:00-15:00", "Jane Doe", "2", "RES-2", "Pending", "W1")
        );

        // Mock dependencies
        when(tokenContextService.getEmailFromToken()).thenReturn(email);
        when(bookingService.getWaiterReservation(email, "2023-10-01", null, null)).thenReturn(reservations);

        // Execute
        ResponseEntity<List<WaiterReservationDto>> responseEntity = reservationController.getWaiterReservations("2023-10-01", null, null);

        // Assertions
        assertNotNull(responseEntity.getBody());
        assertEquals(2, responseEntity.getBody().size());
        assertEquals("RES-1", responseEntity.getBody().get(0).getReservationId());
        assertEquals("RES-2", responseEntity.getBody().get(1).getReservationId());

        // Verify mocks
        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(bookingService, times(1)).getWaiterReservation(email, "2023-10-01", null, null);
    }
}