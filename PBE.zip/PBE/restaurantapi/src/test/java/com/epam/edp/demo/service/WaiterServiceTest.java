package com.epam.edp.demo.service;

import com.epam.edai.run8.team17.model.Waiter;
import com.epam.edai.run8.team17.repository.WaiterRepository;
import com.epam.edai.run8.team17.service.WaiterService;
import jakarta.validation.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import com.epam.edai.run8.team17.exception.NotFoundException;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Slf4j
class WaiterServiceTest {

    @Mock
    private WaiterRepository waiterRepository;

    @InjectMocks
    private WaiterService waiterService;

    private List<Waiter> createWaiterList() {
        Map<String, List<String>> bookings1 = new HashMap<>();
        bookings1.put("2023-10-01", List.of("11:00-12:00", "14:30-16:00"));
        bookings1.put("2023-10-02", List.of("10:00-12:00", "14:00-16:00"));

        Map<String, List<String>> bookings2 = new HashMap<>();
        bookings2.put("2023-10-01", List.of("15:00-16:00"));
        bookings2.put("2023-10-02", List.of("10:00-12:00", "14:00-16:00"));

        Waiter waiter1 = new Waiter();
        waiter1.setId("10");
        waiter1.setShiftStart("10:00");
        waiter1.setShiftEnd("22:00");
        waiter1.setLocationId("L001");
        waiter1.setActive(true);
        waiter1.setBooked(bookings1);

        Waiter waiter2 = new Waiter();
        waiter2.setId("20");
        waiter2.setShiftStart("10:00");
        waiter2.setShiftEnd("22:00");
        waiter2.setLocationId("L001");
        waiter2.setActive(true);
        waiter2.setBooked(bookings2);

         List<Waiter> list = new ArrayList<>();
         list.add(waiter1);
         list.add(waiter2);
        return list;
    }

    @Test
    void testGetLeastBusyWaiter_Success() {
        String locationId = "L001";
        String date = "2023-10-01";
        String timeFrom = "12:00";
        String timeTo = "13:00";

        // Mock the behavior of the waiterRepository
        List<Waiter> waiters = createWaiterList();

        waiters.forEach(waiter -> {
            log.info("Test Setup - Waiter ID: " + waiter.getId());
            log.info("Bookings: " + waiter.getBooked());
        });


        when(waiterRepository.getWaitersByLocation(locationId)).thenReturn(waiters);

        // Call the method under test
        String leastBusyWaiterId = waiterService.getLeastBusyWaiter(locationId, date, timeFrom, timeTo);

        log.info("Least Busy Waiter ID: " + leastBusyWaiterId);
        // Verify the result
        assertEquals("20", leastBusyWaiterId);
    }

    @Test
    void testGetLeastBusyWaiter_NoEligibleWaiter() {
        String locationId = "L001";
        String date = "2023-10-01";
        String timeFrom = "14:00";
        String timeTo = "16:00";

        // Mock the behavior of the waiterRepository
        List<Waiter> waiters = createWaiterList();
        when(waiterRepository.getWaitersByLocation(locationId)).thenReturn(waiters);

        // Call the method under test and expect an exception
        Exception exception = assertThrows(ValidationException.class, () -> {
            waiterService.getLeastBusyWaiter(locationId, date, timeFrom, timeTo);
        });

        // Verify the exception message
        assertEquals("No eligible waiters available for the selected time slot", exception.getMessage());
    }

    @Test
    void testGetLeastBusyWaiter_NoWaiters() {
        String locationId = "L001";
        String date = "2023-10-01";
        String timeFrom = "12:00";
        String timeTo = "14:00";

        // Mock the behavior of the waiterRepository
        when(waiterRepository.getWaitersByLocation(locationId)).thenReturn(List.of());

        // Call the method under test and expect an exception
        ValidationException exception = assertThrows(ValidationException.class, () -> {
            waiterService.getLeastBusyWaiter(locationId, date, timeFrom, timeTo);
        });

        // Verify the exception message
        assertEquals("No waiters available for the selected location", exception.getMessage());
    }

    @Test
    void testGetLeastBusyWaiter_InvalidParameters() {
        String locationId = null;
        String date = null;
        String timeFrom = null;
        String timeTo = null;

        // Call the method under test and expect an exception
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            waiterService.getLeastBusyWaiter(locationId, date, timeFrom, timeTo);
        });

        // Verify the exception message
        assertEquals("All parameters are required", exception.getMessage());
    }

    @Test
    void testUpdateTimeSlotForWaiter_Success() {
        String waiterId = "10";
        String locationId = "L001";
        String date = "2023-10-01";
        String timeSlot = "16:00-17:00";

        // Mock the behavior to indicate the waiter exists
        when(waiterRepository.doesWaiterExistWithIdAndLocationId(waiterId, locationId)).thenReturn(true);

        // Call the method under test
        waiterService.updateTimeSlotForWaiterWithIdAndLocationId(waiterId, locationId, date, timeSlot);

        // Verify the repository was called correctly
        verify(waiterRepository, times(1)).updateTimeSlotForWaiterWithId(waiterId, locationId, date, timeSlot);
    }

    @Test
    void testUpdateTimeSlotForWaiter_Failure() {
        String waiterId = "10";
        String locationId = "L001";
        String date = "2023-10-01";
        String timeSlot = "16:00-17:00";

        // Mock the behavior to indicate the waiter does not exist
        when(waiterRepository.doesWaiterExistWithIdAndLocationId(waiterId, locationId)).thenReturn(false);

        // Call the method under test and expect an exception
        Exception exception = assertThrows(NotFoundException.class, () -> {
            waiterService.updateTimeSlotForWaiterWithIdAndLocationId(waiterId, locationId, date, timeSlot);
        });

        // Verify the exception message
        assertEquals("Waiter not found", exception.getMessage());
    }

    @Test
    void testRemoveTimeSlot_Success() {
        String waiterId = "20";
        String locationId = "L001";
        String date = "2023-10-01";
        String timeSlot = "14:00-15:00";

        // Call the method under test
        waiterService.removeTimeSlot(waiterId, locationId, date, timeSlot);

        // Verify that the repository method was called
        verify(waiterRepository, times(1)).removeTimeSlotFromWaiter(waiterId, locationId, date, timeSlot);
    }

    @Test
    void testDoesWaiterExistWithIdAndLocationId_Success() {
        String waiterId = "20";
        String locationId = "L001";

        // Mock the behavior to indicate the waiter exists
        when(waiterRepository.doesWaiterExistWithIdAndLocationId(waiterId, locationId)).thenReturn(true);

        // Call the method under test
        boolean exists = waiterService.doesWaiterExistWithIdAndLocationId(waiterId, locationId);

        // Verify the result
        assertTrue(exists);

        // Verify the repository was called correctly
        verify(waiterRepository, times(1)).doesWaiterExistWithIdAndLocationId(waiterId, locationId);
    }
}