package com.epam.edp.demo.controller;

import com.epam.edai.run8.team17.controller.BookingController;
import com.epam.edai.run8.team17.dto.*;
import com.epam.edai.run8.team17.model.TimeSlot;
import com.epam.edai.run8.team17.service.BookingService;
import com.epam.edai.run8.team17.service.ReservationService;
import com.epam.edai.run8.team17.service.TableService;
import com.epam.edai.run8.team17.service.TokenContextService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class BookingControllerTest {

    @Mock
    private BookingService bookingService;

    @Mock
    private ReservationService reservationService;

    @Mock
    private TableService tableService;

    @Mock
    private TokenContextService tokenContextService;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private BookingController bookingController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    @Test
    void testCreateBooking_Success() {
        BookingRequestDto bookingRequestDto = new BookingRequestDto();
        bookingRequestDto.setLocationId("L001");
        bookingRequestDto.setTableId("T001");
        bookingRequestDto.setDate("2023-10-01");
        bookingRequestDto.setTimeFrom("18:00");
        bookingRequestDto.setTimeTo("20:00");
        bookingRequestDto.setGuestsNumber("4");

        ReservationDto reservationDto =
                new ReservationDto("RES-1", "Confirmed", "Street 140", "2023-10-01", "18:00-20:00", "none", "4", "fb123", "John Doe", "4.5");

        ReservationDtoWithTableId expectedReservation = new ReservationDtoWithTableId("RES-1", "Confirmed", "Street 140", "2023-10-01", "18:00-20:00", "none", "4", "fb123", "T001", "John Doe", "4.5");

        // Mock the required behavior
        when(tokenContextService.getEmailFromToken()).thenReturn("johndoe@email.com");
        when(bookingService.createReservation(any(BookingRequestDto.class), anyString())).thenReturn(reservationDto);
        when(objectMapper.convertValue(reservationDto, ReservationDtoWithTableId.class)).thenReturn(expectedReservation);

        // Execute the API call
        ResponseEntity<ReservationDtoWithTableId> response = bookingController.createBooking(bookingRequestDto);

        // Assertions
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("RES-1", response.getBody().getId());
        assertEquals("T001", response.getBody().getTableId());

        // Verify method interactions
        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(bookingService, times(1)).createReservation(any(BookingRequestDto.class), anyString());
    }

    @Test
    void testCreateBooking_Failure() {
        BookingRequestDto bookingRequestDto = new BookingRequestDto();
        bookingRequestDto.setLocationId("L001");
        bookingRequestDto.setTableId("T001");
        bookingRequestDto.setDate("2023-10-01");
        bookingRequestDto.setTimeFrom("18:00");
        bookingRequestDto.setTimeTo("20:00");
        bookingRequestDto.setGuestsNumber("4");

        // Simulate service throwing an exception
        when(tokenContextService.getEmailFromToken()).thenReturn("user@example.com");
        when(bookingService.createReservation(any(BookingRequestDto.class), anyString())).thenThrow(new RuntimeException("Booking failed"));

        // API call
        Exception exception = assertThrows(RuntimeException.class, () -> bookingController.createBooking(bookingRequestDto));

        // Assertions
        assertEquals("Booking failed", exception.getMessage());
        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(bookingService, times(1)).createReservation(any(BookingRequestDto.class), anyString());
    }

    @Test
    void testCreateBookingByWaiter_Success() {
        WaiterBookingDTO waiterBookingDTO = new WaiterBookingDTO();
        waiterBookingDTO.setClientType("customer");
        waiterBookingDTO.setClientEmail("customer@example.com");

        ReservationByWaiterDTO reservation = new ReservationByWaiterDTO("2023-10-01", "fb123", "4", "RES-1", "Street 140", "Confirmed", "T001", "T001", "12:00-14:00", "Blake");

        // Mock the dependencies
        when(tokenContextService.getEmailFromToken()).thenReturn("waiter@example.com");
        when(tokenContextService.getRoleFromToken()).thenReturn("waiter");
        when(reservationService.bookTable(anyString(), any(WaiterBookingDTO.class), anyString())).thenReturn(reservation);

        // API invokation
        ResponseEntity<ReservationByWaiterDTO> response = bookingController.createBookingByWaiter(waiterBookingDTO, "Bearer token");

        // Assertions
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("RES-1", response.getBody().getId());

        verify(tokenContextService, times(1)).getEmailFromToken();
        verify(tokenContextService, times(1)).getRoleFromToken();
        verify(reservationService, times(1)).bookTable(anyString(), any(WaiterBookingDTO.class), anyString());
    }

    @Test
    void testGetAvailableTables_Success() {
        // Arrange
        String locationId = "L001";
        String date = "2023-10-01";
        String timeSlot = "18:00-20:00";
        int guests = 4;


        // Mocking parsed time slots and available tables
        TimeSlot parsedTimeSlot = new TimeSlot("18:00", "20:00");
        List<String> availableSlots = new ArrayList<>();
        availableSlots.add("18:00-19:00");
        availableSlots.add("19:00-20:00");

        TableAvailableDTO table1 = new TableAvailableDTO("L001", "Street 140", "T001", 4, availableSlots, "https://example.com/images/table1.jpg");
        TableAvailableDTO table2 = new TableAvailableDTO("L001", "Street 140", "T002", 2, availableSlots, "https://example.com/images/table2.jpg");

        List<TableAvailableDTO> availableTables = new ArrayList<>();
        availableTables.add(table1);
        availableTables.add(table2);


        // Mock the required service calls
        when(tableService.parseTimeSlot(timeSlot)).thenReturn(parsedTimeSlot);
        when(tableService.getAvailableTables(locationId, date, parsedTimeSlot, guests)).thenReturn(availableTables);

        // Execute the API call
        ResponseEntity<Map<String, List<TableAvailableDTO>>> response = bookingController.getAvailableTables(locationId, date, timeSlot, guests);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().containsKey("tables"));
        assertEquals(2, response.getBody().get("tables").size());
        assertEquals("T001", response.getBody().get("tables").get(0).getTableNumber());
        assertEquals("T002", response.getBody().get("tables").get(1).getTableNumber());

        // Verify service calls
        verify(tableService, times(1)).parseTimeSlot(timeSlot);
        verify(tableService, times(1)).getAvailableTables(locationId, date, parsedTimeSlot, guests);
    }
}