package com.epam.edp.demo.controller;

import com.epam.edai.run8.team17.controller.DishController;
import com.epam.edai.run8.team17.dto.DishDTO;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.DishResponseDTO;
import com.epam.edai.run8.team17.service.DishService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;
import org.springframework.http.ResponseEntity;

class DishControllerTest {

    @Mock
    private DishService dishService;

    @InjectMocks
    private DishController dishController;

    @BeforeEach
    void setUp() {
        openMocks(this); // Initialize @Mock and @InjectMocks
    }

    @Test
    void testGetAllPopularDishesReturnsList() {
        List<DishInfoDTO> mockPopular = List.of(
                DishInfoDTO.builder().name("Pizza").imageUrl("img.jpg").build()
        );

        when(dishService.getListOfAllPopularDishes()).thenReturn(mockPopular);

        ResponseEntity<Map<String, List<DishInfoDTO>>> response = dishController.getAllPopularDishes();

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).containsKey("dishes");
        assertThat(response.getBody().get("dishes")).isEqualTo(mockPopular);
    }

    @Test
    void testGetDishesReturnsList() {
        List<DishResponseDTO> mockList = List.of(
                DishResponseDTO.builder()
                        .id("1")
                        .name("Pizza")
                        .imageUrl("img.jpg")
                        .price("10")
                        .weight("500g")
                        .state("Available")
                        .build()
        );

        when(dishService.getListOfAllDishes("Main", "price,asc")).thenReturn(mockList);

        ResponseEntity<Map<String, List<DishResponseDTO>>> response =
                dishController.getDishes("Main", "price,asc");

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).containsKey("dishes");
        assertThat(response.getBody().get("dishes")).isEqualTo(mockList);
    }

    @Test
    void testGetDishByIdReturnsDish() {
        DishDTO mockDish = DishDTO.builder()
                .id("1")
                .name("Pizza")
                .price("10")
                .weight("500g")
                .imageUrl("img.jpg")
                .description("Tasty")
                .dishType("Main")
                .carbohydrates("30")
                .fats("10")
                .proteins("12")
                .vitamins("A,C")
                .state("Available")
                .calories("250")
                .build();

        when(dishService.getDishById("1")).thenReturn(mockDish);

        ResponseEntity<DishDTO> response = dishController.getDishById("1");

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody()).isEqualTo(mockDish);
    }
}
