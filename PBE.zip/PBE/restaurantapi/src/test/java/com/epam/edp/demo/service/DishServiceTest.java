package com.epam.edp.demo.service;

import com.epam.edai.run8.team17.dto.*;
import com.epam.edai.run8.team17.exception.DishNotFoundException;
import com.epam.edai.run8.team17.model.Dish;
import com.epam.edai.run8.team17.repository.DishRepository;
import com.epam.edai.run8.team17.service.DishService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DishServiceTest {

    @Mock
    private DishRepository dishRepository;

    @InjectMocks
    private DishService dishService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetDishesByIdFoundAndAvailable() {
        Dish dish = new Dish();
        dish.setId("1");
        dish.setAvailable(true);
        dish.setName("Pizza");
        dish.setPrice("10");
        dish.setWeight("200");
        dish.setImage("url");
        dish.setDescription("desc");
        dish.setCalories("300");
        dish.setCarbs("30");
        dish.setDishType("Main");
        dish.setFats("10");
        dish.setProteins("15");
        dish.setState("Available");
        dish.setVitamins("A,B");

        when(dishRepository.findById("1")).thenReturn(dish);

        DishDTO result = dishService.getDishesById("1");

        assertEquals("1", result.getId());
        assertEquals("Pizza", result.getName());
    }

    @Test
    void testGetDishesByIdNotFound() {
        when(dishRepository.findById("999")).thenReturn(null);
        assertThrows(DishNotFoundException.class, () -> dishService.getDishesById("999"));
    }

    @Test
    void testGetDishCategorizedByTypeFilterMatch() {
        Dish dish1 = new Dish();
        dish1.setDishType("Main");
        dish1.setAvailable(true);

        Dish dish2 = new Dish();
        dish2.setDishType("Dessert");
        dish2.setAvailable(true);

        when(dishRepository.findAll()).thenReturn(List.of(dish1, dish2));

        List<Dish> result = dishService.getDishCategorizedByType("Main");
        assertEquals(1, result.size());
        assertEquals("Main", result.get(0).getDishType());
    }

//    @Test
//    void testSortDishesByPriceAsc() {
//        Dish dish1 = new Dish();
//        dish1.setId("1");
//        dish1.setName("Pizza");
//        dish1.setAvailable(true);
//        dish1.setPrice("5");
//
//        Dish dish2 = new Dish();
//        dish2.setId("2");
//        dish2.setName("Burger");
//        dish2.setAvailable(true);
//        dish2.setPrice("10");
//
//        when(dishRepository.findAll()).thenReturn(List.of(dish2, dish1));
//
//        List<DishSmallDTO> result = dishService.sortDishes("price,asc");
//        assertEquals("1", result.get(0).getId());
//    }
//
//    @Test
//    void testSortDishesByPopularity() {
//        Dish dish1 = new Dish();
//        dish1.setId("1");
//        dish1.setName("Pizza");
//        dish1.setAvailable(true);
//        dish1.setIsPopular(true);
//        dish1.setPopularityScore("90");
//
//        Dish dish2 = new Dish();
//        dish2.setId("2");
//        dish2.setName("Burger");
//        dish2.setAvailable(true);
//        dish2.setIsPopular(false);
//        dish2.setPopularityScore("50");
//
//        when(dishRepository.findAll()).thenReturn(List.of(dish2, dish1));
//
//        List<DishSmallDTO> result = dishService.sortDishes("popularity,desc");
//        assertEquals("2", result.get(0).getId());
//    }

    @Test
    void testSortDishesWithInvalidSortString() {
        Dish dish = new Dish();
        dish.setId("1");
        dish.setName("Pizza");
        dish.setAvailable(true);
        dish.setPrice("10");

        when(dishRepository.findAll()).thenReturn(List.of(dish));

        List<DishSmallDTO> result = dishService.sortDishes("invalid");
        assertEquals(1, result.size());
    }

    @Test
    void testGetListOfAllDishes() {
        DishResponseDTO mockResponse = DishResponseDTO.builder().build(); // Assume it has setters/getters
        when(dishRepository.getListOfAllDishes("Main", "price,asc"))
                .thenReturn(List.of(mockResponse));

        List<DishResponseDTO> result = dishService.getListOfAllDishes("Main", "price,asc");
        assertEquals(1, result.size());
    }

    @Test
    void testGetAllDishes() {
        Dish dish = new Dish();
        dish.setId("1");
        dish.setName("Pizza");
        dish.setAvailable(true);
        dish.setPrice("10");

        when(dishRepository.findAll()).thenReturn(List.of(dish));

        List<DishSmallDTO> result = dishService.getAllDishes();
        assertEquals("1", result.get(0).getId());
    }

    @Test
    void testGetListOfAllPopularDishes() {
        DishInfoDTO dto = new DishInfoDTO();
        when(dishRepository.getPopularDishes()).thenReturn(List.of(dto));

        List<DishInfoDTO> result = dishService.getListOfAllPopularDishes();
        assertEquals(1, result.size());
    }

    @Test
    void testGetDishById() {
        DishDTO dto = DishDTO.builder().id("123").name("Test Dish").build();
        when(dishRepository.getDishDtoById("123")).thenReturn(dto);

        DishDTO result = dishService.getDishById("123");
        assertEquals("123", result.getId());
    }

    @Test
    void testGetDishCategorizedByTypeNoMatch() {
        Dish dish1 = new Dish();
        dish1.setDishType("Main");
        dish1.setAvailable(true);

        when(dishRepository.findAll()).thenReturn(List.of(dish1));

        List<Dish> result = dishService.getDishCategorizedByType("Dessert");
        assertEquals(1, result.size()); // fallback to all dishes
    }

    @Test
    void testSortDishesNullSort() {
        Dish dish = new Dish();
        dish.setId("1");
        dish.setName("Pizza");
        dish.setAvailable(true);
        dish.setPrice("10");

        when(dishRepository.findAll()).thenReturn(List.of(dish));

        List<DishSmallDTO> result = dishService.sortDishes(null);
        assertEquals(1, result.size());
    }

//    @Test
//    void testSortDishesByPopularityAsc() {
//        Dish dish1 = new Dish();
//        dish1.setId("1");
//        dish1.setName("Pizza");
//        dish1.setAvailable(true);
//        dish1.setIsPopular(true);
//        dish1.setPopularityScore("90");
//
//        Dish dish2 = new Dish();
//        dish2.setId("2");
//        dish2.setName("Burger");
//        dish2.setAvailable(true);
//        dish2.setIsPopular(false);
//        dish2.setPopularityScore("50");
//
//        when(dishRepository.findAll()).thenReturn(List.of(dish1, dish2));
//
//        List<DishSmallDTO> result = dishService.sortDishes("popularity,asc");
//        assertEquals("2", result.get(0).getId()); // less popular comes first
//    }
}
