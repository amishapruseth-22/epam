package com.epam.edp.demo.controller;


import com.amazonaws.services.kms.model.NotFoundException;
import com.epam.edai.run8.team17.controller.LocationController;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.FeedbackDTO;
import com.epam.edai.run8.team17.dto.LocationSmallDTO;
import com.epam.edai.run8.team17.dto.PaginatedResponse;
import com.epam.edai.run8.team17.model.Location;
import com.epam.edai.run8.team17.service.FeedbackService;
import com.epam.edai.run8.team17.service.LocationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LocationControllerTest {

    @Mock
    private LocationService locationService;

    @Mock
    private FeedbackService feedbackService;

    @InjectMocks
    private LocationController locationController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    @Test
    void testGetAllAvailableLocations_Success() {
        // Arrange
        List<Location> locations = List.of(new Location("1", "Location A", "Address A", "Description A",
                "100", "50", "urlA", "5", "Special Dish"));
        when(locationService.getAllLocationsList()).thenReturn(locations);

        // Act
        ResponseEntity<Map<String, List<Location>>> response = locationController.getAllAvailableLocations();

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().containsKey("locations"));
        assertEquals(1, response.getBody().get("locations").size());
        verify(locationService, times(1)).getAllLocationsList();
    }

    @Test
    void testGetAllAvailableLocations_NotFound() {
        // Arrange
        when(locationService.getAllLocationsList()).thenReturn(new ArrayList<>());

        // Act & Assert
        NotFoundException exception = assertThrows(NotFoundException.class, () ->
                locationController.getAllAvailableLocations()
        );

        assertTrue(exception.getMessage().contains("No locations available at the moment."));
        verify(locationService, times(1)).getAllLocationsList();
    }

    @Test
    void testGetSpecialityDishes_Success() {
        // Arrange
        String locationId = "loc1";
        DishInfoDTO dishInfo = DishInfoDTO.builder()
                .name("Dish 1")
                .price("20 USD")
                .weight("500 grams")
                .imageUrl("https://example.com/image1.jpg")
                .build();
        when(locationService.getSpecialityDishesByLocationId(locationId)).thenReturn(dishInfo);

        // Act
        ResponseEntity<Map<String, DishInfoDTO>> response = locationController.getSpecialityDishes(locationId);

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().containsKey("specialityDishes"));
        DishInfoDTO responseDish = response.getBody().get("specialityDishes");
        assertEquals("Dish 1", responseDish.getName());
        assertEquals("20 USD", responseDish.getPrice());
        assertEquals("500 grams", responseDish.getWeight());
        assertEquals("https://example.com/image1.jpg", responseDish.getImageUrl());
        verify(locationService, times(1)).getSpecialityDishesByLocationId(locationId);
    }

    @Test
    void testGetSpecialityDishes_NotFound() {
        // Arrange
        String locationId = "loc1";
        when(locationService.getSpecialityDishesByLocationId(locationId)).thenReturn(null);

        // Act & Assert
        NotFoundException exception = assertThrows(NotFoundException.class, () ->
                locationController.getSpecialityDishes(locationId)
        );

        assertTrue(exception.getMessage().contains("No speciality dishes found for location ID: loc1"));
        verify(locationService, times(1)).getSpecialityDishesByLocationId(locationId);
    }

    @Test
    void testGetLocationsForSelectOptions_Success() {
        // Arrange
        List<LocationSmallDTO> locations = List.of(new LocationSmallDTO("1", "Address 1"));
        when(locationService.getAllLocations()).thenReturn(locations);

        // Act
        ResponseEntity<Map<String, List<LocationSmallDTO>>> response = locationController.getLocationsForSelectOptions();

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().containsKey("locations"));
        assertEquals(1, response.getBody().get("locations").size());
        verify(locationService, times(1)).getAllLocations();
    }

    @Test
    void testGetLocationsForSelectOptions_NotFound() {
        // Arrange
        when(locationService.getAllLocations()).thenReturn(new ArrayList<>());

        // Act & Assert
        NotFoundException exception = assertThrows(NotFoundException.class, () ->
                locationController.getLocationsForSelectOptions()
        );

        assertTrue(exception.getMessage().contains("No locations available to display as select options."));
        verify(locationService, times(1)).getAllLocations();
    }

    @Test
    void testGetFeedbacksForLocation_Success() {
        // Arrange
        String locationId = "loc1";

        // Create a list of FeedbackDTO using the builder pattern for clarity
        List<FeedbackDTO> feedbacks = List.of(
                FeedbackDTO.builder()
                        .id("1")
                        .rate("5")
                        .comment("Good feedback")
                        .userName("User A")
                        .date("2023-10-15")
                        .type("Positive")
                        .locationId(locationId)
                        .userAvatarUrl("https://example.com/avatar.jpg")
                        .build());

        // Create a PaginatedResponse mock and set values for testing
        PaginatedResponse<FeedbackDTO> feedbackPage = new PaginatedResponse<>();
        feedbackPage.setContent(feedbacks);  // Correctly set the list of feedbacks
        feedbackPage.setTotalPages(1);
        feedbackPage.setTotalElements(feedbacks.size());
        feedbackPage.setSize(10);
        feedbackPage.setNumber(0);
        feedbackPage.setFirst(true);
        feedbackPage.setLast(true);
        feedbackPage.setNumberOfElements(feedbacks.size());
        feedbackPage.setEmpty(false);

        // Mock service behavior
        when(locationService.doesLocationExist(locationId)).thenReturn(false); // Location exists
        when(feedbackService.getFeedbackByLocationWithPagination(locationId, 10, 0, null, "asc"))
                .thenReturn(feedbackPage);

        // Act
        ResponseEntity<PaginatedResponse<FeedbackDTO>> response =
                locationController.getFeedbacksForLocation(locationId, 0, 10, null, "asc");

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getContent().size());
        FeedbackDTO feedbackDTO = response.getBody().getContent().get(0);
        assertEquals("1", feedbackDTO.getId());
        assertEquals("5", feedbackDTO.getRate());
        assertEquals("Good feedback", feedbackDTO.getComment());
        assertEquals("User A", feedbackDTO.getUserName());
        assertEquals("https://example.com/avatar.jpg", feedbackDTO.getUserAvatarUrl());
        verify(locationService, times(1)).doesLocationExist(locationId);
        verify(feedbackService, times(1)).getFeedbackByLocationWithPagination(locationId, 10, 0, null, "asc");
    }

    @Test
    void testGetFeedbacksForLocation_NotFound() {
        // Arrange
        String locationId = "loc1";
        when(locationService.doesLocationExist(locationId)).thenReturn(true); // Location does not exist

        // Act & Assert
        NotFoundException exception = assertThrows(NotFoundException.class, () ->
                locationController.getFeedbacksForLocation(locationId, 0, 10, null, "asc")
        );

        assertTrue(exception.getMessage().contains("Invalid Location"));
        verify(locationService, times(1)).doesLocationExist(locationId);
        verify(feedbackService, never()).getFeedbackByLocationWithPagination(anyString(), anyInt(), anyInt(), any(), anyString());
    }
}