package com.epam.edp.demo.service;


import com.amazonaws.services.kms.model.NotFoundException;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.DishSmallDTO;
import com.epam.edai.run8.team17.dto.LocationSmallDTO;
import com.epam.edai.run8.team17.model.Location;
import com.epam.edai.run8.team17.repository.LocationRepository;
import com.epam.edai.run8.team17.service.DishService;
import com.epam.edai.run8.team17.service.LocationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LocationServiceTest {

    @Mock
    private DishService dishService;

    @Mock
    private LocationRepository locationRepository;

    @InjectMocks
    private LocationService locationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllLocations_Success() {
        Location location1 = new Location();
        location1.setId("LOC-1");
        location1.setAddress("123 Main Street");

        Location location2 = new Location();
        location2.setId("LOC-2");
        location2.setAddress("456 Elm Street");

        when(locationRepository.getAllLocationsList()).thenReturn(List.of(location1, location2));

        List<LocationSmallDTO> result = locationService.getAllLocations();

        assertEquals(2, result.size());
        assertEquals("LOC-1", result.get(0).getId());
        assertEquals("123 Main Street", result.get(0).getAddress());
        assertEquals("LOC-2", result.get(1).getId());
        assertEquals("456 Elm Street", result.get(1).getAddress());

        verify(locationRepository, times(1)).getAllLocationsList();
    }

    @Test
    void testGetLocationById_Success() {
        Location location = new Location();
        location.setId("LOC-1");
        location.setAddress("123 Main Street");

        when(locationRepository.getLocationDataById("LOC-1")).thenReturn(Optional.of(location));

        Location result = locationService.getLocationById("LOC-1");

        assertNotNull(result);
        assertEquals("LOC-1", result.getId());
        assertEquals("123 Main Street", result.getAddress());

        verify(locationRepository, times(1)).getLocationDataById("LOC-1");
    }

    @Test
    void testGetLocationById_NotFound() {
        when(locationRepository.getLocationDataById("LOC-1")).thenReturn(Optional.empty());

        NotFoundException exception = assertThrows(NotFoundException.class, () -> locationService.getLocationById("LOC-1"));
        assertTrue(exception.getMessage().contains("Location with id: LOC-1 does not exist"));

        verify(locationRepository, times(1)).getLocationDataById("LOC-1");
    }

    @Test
    void testGetLocationAddressByLocationId_Success() {
        Location location = new Location();
        location.setId("LOC-1");
        location.setAddress("123 Main Street");

        when(locationRepository.getLocationDataById("LOC-1")).thenReturn(Optional.of(location));

        String address = locationService.getLocationAddressByLocationId("LOC-1");

        assertEquals("123 Main Street", address);
        verify(locationRepository, times(1)).getLocationDataById("LOC-1");
    }

    @Test
    void testGetLocationAddressByLocationId_NotFound() {
        when(locationRepository.getLocationDataById("LOC-1")).thenReturn(Optional.empty());

        NotFoundException exception = assertThrows(NotFoundException.class, () -> locationService.getLocationAddressByLocationId("LOC-1"));
        assertTrue(exception.getMessage().contains("Location with id: LOC-1 does not exist"));

        verify(locationRepository, times(1)).getLocationDataById("LOC-1");
    }

    @Test
    void testGetSpecialityDishesByLocationId_Success() {
        Location location = new Location();
        location.setId("LOC-1");
        location.setSpecialityDishes("Burger");

        DishSmallDTO dish = DishSmallDTO.builder()
                .name("Burger")
                .price("10.0")
                .weight("200")
                .imageUrl("https://example.com/burger.jpg")
                .build();

        when(locationRepository.getAllLocationsList()).thenReturn(List.of(location));
        when(dishService.getAllDishes()).thenReturn(List.of(dish));

        DishInfoDTO result = locationService.getSpecialityDishesByLocationId("LOC-1");

        assertNotNull(result);
        assertEquals("Burger", result.getName());
        assertEquals("10.0", result.getPrice());
        assertEquals("200", result.getWeight());
        assertEquals("https://example.com/burger.jpg", result.getImageUrl());

        verify(locationRepository, times(1)).getAllLocationsList();
        verify(dishService, times(1)).getAllDishes();
    }

    @Test
    void testGetSpecialityDishesByLocationId_LocationNotFound() {
        when(locationRepository.getAllLocationsList()).thenReturn(List.of());

        NotFoundException exception = assertThrows(NotFoundException.class, () -> locationService.getSpecialityDishesByLocationId("LOC-1"));
        assertTrue(exception.getMessage().contains("Location with id: LOC-1 does not exist"));

        verify(locationRepository, times(1)).getAllLocationsList();
    }

    @Test
    void testGetSpecialityDishesByLocationId_DishNotFound() {
        Location location = new Location();
        location.setId("LOC-1");
        location.setSpecialityDishes("Pizza");

        when(locationRepository.getAllLocationsList()).thenReturn(List.of(location));
        when(dishService.getAllDishes()).thenReturn(List.of());

        NotFoundException exception = assertThrows(NotFoundException.class, () -> locationService.getSpecialityDishesByLocationId("LOC-1"));
        assertTrue(exception.getMessage().contains("Dish with name: Pizza does not exist"));

        verify(locationRepository, times(1)).getAllLocationsList();
        verify(dishService, times(1)).getAllDishes();
    }

    @Test
    void testGetLocationAddressById_Success() {
        when(locationRepository.getLocationAddress("LOC-1")).thenReturn("123 Main Street");

        String address = locationService.getLocationAddressById("LOC-1");

        assertEquals("123 Main Street", address);
        verify(locationRepository, times(1)).getLocationAddress("LOC-1");
    }

    @Test
    void testGetLocationAddressById_NotFound() {
        when(locationRepository.getLocationAddress("LOC-1")).thenReturn(null);

        NotFoundException exception = assertThrows(NotFoundException.class, () -> locationService.getLocationAddressById("LOC-1"));
        assertTrue(exception.getMessage().contains("Location with id: LOC-1 does not exist"));

        verify(locationRepository, times(1)).getLocationAddress("LOC-1");
    }

    @Test
    void testDoesLocationExist_Success() {
        when(locationRepository.getLocationById("LOC-1")).thenReturn(new Location());

        boolean exists = locationService.doesLocationExist("LOC-1");

        assertTrue(exists);
        verify(locationRepository, times(1)).getLocationById("LOC-1");
    }

    @Test
    void testDoesLocationExist_InvalidId() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> locationService.doesLocationExist(null));
        assertEquals("Location ID cannot be null", exception.getMessage());

        verify(locationRepository, never()).getLocationById(anyString());
    }
}