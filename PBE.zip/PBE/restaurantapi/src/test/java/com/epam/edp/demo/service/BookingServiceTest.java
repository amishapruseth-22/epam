package com.epam.edp.demo.service;


import com.epam.edai.run8.team17.dto.BookingRequestDto;
import com.epam.edai.run8.team17.dto.ReservationDto;
import com.epam.edai.run8.team17.dto.WaiterBookingDTO;
import com.epam.edai.run8.team17.dto.WaiterReservationDto;
import com.epam.edai.run8.team17.exception.NotFoundException;
import com.epam.edai.run8.team17.exception.reservationException.UnauthorizedException;
import com.epam.edai.run8.team17.model.Booking;
import com.epam.edai.run8.team17.repository.BookingRepository;
import com.epam.edai.run8.team17.repository.EmployeeRepository;
import com.epam.edai.run8.team17.service.*;
import jakarta.validation.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceTest {
    @Mock
    private BookingRepository bookingRepository;
    @Mock
    private TableService tableService;
    @Mock
    private LocationService locationService;
    @Mock
    private WaiterService waiterService;
    @Mock
    private EmployeeRepository employeeRepository;
    @Mock
    private UserService userService;

    @InjectMocks
    private BookingService bookingService;

    private Booking testBooking;
    private String futureDate;
    private String futureTimeFrom;
    private String futureTimeTo;

    @BeforeEach
    void setUp() {
        // Setup dates
        futureDate = LocalDate.now().plusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE);
        futureTimeFrom = LocalTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("HH:mm"));
        futureTimeTo = LocalTime.now().plusHours(3).format(DateTimeFormatter.ofPattern("HH:mm"));

        // Create test booking
        testBooking = createTestBooking();
    }

    @Test
    void testUpdateBookingTableWithId() {
        // Given
        String bookingId = "res123";
        String newTableId = "newTable";
        String newLocationId = "newLoc";

        // Mock only what's needed for this specific test
        when(bookingRepository.doesBookingExist(bookingId)).thenReturn(true);
        when(bookingRepository.getBookingById(bookingId)).thenReturn(testBooking);
        when(locationService.doesLocationExist(newLocationId)).thenReturn(false);
        when(tableService.doesTableExistsWithIdAndLocationId(newTableId, newLocationId)).thenReturn(true);
        when(tableService.isTableAvailableForBooking(eq(newTableId), eq(newLocationId), eq(testBooking.getDate()), eq(testBooking.getTimeFrom()), eq(testBooking.getTimeTo()))).thenReturn(true);
        doNothing().when(tableService).verifyTableCanAccommodateGuestsWithIdAndLocationId(eq(newTableId), eq(newLocationId), eq(testBooking.getGuestsNumber()));
        when(locationService.getLocationAddressById(newLocationId)).thenReturn("New Location");
        when(employeeRepository.getNameFromId(testBooking.getWaiterId())).thenReturn("Test Waiter");

        // When
        ReservationDto result = bookingService.updateBookingTableWithId(bookingId, newTableId, newLocationId);

        // Then
        assertNotNull(result);
        verify(bookingRepository).saveBooking(argThat(booking -> booking.getTableId().equals(newTableId) && booking.getLocationId().equals(newLocationId)));
    }

    private Booking createTestBooking() {
        Booking booking = new Booking();
        booking.setReservationId("res123");
        booking.setUserEmail("test@example.com");
        booking.setTableId("table1");
        booking.setLocationId("loc1");
        booking.setDate(futureDate);
        booking.setTimeFrom(futureTimeFrom);
        booking.setTimeTo(futureTimeTo);
        booking.setGuestsNumber("4");
        booking.setWaiterId("waiter1");
        booking.setStatus(BookingService.RESERVED);
        booking.setByCustomer(true);
        booking.setFeedbackId(BookingService.NO_FEEDBACK);
        return booking;
    }

    @Test
    void testGetListReservationDto() {
        // Given
        String userEmail = "test@example.com";

        // Mock setup
        when(bookingRepository.getBookingsByEmail(userEmail)).thenReturn(List.of(testBooking));
        when(locationService.getLocationAddressById(testBooking.getLocationId())).thenReturn("Test Location");
        when(employeeRepository.getNameFromId(testBooking.getWaiterId())).thenReturn("Test Waiter");

        // When
        List<ReservationDto> result = bookingService.getListReservationDto(userEmail);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        ReservationDto dto = result.get(0);
        assertEquals(testBooking.getReservationId(), dto.getId());
        assertEquals("Test Location", dto.getLocationAddress());
        assertEquals(testBooking.getDate(), dto.getDate());
        assertEquals(testBooking.getTimeFrom() + "-" + testBooking.getTimeTo(), dto.getTimeSlot());
        assertEquals("Test Waiter", dto.getWaiterName());
    }

    @Test
    void testGetListReservationDto_NullEmail() {
        // When & Then
        assertThrows(UnauthorizedException.class, () -> bookingService.getListReservationDto(null));
    }

    @Test
    void testGetListReservationDto_NoReservations() {
        // Given
        String userEmail = "test@example.com";
        when(bookingRepository.getBookingsByEmail(userEmail)).thenReturn(Collections.emptyList());

        // When
        List<ReservationDto> result = bookingService.getListReservationDto(userEmail);

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testCreateReservation() {
        // Given
        String reservationId = "res123";
        BookingRequestDto requestDto = new BookingRequestDto();
        requestDto.setUserEmail("test@example.com");
        requestDto.setTableId("table1");
        requestDto.setLocationId("loc1");
        requestDto.setDate(futureDate);
        requestDto.setTimeFrom(futureTimeFrom);
        requestDto.setTimeTo(futureTimeTo);
        requestDto.setGuestsNumber("4");

        // Mock setup
        when(locationService.doesLocationExist("loc1")).thenReturn(false);
        when(tableService.doesTableExistsWithIdAndLocationId("table1", "loc1")).thenReturn(true);
        when(tableService.isTableAvailableForBooking(eq("table1"), eq("loc1"), eq(futureDate), eq(futureTimeFrom), eq(futureTimeTo))).thenReturn(true);
        when(waiterService.getLeastBusyWaiter("loc1", futureDate, futureTimeFrom, futureTimeTo)).thenReturn("waiter1");
        when(bookingRepository.createBooking(any(Booking.class))).thenReturn(testBooking);
        when(locationService.getLocationAddressById("loc1")).thenReturn("Test Location");
        when(employeeRepository.getNameFromId("waiter1")).thenReturn("Test Waiter");

        // When
        ReservationDto result = bookingService.createReservation(requestDto, reservationId);

        // Then
        assertNotNull(result);
        assertEquals(reservationId, result.getId());
        verify(bookingRepository).createBooking(any(Booking.class));
    }

    @Test
    void testDeleteReservationWithId() {
        // Given
        String reservationId = "res123";
        String userEmail = "test@example.com";

        // Mock setup
        when(bookingRepository.doesBookingExist(reservationId)).thenReturn(true);
        when(bookingRepository.doesBookingExistForUserWithEmailAndId(reservationId, userEmail)).thenReturn(true);
        when(bookingRepository.getBookingByIdAndEmail(reservationId, userEmail)).thenReturn(testBooking);

        // When
        bookingService.deleteReservationWithId(reservationId, userEmail, false);

        // Then
        verify(bookingRepository).deleteUserBookingWithId(reservationId, userEmail);
        verify(tableService).removeTimeSlotFromTable(testBooking.getTableId(), testBooking.getLocationId(), testBooking.getDate(), testBooking.getTimeFrom() + "-" + testBooking.getTimeTo());
    }

    @Test
    void testUpdateBookingDateAndTimeWithId() {
        // Given
        String reservationId = "res123";
        String userEmail = "test@example.com";
        Map<String, String> updateFields = new HashMap<>();
        String newDate = LocalDate.now().plusDays(2).format(DateTimeFormatter.ISO_LOCAL_DATE);
        updateFields.put("date", newDate);
        updateFields.put("timeFrom", "14:00");
        updateFields.put("timeTo", "16:00");

        // Mock setup
        when(bookingRepository.doesBookingExistForUserWithEmailAndId(reservationId, userEmail)).thenReturn(true);
        when(bookingRepository.getBookingByIdAndEmail(reservationId, userEmail)).thenReturn(testBooking);
        when(locationService.getLocationAddressById(any())).thenReturn("Test Location");
        when(employeeRepository.getNameFromId(any())).thenReturn("Test Waiter");

        // When
        ReservationDto result = bookingService.updateBookingDateAndTimeWithId(reservationId, userEmail, updateFields, false);

        // Then
        assertNotNull(result);
        assertEquals(newDate, result.getDate());
        verify(bookingRepository).saveBooking(any(Booking.class));
    }

    @Test
    void testUpdateBookings() {
        // Given
        testBooking.setDate(LocalDate.now().minusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE));
        when(bookingRepository.getAllBookings()).thenReturn(List.of(testBooking));

        // When
        bookingService.updateBookings();

        // Then
        verify(bookingRepository).saveBooking(argThat(booking -> "FINISHED".equals(booking.getStatus())));
    }

    @Test
    void testSetFeedbackIdWithId() {
        // Given
        String reservationId = "res123";
        String feedbackId = "feedback1";

        // Mock setup
        when(bookingRepository.doesBookingExist(reservationId)).thenReturn(true);
        when(bookingRepository.getBookingById(reservationId)).thenReturn(testBooking);

        // When
        bookingService.setFeedbackIdWithId(reservationId, feedbackId);

        // Then
        verify(bookingRepository).saveBooking(argThat(booking -> feedbackId.equals(booking.getFeedbackId())));
    }

    @Test
    void testGetWaiterReservation() {
        // Given
        String waiterEmail = "waiter@example.com";
        String date = futureDate;
        String time = futureTimeFrom;
        String tableNumber = "table1";

        // Mock setup
        when(employeeRepository.getWaiterIdFromEmail(waiterEmail)).thenReturn("waiter1");
        when(bookingRepository.getBookingsByIdAndDate("waiter1", date)).thenReturn(List.of(testBooking));
        when(userService.getNameByEmail(any())).thenReturn("Test User");
        when(locationService.getLocationAddressById(any())).thenReturn("Test Location");

        // When
        List<WaiterReservationDto> result = bookingService.getWaiterReservation(waiterEmail, date, time, tableNumber);

        // Then
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals("Test Location", result.get(0).getLocationName());
    }


    @Test
    void testUpdateBookingDateAndTime_EmptyUpdate() {
        Map<String, String> emptyMap = new HashMap<>();
        assertThrows(IllegalArgumentException.class,
                () -> bookingService.updateBookingDateAndTimeWithId("res123", "test@example.com", emptyMap, false));
    }


    @Test
    void testCreateReservation_InvalidLocation() {
        // Given
        BookingRequestDto requestDto = createValidBookingRequest();
        requestDto.setLocationId("invalid");

        // Only mock what's actually needed
        when(locationService.doesLocationExist("invalid")).thenReturn(true);

        // When & Then
        assertThrows(NotFoundException.class, () -> bookingService.createReservation(requestDto, "res123"));

        // Verify the mock was actually used
        verify(locationService).doesLocationExist("invalid");
    }

    @Test
    void testDeleteReservation_Cancelled() {
        // Given
        String reservationId = "res123";
        String userEmail = "test@example.com";

        Booking cancelledBooking = createTestBooking();
        cancelledBooking.setStatus(BookingService.CANCELLED);

        // Mock setup - Important order
        when(bookingRepository.doesBookingExist(reservationId)).thenReturn(true);
        when(bookingRepository.doesBookingExistForUserWithEmailAndId(reservationId, userEmail)).thenReturn(true);
        when(bookingRepository.getBookingByIdAndEmail(reservationId, userEmail)).thenReturn(cancelledBooking);

        // When & Then
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> bookingService.deleteReservationWithId(reservationId, userEmail, false));

        assertEquals("Reservation is already cancelled.", exception.getMessage());
    }

    // Helper method if not already present
    private BookingRequestDto createValidBookingRequest() {
        BookingRequestDto dto = new BookingRequestDto();
        dto.setUserEmail("test@example.com");
        dto.setTableId("table1");
        dto.setLocationId("loc1");
        dto.setDate(futureDate);
        dto.setTimeFrom(futureTimeFrom);
        dto.setTimeTo(futureTimeTo);
        dto.setGuestsNumber("4");
        return dto;
    }


    // Test for null validation in validateBookingConstraints
    @Test
    void testValidateBookingConstraints_NullValues() {
        BookingRequestDto requestDto = new BookingRequestDto();
        // Don't set any fields - test null validation

        ValidationException exception = assertThrows(ValidationException.class, () -> bookingService.createReservation(requestDto, "res123"));
        assertEquals("Invalid booking details: Cannot parse null string", exception.getMessage());
    }

    // Test for time slot validation
    @Test
    void testValidateDateTime_InvalidTimeSlot() {
        BookingRequestDto requestDto = createValidBookingRequest();
        requestDto.setTimeFrom("14:00");
        requestDto.setTimeTo("14:00"); // Same time - should fail

        ValidationException exception = assertThrows(ValidationException.class, () -> bookingService.createReservation(requestDto, "res123"));
        assertEquals("Invalid booking details: End time must be after start time", exception.getMessage());
    }

    // Test for past date validation
    @Test
    void testValidateDateTime_PastDate() {
        BookingRequestDto requestDto = createValidBookingRequest();
        requestDto.setDate(LocalDate.now().minusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE));

        ValidationException exception = assertThrows(ValidationException.class, () -> bookingService.createReservation(requestDto, "res123"));
        assertEquals("Invalid booking details: Cannot book for past date/time", exception.getMessage());
    }

    // Test for guest number validation
    @Test
    void testValidateGuestCount_InvalidNumbers() {
        // Test too many guests
        BookingRequestDto tooManyGuests = createValidBookingRequest();
        tooManyGuests.setGuestsNumber("21");

        assertThrows(ValidationException.class, () -> bookingService.createReservation(tooManyGuests, "res123"));

        // Test zero guests
        BookingRequestDto zeroGuests = createValidBookingRequest();
        zeroGuests.setGuestsNumber("0");

        assertThrows(ValidationException.class, () -> bookingService.createReservation(zeroGuests, "res123"));
    }

    // Test for waiter booking with null email
    @Test
    void testMakeBookingForVisitor_NullEmail() {
        WaiterBookingDTO dto = new WaiterBookingDTO();
        dto.setTableNumber("table1");
        dto.setDate(futureDate);
        dto.setTimeFrom(futureTimeFrom);
        dto.setTimeTo(futureTimeTo);
        dto.setGuestsNumber("4");

        Booking result = bookingService.makeBookingForVisitor(dto, "waiter1", "res123", "loc1");

        assertEquals("dummy", result.getUserEmail());
        assertFalse(result.isByCustomer());
        verify(bookingRepository).saveBooking(any(Booking.class));
    }

    // Test for partial time update validation
    @Test
    void testUpdateBookingDateAndTime_PartialTimeUpdate() {
        Map<String, String> updateFields = new HashMap<>();
        updateFields.put("timeFrom", "14:00");
        // Missing timeTo - should fail

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> bookingService.updateBookingDateAndTimeWithId("res123", "test@example.com", updateFields, false));
        assertEquals("timeFrom and timeTo must be updated together", exception.getMessage());
    }

    // Test for status transitions in updateBookings
    @Test
    void testUpdateBookings_StatusTransitions() {
        // Past booking
        Booking pastBooking = createTestBooking();
        pastBooking.setDate(LocalDate.now().minusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE));

        // Current booking
        Booking currentBooking = createTestBooking();
        currentBooking.setDate(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
        currentBooking.setTimeFrom(LocalTime.now().minusHours(1).format(DateTimeFormatter.ofPattern("HH:mm")));
        currentBooking.setTimeTo(LocalTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("HH:mm")));

        when(bookingRepository.getAllBookings()).thenReturn(Arrays.asList(pastBooking, currentBooking));

        bookingService.updateBookings();

        verify(bookingRepository).saveBooking(argThat(booking -> "FINISHED".equals(booking.getStatus())));
        verify(bookingRepository).saveBooking(argThat(booking -> "IN PROGRESS".equals(booking.getStatus())));
    }

    // Test for cancelled booking update
    @Test
    void testUpdateBookings_CancelledBooking() {
        Booking cancelledBooking = createTestBooking();
        cancelledBooking.setStatus(BookingService.CANCELLED);

        when(bookingRepository.getAllBookings()).thenReturn(List.of(cancelledBooking));

        bookingService.updateBookings();

        verify(bookingRepository, never()).saveBooking(any(Booking.class));
    }

    // Test for waiter access validation
    @Test
    void testDeleteReservation_WaiterAccess() {
        // Given
        String reservationId = "res123";
        String waiterEmail = "waiter@example.com";

        // The booking's email will be used in deletion, not the waiter's email
        Booking bookingToDelete = createTestBooking(); // This has email "test@example.com"

        // Mock setup
        when(bookingRepository.doesBookingExist(reservationId)).thenReturn(true);
        when(bookingRepository.getBookingById(reservationId)).thenReturn(bookingToDelete);

        // When
        bookingService.deleteReservationWithId(reservationId, waiterEmail, true);

        // Then
        // Verify deletion uses the booking's email, not the waiter's
        verify(bookingRepository).deleteUserBookingWithId(reservationId, bookingToDelete.getUserEmail());

        // Also verify the time slot removals
        verify(tableService).removeTimeSlotFromTable(bookingToDelete.getTableId(), bookingToDelete.getLocationId(), bookingToDelete.getDate(), bookingToDelete.getTimeFrom() + "-" + bookingToDelete.getTimeTo());
        verify(waiterService).removeTimeSlot(bookingToDelete.getWaiterId(), bookingToDelete.getLocationId(), bookingToDelete.getDate(), bookingToDelete.getTimeFrom() + "-" + bookingToDelete.getTimeTo());
    }


    @Test
    void testCanCancelReservation_EdgeCases() throws Exception {
        // Given
        String date = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
        String time = LocalTime.now().plusMinutes(30).format(DateTimeFormatter.ofPattern("HH:mm"));

        // Use reflection to access private method
        Method canCancelMethod = BookingService.class.getDeclaredMethod("canCancelReservation", String.class, String.class);
        canCancelMethod.setAccessible(true);

        // When & Then
        boolean result = (boolean) canCancelMethod.invoke(bookingService, date, time);
        assertFalse(result);

        // Test exactly 31 minutes - should allow cancellation
        String timeJustOver = LocalTime.now().plusMinutes(31).format(DateTimeFormatter.ofPattern("HH:mm"));
        boolean resultJustOver = (boolean) canCancelMethod.invoke(bookingService, date, timeJustOver);
        assertTrue(resultJustOver);
    }

    @Test
    void testUpdateBookingDateAndTimeWithId_WaiterUpdate() {
        // Given
        String reservationId = "res123";
        String waiterEmail = "waiter@example.com";
        Map<String, String> updateFields = new HashMap<>();
        updateFields.put("locationId", "newLoc");    // Waiter can update location
        updateFields.put("tableNumber", "newTable"); // Waiter can update table

        when(bookingRepository.doesBookingExist(reservationId)).thenReturn(true);
        when(bookingRepository.getBookingById(reservationId)).thenReturn(testBooking);
        when(locationService.getLocationAddressById(any())).thenReturn("Test Location");
        when(employeeRepository.getNameFromId(any())).thenReturn("Test Waiter");

        // When
        ReservationDto result = bookingService.updateBookingDateAndTimeWithId(reservationId, waiterEmail, updateFields, true);

        // Then
        assertNotNull(result);
        verify(bookingRepository).saveBooking(any(Booking.class));
    }

    @Test
    void testValidateBookingConstraints_InvalidTimeFormat() {
        BookingRequestDto requestDto = createValidBookingRequest();
        requestDto.setTimeFrom("invalid");
        requestDto.setTimeTo("25:00");

        ValidationException exception = assertThrows(ValidationException.class, () -> bookingService.createReservation(requestDto, "res123"));
        assertTrue(exception.getMessage().contains("Invalid booking details"));
    }

    @Test
    void testUpdateBookings_MultipleStatuses() {
        // Past booking
        Booking pastBooking = createTestBooking();
        pastBooking.setDate(LocalDate.now().minusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE));

        // Current booking
        Booking currentBooking = createTestBooking();
        currentBooking.setDate(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
        currentBooking.setTimeFrom(LocalTime.now().minusHours(1).format(DateTimeFormatter.ofPattern("HH:mm")));
        currentBooking.setTimeTo(LocalTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("HH:mm")));

        // Future booking
        Booking futureBooking = createTestBooking();
        futureBooking.setDate(LocalDate.now().plusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE));

        // Cancelled booking
        Booking cancelledBooking = createTestBooking();
        cancelledBooking.setStatus(BookingService.CANCELLED);

        when(bookingRepository.getAllBookings()).thenReturn(Arrays.asList(pastBooking, currentBooking, futureBooking, cancelledBooking));

        bookingService.updateBookings();

        verify(bookingRepository).saveBooking(argThat(booking -> "FINISHED".equals(booking.getStatus())));
        verify(bookingRepository).saveBooking(argThat(booking -> "IN PROGRESS".equals(booking.getStatus())));
        verify(bookingRepository, never()).saveBooking(argThat(booking -> BookingService.CANCELLED.equals(booking.getStatus())));
    }

    @Test
    void testValidateUserBooking_Unauthorized() {
        // Given
        String reservationId = "res123";
        String userEmail = "unauthorized@example.com";

        when(bookingRepository.doesBookingExistForUserWithEmailAndId(reservationId, userEmail)).thenReturn(false);

        HashMap<String, String> map = new HashMap<>();
        map.put("date", "2025-10-10");
        // When & Then
        UnauthorizedException exception = assertThrows(UnauthorizedException.class, () -> bookingService.updateBookingDateAndTimeWithId(reservationId, userEmail, map, false));
        assertEquals("User can only access their own reservations", exception.getMessage());
    }


    @Test
    void testProcessCancellation_FailedWaiterUpdate() {
        // Given
        String reservationId = "res123";
        String userEmail = "test@example.com";

        when(bookingRepository.doesBookingExist(reservationId)).thenReturn(true);
        when(bookingRepository.doesBookingExistForUserWithEmailAndId(reservationId, userEmail)).thenReturn(true);
        when(bookingRepository.getBookingByIdAndEmail(reservationId, userEmail)).thenReturn(testBooking);
        doThrow(new ValidationException("Failed to update waiter schedule")).when(waiterService).removeTimeSlot(anyString(), anyString(), anyString(), anyString());

        // When & Then
        assertThrows(ValidationException.class, () -> bookingService.deleteReservationWithId(reservationId, userEmail, false));
    }

    @Test
    void testToReservationDto_NullBooking() {
        assertNull(bookingService.toReservationDto(null));
    }


    @Test
    void testToReservationDto_MissingWaiter() {
        // Given
        Booking bookingWithoutWaiter = createTestBooking();
        bookingWithoutWaiter.setWaiterId(null);

        when(locationService.getLocationAddressById(any())).thenReturn("Test Location");

        // When
        ReservationDto result = bookingService.toReservationDto(bookingWithoutWaiter);

        // Then
        assertNotNull(result);
        assertNull(result.getWaiterName());
    }


    @Test
    void testMakeBookingForCustomer_CompleteFlow() {
        // Given
        WaiterBookingDTO dto = new WaiterBookingDTO();
        dto.setTableNumber("table1");
        dto.setDate(futureDate);
        dto.setTimeFrom(futureTimeFrom);
        dto.setTimeTo(futureTimeTo);
        dto.setGuestsNumber("4");
        dto.setClientEmail("customer@example.com");

        // When
        bookingService.makeBookingForCustomer(dto, "waiter1", "res123", "loc1");

        // Then
        verify(bookingRepository).saveBooking(argThat(booking -> "customer@example.com".equals(booking.getUserEmail()) && !booking.isByCustomer() && BookingService.RESERVED.equals(booking.getStatus()) && "waiter1".equals(booking.getWaiterId()) && "table1".equals(booking.getTableId()) && "loc1".equals(booking.getLocationId()) && "res123".equals(booking.getReservationId())));
    }

}