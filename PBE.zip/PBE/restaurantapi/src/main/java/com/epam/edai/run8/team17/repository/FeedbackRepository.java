package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.model.Feedback;
import lombok.RequiredArgsConstructor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

import java.util.List;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
public class FeedbackRepository {
    private final DynamoDbTable<Feedback> feedbackTable;

    public void saveFeedback(Feedback feedback) {
        feedbackTable.putItem(feedback);
    }

    public Feedback getFeedbackById(String feedbackId) {
        return feedbackTable.getItem(r -> r.key(k -> k.partitionValue(feedbackId)));
    }

    public List<Feedback> getFeedbacksByLocationId(String locationId) {
        return feedbackTable.scan().items().stream()
                .filter(fb -> locationId.equals(fb.getLocationID()))
                .collect(Collectors.toList());
    }

    public Feedback getFeedbackByReservationId(String reservationId) {
        return feedbackTable.scan().items().stream()
                .filter(fb -> reservationId.equals(fb.getResID()))
                .findFirst()
                .orElse(null);
    }

    public List<Feedback> getFeedbackByLocation(String locationId, String type) {
        return feedbackTable.scan().items().stream()
                .filter(fb -> locationId.equalsIgnoreCase(fb.getLocationID()))
                .filter(fb -> type == null || type.isEmpty() || type.equalsIgnoreCase(fb.getType()))
                .collect(Collectors.toList());
    }
}