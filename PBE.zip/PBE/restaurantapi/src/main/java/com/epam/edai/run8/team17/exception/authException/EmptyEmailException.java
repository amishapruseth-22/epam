package com.epam.edai.run8.team17.exception.authException;

public class EmptyEmailException extends Exception{

    public EmptyEmailException(String message) {
        super(message);
    }
}
