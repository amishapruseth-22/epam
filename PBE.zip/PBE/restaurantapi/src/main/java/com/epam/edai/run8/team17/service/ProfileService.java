package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.dto.ChangePassword;
import com.epam.edai.run8.team17.dto.PutUsersProfileRequest;
import com.epam.edai.run8.team17.dto.UserResponse;
import com.epam.edai.run8.team17.exception.CredentialsInvalidException;
import com.epam.edai.run8.team17.exception.NotFoundException;
import com.epam.edai.run8.team17.model.User;
import com.epam.edai.run8.team17.repository.UserRepository;
import com.epam.edai.run8.team17.utils.Base64ImageHandler;
import com.epam.edai.run8.team17.utils.ChangePasswordDtoValidator;
import com.epam.edai.run8.team17.utils.PutUserProfileRequestValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sts.endpoints.internal.Value;

@Service
@RequiredArgsConstructor
public class ProfileService {

    private final UserRepository userRepository;
    private final TokenContextService tokenContextService;
    private final Base64ImageHandler base64ImageHandler;
    private final PasswordEncoder encoder;


    public UserResponse getUser() {
        String email = tokenContextService.getEmailFromToken();
        User user = userRepository.findByEmail(email);
        return UserResponse.builder()
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .imageUrl(user.getImageUrl())
                .email(user.getEmail())
                .build();
    }

    public String updateUser(PutUsersProfileRequest putUsersProfileRequest) {
        PutUserProfileRequestValidator.validate(putUsersProfileRequest);

        String email = tokenContextService.getEmailFromToken();
        User user = userRepository.findByEmail(email);

        if (user == null) {
            throw new NotFoundException("User not found");
        }

        String previousImageUrl = user.getImageUrl();
        String imageUrl;

        if (putUsersProfileRequest.getBase64encodedImage().isEmpty()) {
            imageUrl = previousImageUrl;
        } else {
            imageUrl = base64ImageHandler.handleBase64Image(putUsersProfileRequest.getBase64encodedImage());
        }

        user.setFirstName(putUsersProfileRequest.getFirstName());
        user.setLastName(putUsersProfileRequest.getLastName());
        user.setImageUrl(imageUrl);

        userRepository.saveUser(user);
        return "Profile has been successfully updated";
    }

    public String updatePassword(ChangePassword changePassword) {
        ChangePasswordDtoValidator.validate(changePassword);

        String email = tokenContextService.getEmailFromToken();
        User user = userRepository.findByEmail(email);

        if (!encoder.matches(changePassword.getOldPassword(), user.getPassword())) {
            throw new CredentialsInvalidException("Invalid credentials");
        }

        user.setPassword(encoder.encode(changePassword.getNewPassword()));

        userRepository.saveUser(user);
        return "Password has been successfully updated";
    }
}
