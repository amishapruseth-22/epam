package com.epam.edai.run8.team17.utils;

import com.epam.edai.run8.team17.model.Table;
import com.epam.edai.run8.team17.model.TimeSlot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class TableFilter {
    private static final Logger logger = LoggerFactory.getLogger(TableFilter.class);

    // Full list of predefined timeslots for table availability
    private static final List<String> ALL_TIMESLOTS = List.of(
            "10:30-12:00",
            "12:15-13:45",
            "14:00-15:30",
            "15:45-17:15",
            "17:30-19:00",
            "19:15-20:45",
            "21:00-22:30"
    );

    public static List<Table> filterTables(List<Table> tables, Date date, int guests, TimeSlot timeSlot) {
        logger.debug("[filterTables] Filtering tables for Date: {}, Guests: {}, TimeSlot: {}-{}",
                date, guests, timeSlot.getFrom(), timeSlot.getTo());

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = formatter.format(date);
        String timeSlotKey = timeSlot.getFrom() + "-" + timeSlot.getTo();

        logger.debug("[filterTables] Date string formatted: {}", dateString);

        return tables.stream()
                .filter(table -> {
                    // Check if table can accommodate the number of guests
                    int tableCapacity = Integer.parseInt(table.getCapacity());
                    if (tableCapacity < guests) {
                        logger.debug("[filterTables] Table ID: {} cannot accommodate {} guests.", table.getId(), guests);
                        return false;
                    }

                    // Check if the date is already booked
                    if (table.getBooked().containsKey(dateString)) {
                        logger.debug("[filterTables] Table ID: {} has bookings for Date: {}", table.getId(), dateString);

                        List<String> bookedTimeSlots = table.getBooked().get(dateString);
                        logger.debug("[filterTables] Booked time slots: {}", bookedTimeSlots);

                        // If the desired time slot is not booked, table is available
                        return !bookedTimeSlots.contains(timeSlotKey);
                    }

                    // No bookings for the date, table is available
                    return true;
                })
                .collect(Collectors.toList());
    }

    public static List<String> getAvailableTimeSlot(List<String> bookedTimes, String date) {
        logger.debug("[getAvailableTimeSlot] Getting available slots for Date: {}, Booked Times: {}", date, bookedTimes);

        // Start with the full list of timeslots
        List<String> allTimes = new ArrayList<>(ALL_TIMESLOTS);

        LocalDate today = LocalDate.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate otherDate = LocalDate.parse(date, dateFormatter);

        // Remove time slots in the past on the current date
        if (today.isEqual(otherDate)) {
            LocalTime currentTime = LocalTime.now(ZoneId.of("Asia/Kolkata")).truncatedTo(ChronoUnit.MINUTES);
            logger.debug("[getAvailableTimeSlot] Current time: {}", currentTime);

            allTimes.removeIf(timeSlot -> {
                String startTimeStr = timeSlot.split("-")[0];  // Extract the start time
                LocalTime startTime = LocalTime.parse(startTimeStr);
                return startTime.isBefore(currentTime); // Remove timeslots that start before the current time
            });
        }

        // Remove already booked times, if any
        if (bookedTimes != null && !bookedTimes.isEmpty()) {
            allTimes.removeAll(bookedTimes);
            logger.debug("[getAvailableTimeSlot] Removed booked times: {}", bookedTimes);
        }

        logger.debug("[getAvailableTimeSlot] Available times: {}", allTimes);
        return allTimes;
    }
}