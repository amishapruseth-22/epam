package com.epam.edai.run8.team17.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DishResponseDTO {
    private String id;
    private String name;
    private String imageUrl;
    private String price;
    private String weight;
    private String state;

    public static DishResponseDTO fromDishDTO(DishDTO dto) {
        return DishResponseDTO.builder().
                id(dto.getId()).
                name(dto.getName()).
                imageUrl(dto.getImageUrl()).
                price(dto.getPrice()).
                weight(dto.getWeight()).
                state(dto.getState())
                .build();
    }
}
