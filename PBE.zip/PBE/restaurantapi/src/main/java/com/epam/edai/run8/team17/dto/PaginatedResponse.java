package com.epam.edai.run8.team17.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedResponse<T> {
    private int totalPages;
    private int totalElements;
    private int size;
    private List<T> content;
    private int number;
    private boolean first;
    private boolean last;
    private int numberOfElements;
    private boolean empty;
    private Pageable pageable;
    private List<Sort> sort;

    @Data
    public static class Pageable {
        private int offset;
        private List<Sort> sort;
        private boolean paged;
        private int pageSize;
        private int pageNumber;
        private boolean unpaged;
    }

    @Data
    public static class Sort {
        private String direction;
        private String nullHandling;
        private boolean ascending;
        private String property;
        private boolean ignoreCase;
    }
}
