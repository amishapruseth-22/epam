package com.epam.edai.run8.team17.controller;

import com.epam.edai.run8.team17.dto.ReservationDto;
import com.epam.edai.run8.team17.dto.WaiterReservationDto;
import com.epam.edai.run8.team17.exception.reservationException.ForbiddenException;
import com.epam.edai.run8.team17.service.BookingService;
import com.epam.edai.run8.team17.service.TokenContextService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/reservations")
@RequiredArgsConstructor
@Slf4j
public class ReservationController {
    private static final String TABLE_ID = "tableId";
    private static final String LOCATION_ID = "locationId";

    private final BookingService bookingService;
    private final TokenContextService tokenContext;

    @GetMapping
    public ResponseEntity<List<ReservationDto>> getUserReservations() {
        String email = tokenContext.getEmailFromToken();
        bookingService.updateBookings();
        List<ReservationDto> bookings = bookingService.getListReservationDto(email);
        return ResponseEntity.ok(bookings);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<ReservationDto> updateReservation(@PathVariable String id, @RequestBody Map<String, String> updateFields) {
        String email = tokenContext.getEmailFromToken();
        ReservationDto updatedBooking = bookingService.updateBookingDateAndTimeWithId(id, email, updateFields, false);
        return ResponseEntity.ok(updatedBooking);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteReservation(@PathVariable String id) {
        String email = tokenContext.getEmailFromToken();
        bookingService.deleteReservationWithId(id, email, false);
        return ResponseEntity.ok(Map.of("message", "Reservation deleted successfully"));
    }

    @DeleteMapping("/waiters/{id}")
    public ResponseEntity<String> deleteReservationByWaiter(@PathVariable String id) throws ForbiddenException {
        String waiterEmail = tokenContext.getEmailFromToken();
        String role = tokenContext.getRoleFromToken();

        if (!role.equalsIgnoreCase("waiter")) {
            throw new ForbiddenException("Only waiters can perform this operation");
        }

        bookingService.deleteReservationWithId(id, waiterEmail, true);
        return ResponseEntity.ok("Reservation cancelled successfully");
    }

    @PatchMapping("/waiters/{id}")
    public ResponseEntity<ReservationDto> updateReservationByWaiter(@PathVariable String id, @RequestBody Map<String, String> updateFields) {
        String email = tokenContext.getEmailFromToken();
        String role = tokenContext.getRoleFromToken();

        if (!role.equalsIgnoreCase("waiter")) {
            throw new ForbiddenException("Only waiters can perform this operation");
        }

        validateRequestBody(updateFields);

        ReservationDto updatedBooking;
        if (isTableUpdate(updateFields) && isDateTimeUpdate(updateFields)) {
            bookingService.updateBookingTableWithId(id, updateFields.get(TABLE_ID), updateFields.get(LOCATION_ID));
            updatedBooking = bookingService.updateBookingDateAndTimeWithId(id, email, updateFields, true);
        } else if (isTableUpdate(updateFields)) {
            updatedBooking = bookingService.updateBookingTableWithId(id, updateFields.get(TABLE_ID), updateFields.get(LOCATION_ID));
        } else if (isDateTimeUpdate(updateFields)) {
            updatedBooking = bookingService.updateBookingDateAndTimeWithId(id, email, updateFields, true);
        } else {
            throw new IllegalArgumentException("Invalid update fields provided");
        }
        return ResponseEntity.ok(updatedBooking);
    }

    @GetMapping("/waiters")
    public ResponseEntity<List<WaiterReservationDto>> getWaiterReservations(
            @RequestParam(required = false) String date,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String table
    ) {
        String email = tokenContext.getEmailFromToken();

        if (date == null) {
            ZonedDateTime indianTime = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            date = indianTime.toLocalDate().format(DateTimeFormatter.ISO_LOCAL_DATE);
        }

        bookingService.updateBookings();
        List<WaiterReservationDto> bookings = bookingService.getWaiterReservation(email, date, time, table);
        return ResponseEntity.ok(bookings);
    }

    private boolean isTableUpdate(Map<String, String> updateFields) {
        return updateFields.containsKey(TABLE_ID) && updateFields.containsKey(LOCATION_ID);
    }

    private boolean isDateTimeUpdate(Map<String, String> updateFields) {
        return updateFields.containsKey("date") || (updateFields.containsKey("timeFrom") && updateFields.containsKey("timeTo"));
    }

    private void validateRequestBody(Map<String, String> requestBody) throws IllegalArgumentException {
        if (requestBody.containsKey(TABLE_ID) ^ requestBody.containsKey(LOCATION_ID)) {
            throw new IllegalArgumentException("tableId and locationId both are needed to update the Table for the Reservation!");
        }
    }
}