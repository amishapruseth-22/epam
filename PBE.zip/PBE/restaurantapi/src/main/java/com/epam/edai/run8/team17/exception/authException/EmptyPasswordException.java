package com.epam.edai.run8.team17.exception.authException;

public class EmptyPasswordException extends Exception{

    public EmptyPasswordException(String message) {
        super(message);
    }
}
