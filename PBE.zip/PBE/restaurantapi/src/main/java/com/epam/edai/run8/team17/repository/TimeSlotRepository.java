package com.epam.edai.run8.team17.repository;


import com.epam.edai.run8.team17.model.TimeSlot;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

import java.util.ArrayList;
import java.util.List;

@Repository
@AllArgsConstructor
@Slf4j
public class TimeSlotRepository {

    private DynamoDbTable<TimeSlot> timeSlotTable;

    public TimeSlot getTimeSlot(String startTime){
        List<TimeSlot> timeSlots = new ArrayList<>();
        timeSlotTable.scan().items().forEach(timeSlots::add);

        log.info(timeSlots.toString());

        // Filter results based on startTime and endTime
        TimeSlot timeSlot =  timeSlots.stream()
                .filter(slot -> slot != null && slot.getFrom() != null && slot.getTo() != null)  // Null check
                .filter(slot -> slot.getFrom().equals(startTime))
                .findFirst()
                .orElse(null);

        log.info(String.valueOf(timeSlot));
        return timeSlot;
    }
}
