package com.epam.edai.run8.team17.controller;


import com.epam.edai.run8.team17.dto.ChangePassword;
import com.epam.edai.run8.team17.dto.PutUsersProfileRequest;
import com.epam.edai.run8.team17.dto.UserResponse;
import com.epam.edai.run8.team17.service.ProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/users/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final ProfileService profileService;

    @GetMapping
    public ResponseEntity<UserResponse> getUsersProfile(){
        return ResponseEntity.ok(profileService.getUser());
    }

    @PutMapping
    public ResponseEntity<Map<String, String>> updateUserProfile(
            @RequestBody PutUsersProfileRequest putUsersProfileRequest
    ){
        String message = profileService.updateUser(putUsersProfileRequest);
        Map<String, String> json = new HashMap<>();
        json.put("message", message);

        return ResponseEntity.ok(json);
    }


    @PutMapping("/password")
    public ResponseEntity<Map<String, String>> updatePassword   (
            @RequestBody ChangePassword changePassword
    ){
        String message = profileService.updatePassword(changePassword);
        Map<String, String> json = new HashMap<>();
        json.put("message", message);

        return ResponseEntity.ok(json);
    }
}

