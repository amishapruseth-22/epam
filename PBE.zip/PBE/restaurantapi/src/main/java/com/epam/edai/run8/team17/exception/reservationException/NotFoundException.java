package com.epam.edai.run8.team17.exception.reservationException;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}

