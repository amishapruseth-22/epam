package com.epam.edai.run8.team17.dto;

import lombok.Data;

@Data
public class LocationResponse {
    private String id;
    private String address;
    private String description;
    private String totalCapacity;
    private String averageOccupancy;
}