package com.epam.edai.run8.team17.exception.authException;

public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) {
        super(message);
    }
}
