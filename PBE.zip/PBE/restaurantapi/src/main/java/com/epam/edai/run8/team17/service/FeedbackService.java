package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.dto.*;
import com.epam.edai.run8.team17.exception.reservationException.UnauthorizedException;
import com.epam.edai.run8.team17.model.Feedback;
import com.epam.edai.run8.team17.model.User;
import com.epam.edai.run8.team17.repository.BookingRepository;
import com.epam.edai.run8.team17.repository.FeedbackRepository;
import com.epam.edai.run8.team17.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FeedbackService {
    private final FeedbackRepository feedbackRepository;
    private final UserRepository userRepository;
    private final SQSEventService sqsEventService;
    private final TokenContextService tokenContextService;
    private final BookingService bookingService;

    private final Logger logger = LoggerFactory.getLogger(FeedbackService.class);

    public PaginatedResponse<FeedbackDTO> getFeedbackByLocationWithPagination(
            String locationId, int limit, int page, String type, String sortBy) {

        List<Feedback> filteredFeedbacks = feedbackRepository.getFeedbackByLocation(locationId, type);
        log.info(filteredFeedbacks.toString());

        List<Feedback> sortedFeedbacks = sortFeedbacks(filteredFeedbacks, sortBy);
        log.info(sortedFeedbacks.toString());

        List<FeedbackDTO> feedbackDTOs = sortedFeedbacks.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        return createPaginatedResponse(feedbackDTOs, limit, page, sortBy);
    }

    private List<Feedback> sortFeedbacks(List<Feedback> feedbacks, String sortBy) {
        return feedbacks.stream()
                .sorted((f1, f2) -> {
                    try {
                        return switch (sortBy.toLowerCase()) {
                            case "desc" ->
                                    Double.compare(Double.parseDouble(f2.getRate()), Double.parseDouble(f1.getRate()));
                            case "asc" ->
                                    Double.compare(Double.parseDouble(f1.getRate()), Double.parseDouble(f2.getRate()));
                            default -> f2.getDate().compareTo(f1.getDate());
                        };
                    } catch (Exception e) {
                        return 0;
                    }
                })
                .collect(Collectors.toList());
    }

    private FeedbackDTO convertToDTO(Feedback feedback) {
        return FeedbackDTO.builder()
                .id(feedback.getId())
                .date(feedback.getDate())
                .comment(feedback.getComment())
                .rate(feedback.getRate())
                .locationId(feedback.getLocationID())
                .type(feedback.getType())
                .userName(feedback.getUserName())
                .userAvatarUrl(feedback.getUserAvatarUrl())
                .build();
    }

    private PaginatedResponse<FeedbackDTO> createPaginatedResponse(
            List<FeedbackDTO> feedbackDTOs, int limit, int page, String sortBy) {

        int totalElements = feedbackDTOs.size();
        int totalPages = (int) Math.ceil((double) totalElements / limit);
        int offset = page * limit;

        List<FeedbackDTO> pagedContent = feedbackDTOs.stream()
                .skip(offset)
                .limit(limit)
                .collect(Collectors.toList());

        PaginatedResponse<FeedbackDTO> response = new PaginatedResponse<>();
        response.setTotalElements(totalElements);
        response.setTotalPages(totalPages);
        response.setSize(limit);
        response.setNumber(page);
        response.setNumberOfElements(pagedContent.size());
        response.setFirst(page == 0);
        response.setLast(page >= totalPages - 1);
        response.setEmpty(pagedContent.isEmpty());
        response.setContent(pagedContent);

        PaginatedResponse.Pageable pageable = new PaginatedResponse.Pageable();
        pageable.setOffset(offset);
        pageable.setPageNumber(page);
        pageable.setPageSize(limit);
        pageable.setPaged(true);
        pageable.setUnpaged(false);

        PaginatedResponse.Sort sort = new PaginatedResponse.Sort();
        sort.setDirection(sortBy.equalsIgnoreCase("oldest") || sortBy.equalsIgnoreCase("worst") ? "ASC" : "DESC");
        sort.setProperty(sortBy.equalsIgnoreCase("best") || sortBy.equalsIgnoreCase("worst") ? "rate" : "date");
        sort.setAscending(sortBy.equalsIgnoreCase("oldest") || sortBy.equalsIgnoreCase("worst"));
        sort.setIgnoreCase(false);
        sort.setNullHandling("NATIVE");

        pageable.setSort(List.of(sort));
        response.setPageable(pageable);
        response.setSort(List.of(sort));

        return response;
    }


    public ResponseEntity<?> createFeedback(FeedbackCreationDto feedbackCreationDto) {
        logger.info("create feedback method is invoked...");
        try {

            logger.info("validating feedback...");
            if (feedbackCreationDto.getCuisineComment() == null || feedbackCreationDto.getCuisineComment().isEmpty()) {
                throw new IllegalArgumentException("Missing cuisine comment");
            }

            if (feedbackCreationDto.getServiceComment() == null || feedbackCreationDto.getServiceComment().isEmpty()) {
                throw new IllegalArgumentException("Missing service comment");
            }

            if (feedbackCreationDto.getReservationId() == null || feedbackCreationDto.getReservationId().isEmpty()) {
                throw new IllegalArgumentException("Missing reservationId");
            }

            if (feedbackCreationDto.getServiceRating() == null || feedbackCreationDto.getServiceRating().isEmpty()) {
                throw new IllegalArgumentException("Missing service rating");
            }

            if (feedbackCreationDto.getCuisineRating() == null || feedbackCreationDto.getCuisineRating().isEmpty()) {
                throw new IllegalArgumentException("Missing cuisine rating");
            }

            int serviceRating = Integer.parseInt(feedbackCreationDto.getServiceRating());
            int cuisineRating = Integer.parseInt(feedbackCreationDto.getCuisineRating());

            if (serviceRating < 1 || serviceRating > 5 || cuisineRating < 1 || cuisineRating > 5) {
                throw new IllegalArgumentException("Ratings must be between 1 and 5");
            }

            String email = tokenContextService.getEmailFromToken();
            String userRole = tokenContextService.getRoleFromToken();
            logger.info("user email: {}, role: {}", email, userRole);

            if(!"customer".equalsIgnoreCase(userRole)){
                throw new UnauthorizedException("only customer is allowed to give feedback");
            }

            logger.info("Fetching user...");
            User user = userRepository.findByEmail(email);
            String imageUrl = user != null ? user.getImageUrl() : "test";
            String firstName = user != null ? user.getFirstName() : "test";
            String lastName = user != null ? user.getLastName() : "test";
            String role = user != null ? user.getRole().name() : "test";

            logger.info("Creating New Feedback");
            Feedback feedback = new Feedback();

            feedback.setId(UUID.randomUUID().toString());
            feedback.setComment(feedbackCreationDto.getCuisineComment() + " | " + feedbackCreationDto.getServiceComment());
            feedback.setDate(LocalDate.now(ZoneId.of("Asia/Kolkata")).toString());

            int averageRating = (cuisineRating + serviceRating) / 2;
            feedback.setRate(String.valueOf(averageRating));

            feedback.setResID(feedbackCreationDto.getReservationId());

            feedback.setCuisineComment(feedbackCreationDto.getCuisineComment());
            feedback.setCuisineRating(String.valueOf(feedbackCreationDto.getCuisineRating()));

            feedback.setServiceComment(feedbackCreationDto.getServiceComment());
            feedback.setServiceRating(String.valueOf(feedbackCreationDto.getServiceRating()));

            feedback.setUserAvatarUrl(imageUrl);

            feedback.setUserName(firstName + " " + lastName);

            feedback.setType(role);

            logger.info("setting location id by fetch from booking table...");
            feedback.setLocationID(bookingService.getLocationIdByReservationId(feedbackCreationDto.getReservationId()));

            feedbackRepository.saveFeedback(feedback);
            logger.info("New Feedback: {} is saved", feedback);

            logger.info("saving feedback id to booking repository: {}" ,feedback.getId());
            bookingService.setFeedbackIdWithId(feedbackCreationDto.getReservationId(), feedback.getId());

            logger.info("Sending Message to SQS...");

            sqsEventService.sendMessageToSQSCreateEvent(feedback);

            logger.info("createFeedback execution finished");
            return new ResponseEntity<>(
                    new JSONObject()
                            .put("message", "Feedback has been created")
                            .put("feedback_id", feedback.getId())
                            .toString(),
                    HttpStatus.CREATED);

        } catch (RuntimeException e) {
            logger.error(e.getMessage());
            return new ResponseEntity<>(
                    new JSONObject()
                            .put("error", e.getMessage())
                            .toString(),
                    HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error(e.getMessage());
            return new ResponseEntity<>(
                    new JSONObject()
                            .put("error", "Internal server error")
                            .toString(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> updateFeedback(FeedbackModificationDto feedbackModificationDto) {

        logger.info("Update feedback method invoked...");
        try {
            FeedbackUpdate feedbackUpdate = new FeedbackUpdate();

            String feedbackId = feedbackModificationDto.getFeedbackId();
            logger.info("Feedback id: {}", feedbackId);

            logger.info("validating Feedback modification Dto... {}", feedbackModificationDto);
            if (feedbackId == null || feedbackId.isEmpty()) {
                return new ResponseEntity<>(new JSONObject().put("error", "Missing 'feedbackId' in request body").toString(), HttpStatus.BAD_REQUEST);
            }

            if (feedbackModificationDto.getCuisineComment() == null || feedbackModificationDto.getServiceComment() == null ||
                    Integer.parseInt(feedbackModificationDto.getServiceRating()) < 1 || Integer.parseInt(feedbackModificationDto.getServiceRating()) > 5 ||
                    Integer.parseInt(feedbackModificationDto.getCuisineRating()) < 1 || Integer.parseInt(feedbackModificationDto.getCuisineRating()) > 5) {

                return new ResponseEntity<>(new JSONObject().put("error", "Invalid feedback data: cuisineComment, serviceComment, serviceRating (1-5), and cuisineRating (1-5) are required").toString(), HttpStatus.BAD_REQUEST);
            }

            logger.info("Fetching Prev Feedback....");
            Feedback prevFeedback = feedbackRepository.getFeedbackById(feedbackModificationDto.getFeedbackId());
            feedbackUpdate.setPreviousFeedback(prevFeedback);
            logger.info("Previous Feedback: {}", prevFeedback);

            Feedback existingFeedback = feedbackRepository.getFeedbackById(feedbackModificationDto.getFeedbackId());
            if (existingFeedback == null) {
                logger.error("Feedback doesn't exists");
                return new ResponseEntity<>(new JSONObject().put("error", "Feedback not found for the given feedbackId").toString(), HttpStatus.NOT_FOUND);
            }

            logger.info("Updating prev feedback...");
            existingFeedback.setComment(feedbackModificationDto.getCuisineComment() + " | " + feedbackModificationDto.getServiceComment());
            int serviceRating = Integer.parseInt(feedbackModificationDto.getServiceRating());

            existingFeedback.setServiceComment(feedbackModificationDto.getServiceComment());
            existingFeedback.setServiceRating(String.valueOf(feedbackModificationDto.getServiceRating()));

            int cuisineRating = Integer.parseInt(feedbackModificationDto.getCuisineRating());
            existingFeedback.setCuisineComment(feedbackModificationDto.getCuisineComment());
            existingFeedback.setCuisineRating(String.valueOf(feedbackModificationDto.getCuisineRating()));

            int averageRating = (cuisineRating + serviceRating) / 2;
            existingFeedback.setRate(String.valueOf(averageRating));

            existingFeedback.setDate(LocalDate.now(ZoneId.of("Asia/Kolkata")).toString());

            feedbackRepository.saveFeedback(existingFeedback);
            logger.info("Updated Feedback has been saved");

            logger.info("sending prev and new Feedback to sqs: {}", feedbackUpdate);
            feedbackUpdate.setFeedback(existingFeedback);
            sqsEventService.sendMessageToSQSUpdateEvent(feedbackUpdate);
            logger.info("FeedbackUpdate Message sent to sqs");

            logger.info("updateFeedback execution finished");
            return new ResponseEntity<>(new JSONObject().put("message", "Feedback has been updated successfully").toString(), HttpStatus.OK);

        } catch (Exception e) {
            logger.error(e.getMessage());
            return new ResponseEntity<>(new JSONObject().put("error", "Internal Server Error: " + e.getMessage()).toString(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}