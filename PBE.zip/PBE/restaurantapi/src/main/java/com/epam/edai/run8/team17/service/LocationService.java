package com.epam.edai.run8.team17.service;


import com.amazonaws.services.kms.model.NotFoundException;
import com.epam.edai.run8.team17.dto.*;
import com.epam.edai.run8.team17.model.Dish;


import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.LocationSmallDTO;

import com.epam.edai.run8.team17.model.Dish;
import com.epam.edai.run8.team17.model.Location;
import com.epam.edai.run8.team17.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LocationService {

    private final DishService dishService;

    private final DynamoDbEnhancedClient enhancedClient;
    @Value("${dynamodb.tables.location}")private String tableName;
    private final DishService dishesService;
    private final LocationRepository locationRepository;

    public List<LocationSmallDTO> getAllLocations() {
        List<Location> locations = locationRepository.getAllLocationsList();
        List<LocationSmallDTO> locationSmallDTOS = new ArrayList<>();
        for (Location location : locations) {
            locationSmallDTOS.add(new LocationSmallDTO(location.getId(), location.getAddress()));
        }
        return locationSmallDTOS;
    }

    public Location getLocationById(String locationId) {
        Optional<Location> location = locationRepository.getLocationDataById(locationId);
        return location.orElseThrow(() ->
                new NotFoundException(String.format("Location with id: %s does not exist", locationId))
        );
    }

    public String getLocationAddressByLocationId(String locationId) {
        return getLocationById(locationId).getAddress();
    }

    public List<Location> getAllLocationsList() {
        return locationRepository.getAllLocationsList();
    }

    public DishInfoDTO getSpecialityDishesByLocationId(String locationId) {
        List<Location> locations = getAllLocationsList();

        // Find speciality dish for the given location
        String dishName = locations.stream()
                .filter(location -> location.getId().equals(locationId))
                .map(Location::getSpecialityDishes)
                .findFirst()
                .orElseThrow(() ->
                        new NotFoundException(String.format("Location with id: %s does not exist", locationId))
                );

        // Fetch all dishes and find the matching dish
        List<DishSmallDTO> dishes = dishService.getAllDishes();
        return dishes.stream()
                .filter(dish -> dish.getName().equalsIgnoreCase(dishName))
                .map(dish -> new DishInfoDTO(
                        dish.getName(),
                        dish.getPrice(),
                        dish.getWeight(),
                        dish.getImageUrl()
                ))
                .findFirst()
                .orElseThrow(() -> new NotFoundException(String.format("Dish with name: %s does not exist", dishName)));


    }

    public String getLocationAddressById(String locationId) {
        if (locationId == null) {
            throw new IllegalArgumentException("Location ID cannot be null");
        }

        String address = locationRepository.getLocationAddress(locationId);
        if (address == null) {
            throw new NotFoundException(String.format("Location with id: %s does not exist", locationId));
        }

        return address;
    }


    public boolean doesLocationExist(String locationId) {
        if (locationId == null) {
            throw new IllegalArgumentException("Location ID cannot be null");
        }

        return locationRepository.getLocationById(locationId) != null;
    }

}