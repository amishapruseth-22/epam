package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.dto.FeedbackUpdate;
import com.epam.edai.run8.team17.exception.SqsEventException;
import com.epam.edai.run8.team17.model.Feedback;
import io.awspring.cloud.sqs.annotation.SqsListener;
import jakarta.annotation.PostConstruct;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

import javax.inject.Named;
import java.util.Map;

@Service
public class SQSEventService {

    private static final String EVENT_TYPE = "eventType";
    private static final String FEEDBACK_EVENT = "FEEDBACK_EVENT";
    private static final String NEW_FEEDBACK_EVENT = "NEW_FEEDBACK_EVENT";
    private static final String DAILY_EVENT = "DAILY-EVENT";

    private final SqsClient sqsClient;
    private final String queueUrl;
    private final ReportsGenerationService reportsGenerationService;

    private static final Logger logger = LoggerFactory.getLogger(SQSEventService.class);

    @Autowired
    public SQSEventService(SqsClient sqsClient, @Named("sqsQueueURL") String queueUrl, ReportsGenerationService reportsGenerationService) {
        this.sqsClient = sqsClient;
        this.queueUrl = queueUrl;
        this.reportsGenerationService = reportsGenerationService;
    }

    public void sendMessageToSQSUpdateEvent(FeedbackUpdate item) {
        try {
            SendMessageRequest sendMessageRequest = SendMessageRequest.builder()
                    .queueUrl(queueUrl)
                    .messageBody(new JSONObject(item).toString())
                    .messageAttributes(
                            Map.of(EVENT_TYPE, MessageAttributeValue.builder()
                            .stringValue(FEEDBACK_EVENT)
                            .dataType("String")
                            .build())
                    )
                    .build();

            sqsClient.sendMessage(sendMessageRequest);
        } catch (Exception e) {
            logger.error("Error sending message to SQS -> UpdateEvent");
            throw new SqsEventException(e);
        }
    }

    public void sendMessageToSQSCreateEvent(Feedback item) {
        try {
            SendMessageRequest sendMessageRequest = SendMessageRequest.builder()
                    .queueUrl(queueUrl)
                    .messageBody(new JSONObject(item).toString())
                    .messageAttributes(
                            Map.of(EVENT_TYPE, MessageAttributeValue.builder()
                                    .stringValue(NEW_FEEDBACK_EVENT)
                                    .dataType("String")
                                    .build())
                    ).build();

            sqsClient.sendMessage(sendMessageRequest);
        } catch (Exception e) {
            logger.error("Error sending message to SQS -> CreateEvent");
            throw new SqsEventException(e);
        }
    }

    @SqsListener(value = "${aws.sqs.reportQueue}")
    public void receiveMessage(String payload, @Headers Map<String, Object> headers) {
        try {
            logger.info("Received message from SQS: {}", payload);
            logger.info("Headers: {}", headers);

            String eventType = extractEventType(headers);

            if (eventType == null) {
                throw new SqsEventException("eventType is missing for the SQS Message");
            }

            logger.info("Received message with event type: {}", eventType);

            switch (eventType) {
                case DAILY_EVENT:
                    reportsGenerationService.dailyEventProcessing(payload);
                    break;
                case FEEDBACK_EVENT:
                    reportsGenerationService.feedbackEventProcessing(payload);
                    break;
                case NEW_FEEDBACK_EVENT:
                    reportsGenerationService.newFeedbackEventProcessing(payload);
                    break;
                default:
                    logger.info("{} is an unknown event type", eventType);
            }

            logger.info("Message processed successfully");
        } catch (Exception e) {
            logger.error("Error receiving message from SQS");
            throw new SqsEventException(e);
        }
    }

    @PostConstruct
    public void init() {
        logger.info("SQS Listener service initialized and ready to receive messages");
    }

    private String extractEventType(Map<String, Object> headers) {
        if (headers.containsKey(EVENT_TYPE)) {
            Object eventType = headers.get(EVENT_TYPE);
            return eventType.toString();
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> messageAttributes =
                (Map<String, Object>) headers.get("MessageAttributes");

        if (messageAttributes != null && messageAttributes.containsKey(EVENT_TYPE)) {
            Object attribute = messageAttributes.get(EVENT_TYPE);
            if (attribute instanceof Map) {
                return ((Map<String, String>) attribute).get("stringValue");
            }
            return attribute.toString();
        }

        return null;
    }
}
