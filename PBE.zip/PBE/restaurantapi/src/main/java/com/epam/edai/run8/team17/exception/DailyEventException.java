package com.epam.edai.run8.team17.exception;

public class DailyEventException extends RuntimeException{

    public DailyEventException(String message) {
        super(message);
    }

    public DailyEventException(String message, Throwable cause) {
        super(message, cause);
    }

    public DailyEventException(Throwable cause) {
        super(cause);
    }

}
