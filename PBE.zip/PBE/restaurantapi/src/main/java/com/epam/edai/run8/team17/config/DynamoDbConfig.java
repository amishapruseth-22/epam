package com.epam.edai.run8.team17.config;

import com.epam.edai.run8.team17.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.auth.StsAssumeRoleCredentialsProvider;

import javax.inject.Named;

import static software.amazon.awssdk.enhanced.dynamodb.TableSchema.fromBean;

@Configuration
public class DynamoDbConfig {
    @Value("${aws.accessKeyId}")
    private String accessKeyId;
    @Value("${aws.secretAccessKey}")
    private String secretAccessKey;
    @Value("${aws.sessionToken}")
    private String sessionToken;
    @Value("${aws.region}")
    private String awsRegion;
    @Value("${dynamodb.tables.user}")
    private String userTableName;
    @Value("${aws.roleArn}")
    private String roleArn;
    @Value("${dynamodb.tables.waiter}")
    private String waiterTableName;
    @Value("${dynamodb.tables.dish}")
    private String dishTableName;
    @Value("${dynamodb.tables.location}")
    private String locationTableName;
    @Value("${dynamodb.tables.feedback}")
    private String feedbackTableName;
    @Value("${dynamodb.tables.employee}")
    private String employeeTableName;
    @Value("${dynamodb.tables.booking}")
    private String bookingTableName;
    @Value("${dynamodb.tables.tables}")
    private String tablesTableName;
    @Value("${dynamodb.tables.timeslot}")
    private String timeslotTablesName;

    @Value("${dynamodb.tables.waiterReport}")
    private String waiterReportTableName;
    @Value("${dynamodb.tables.locationReport}")
    private String locationReportTableName;

    @Bean
    @Named("stsAssumeRoleCredentialsProvider")
    public StsAssumeRoleCredentialsProvider stsAssumeRoleCredentialsProvider() {
        AwsSessionCredentials sessionCredentials = AwsSessionCredentials.create(
                accessKeyId,
                secretAccessKey,
                sessionToken
        );
        // Step 2: Create STS client using the initial session credentials
        StsClient stsClient = StsClient.builder()
                .region(Region.of(awsRegion))
                .credentialsProvider(StaticCredentialsProvider.create(sessionCredentials))
                .build();
        // Step 3: Assume Role credentials provider
        return StsAssumeRoleCredentialsProvider.builder()
                .refreshRequest(r -> r.roleArn(roleArn).roleSessionName("assume-role-session"))
                .stsClient(stsClient)
                .build();
    }

    @Bean
    public DynamoDbClient dynamoDbClient(@Autowired StsAssumeRoleCredentialsProvider stsAssumeRoleCredentialsProvider) {
        return DynamoDbClient.builder()
                .region(Region.of(awsRegion))
                .credentialsProvider(stsAssumeRoleCredentialsProvider)
                .build();
    }

    @Bean
    public DynamoDbEnhancedClient dynamoDbEnhancedClient(DynamoDbClient dynamoDbClient) {
        return DynamoDbEnhancedClient.builder()
                .dynamoDbClient(dynamoDbClient)
                .build();
    }

    @Bean
    public DynamoDbTable<User> userTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(userTableName, fromBean(User.class));
    }

    @Bean
    public DynamoDbTable<Waiter> waiterTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(waiterTableName, fromBean(Waiter.class));
    }

    @Bean
    public DynamoDbTable<Dish> dishTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(dishTableName, fromBean(Dish.class));
    }

    @Bean
    public DynamoDbTable<Location> locationTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(locationTableName, fromBean(Location.class));
    }

    @Bean
    public DynamoDbTable<Feedback> feedbackTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(feedbackTableName, fromBean(Feedback.class));
    }

    @Bean
    public DynamoDbTable<Employee> employeeTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(employeeTableName, fromBean(Employee.class));
    }

    @Bean
    public DynamoDbTable<Booking> bookingTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(bookingTableName, fromBean(Booking.class));
    }

    @Bean
    public DynamoDbTable<Table> tablesTable(DynamoDbEnhancedClient enhancedClient) {
        return enhancedClient.table(tablesTableName, fromBean(Table.class));
    }

    @Bean
    public DynamoDbTable<TimeSlot> timeSlotTable(DynamoDbEnhancedClient enhancedClient ){
        return enhancedClient.table(timeslotTablesName, fromBean(TimeSlot.class));
    }

    @Bean
    public DynamoDbTable<WaiterReport> waiterReportTable(DynamoDbEnhancedClient enhancedClient ){
        return enhancedClient.table(waiterReportTableName, fromBean(WaiterReport.class));
    }

    @Bean
    public DynamoDbTable<LocationReport> locationReportTable(DynamoDbEnhancedClient enhancedClient ){
        return enhancedClient.table(locationReportTableName, fromBean(LocationReport.class));
    }

}