package com.epam.edai.run8.team17.dto;

import lombok.Data;

@Data
public class FeedbackResponse {
    private String id;
    private String rate;
    private String comment;
    private String userName;
    private String userAvatarUrl;
    private String date;
    private String type;
    private String locationId;
}