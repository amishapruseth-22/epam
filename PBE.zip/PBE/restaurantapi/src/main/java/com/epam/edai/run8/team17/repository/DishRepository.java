package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.dto.DishDTO;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.DishResponseDTO;
import com.epam.edai.run8.team17.exception.DishNotFoundException;
import com.epam.edai.run8.team17.model.Dish;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.logging.Logger;

@Repository
@RequiredArgsConstructor
public class DishRepository {

    private static final Logger logger = Logger.getLogger(DishRepository.class.getName());
    private final DynamoDbTable<Dish> table;
    private static final String POPULARITY_CONST = "popularity";
    private static final String ON_STOP_CONST = "On stop";

    public List<Dish> findAll() {
        List<Dish> dishes = new ArrayList<>();
        table.scan().items().forEach(dishes::add);
        return dishes;
    }

    public Dish findById(String id) {
        return findAll().stream()
                .filter(dish -> dish.getId().equalsIgnoreCase(id))
                .findFirst()
                .orElse(null);
    }
//
public List<DishResponseDTO> getListOfAllDishes(String dishType, String sort) {
    List<DishDTO> allDishes = getFullDishDTOs();

    if (Objects.nonNull(sort) && !sort.isBlank()) {
        allDishes = sortDishes(allDishes, sort);
    }

    if (Objects.nonNull(dishType) && !dishType.isBlank()) {
        allDishes = filterByDishType(allDishes, dishType);
    }


    return allDishes.stream()
            .map(DishResponseDTO::fromDishDTO)
            .toList();
}

    private List<DishDTO> filterByDishType(List<DishDTO> dishes, String dishType) {
        return dishes.stream()
                .filter(d -> d.getDishType() != null && d.getDishType().equalsIgnoreCase(dishType))
                .toList();
    }

    private List<DishDTO> sortDishes(List<DishDTO> dishes, String sort) {
        String[] sortParts = sort.toLowerCase().split(",");
        if (sortParts.length != 2) {
            return dishes;
        }

        String sortBy = sortParts[0];
        String sortOrder = sortParts[1];
        Comparator<DishDTO> comparator = getComparator(sortBy);

        if (comparator != null && "desc".equals(sortOrder) && !POPULARITY_CONST.equals(sortBy)) {
            comparator = comparator.reversed();
        }

        if (comparator != null) {
            dishes.sort(comparator);
        }

        return dishes;
    }

    private Comparator<DishDTO> getComparator(String sortBy) {
        return switch (sortBy) {
            case "price" -> Comparator.comparingDouble(d -> Double.parseDouble(d.getPrice()));
            case POPULARITY_CONST -> Comparator
                    .comparing(DishDTO::getIsPopular).reversed()
                    .thenComparing(Comparator.comparingInt((DishDTO d) -> Integer.parseInt(d.getPopularityScore())).reversed());
            default -> null;
        };
    }


    public List<DishInfoDTO> getPopularDishes() {
        List<DishInfoDTO> popularDishesDTOs = new ArrayList<>();

        table.scan().items().forEach(dish -> {
            if (dish.isPopular()) {
                DishInfoDTO dto = DishInfoDTO.builder()
                        .name(dish.getName())
                        .price(dish.getPrice())
                        .weight(dish.getWeight())
                        .imageUrl(dish.getImage())
                        .build();
                popularDishesDTOs.add(dto);
            }
        });
        return popularDishesDTOs;
    }

    public DishDTO getDishDtoById(String dishId) {
        List<Dish> dishes = new ArrayList<>();
        table.scan().items().forEach(dishes::add);

        for (Dish dish : dishes) {
            if (dish.getId().equalsIgnoreCase(dishId)) {
                if (!dish.isAvailable()) {
                    dish.setState(ON_STOP_CONST);
                }
                return DishDTO.builder()
                        .id(dish.getId())
                        .name(dish.getName())
                        .price(dish.getPrice())
                        .weight(dish.getWeight())
                        .imageUrl(dish.getImage())
                        .description(dish.getDescription())
                        .calories(dish.getCalories())
                        .carbohydrates(dish.getCarbs())
                        .dishType(dish.getDishType())
                        .fats(dish.getFats())
                        .proteins(dish.getProteins())
                        .state(dish.getState())
                        .vitamins(dish.getVitamins())
                        .build();
            }
        }
        throw new DishNotFoundException("Dish with id " + dishId + " not found");
    }

    public List<DishResponseDTO> getDishCategorizedByType(String dishTypeFilter) {
        List<Dish> dishes = new ArrayList<>();
        table.scan().items().forEach(dishes::add);

        // Update state based on availability
        for (Dish dish : dishes) {
            if (!dish.isAvailable()) {
                dish.setState(ON_STOP_CONST);
            }
        }

        // Filter
        List<Dish> filteredDishes = dishes;
        if (dishTypeFilter != null && !dishTypeFilter.isEmpty()) {
            filteredDishes = dishes.stream()
                    .filter(dish -> dish.getDishType().equalsIgnoreCase(dishTypeFilter))
                    .toList();
        }

        // Map to DTO
        return filteredDishes.stream()
                .map(dish -> DishResponseDTO.builder()
                        .id(dish.getId())
                        .name(dish.getName())
                        .imageUrl(dish.getImage())
                        .price(dish.getPrice())
                        .weight(dish.getWeight())
                        .state(dish.getState())
                        .build())
                .toList();
    }

    public List<DishResponseDTO> sortDishes(String sort) {
        List<DishDTO> allDishes = getFullDishDTOs();

        if (sort == null || sort.isBlank()) {
            return allDishes.stream()
                    .map(DishResponseDTO::fromDishDTO)
                    .toList();
            // return convertToSmallDTO(allDishes); // 🔁 Old code commented out
        }

        String[] sortParts = sort.toLowerCase().split(",");
        if (sortParts.length != 2) {
            return allDishes.stream()
                    .map(DishResponseDTO::fromDishDTO)
                    .toList();
        }

        String sortBy = sortParts[0];
        String sortOrder = sortParts[1];

        Comparator<DishDTO> comparator = null;

        switch (sortBy) {
            case "price":
                comparator = Comparator.comparingDouble(d -> Double.parseDouble(d.getPrice()));
                break;
            case POPULARITY_CONST:
                comparator = Comparator
                        .comparing(DishDTO::getIsPopular).reversed()
                        .thenComparing(Comparator.comparingInt((DishDTO d) -> Integer.parseInt(d.getPopularityScore())).reversed());
                break;
            default:
                break;
        }

        if (comparator != null && "desc".equals(sortOrder) && !POPULARITY_CONST.equals(sortBy)) {
            comparator = comparator.reversed();
        }

        if (comparator != null) {
            allDishes.sort(comparator);
        }

        return allDishes.stream()
                .map(DishResponseDTO::fromDishDTO)
                .toList();
    }

    private List<DishDTO> getFullDishDTOs() {
        List<DishDTO> dishes = new ArrayList<>();

        table.scan().items().forEach(dish -> {
            if (!dish.isAvailable()) {
                dish.setState(ON_STOP_CONST);
            }

            DishDTO dto = DishDTO.builder()
                    .id(dish.getId())
                    .name(dish.getName())
                    .imageUrl(dish.getImage())
                    .price(dish.getPrice())
                    .weight(dish.getWeight())
                    .state(dish.getState())
                    .description(dish.getDescription())
                    .calories(dish.getCalories())
                    .carbohydrates(dish.getCarbs())
                    .dishType(dish.getDishType())
                    .fats(dish.getFats())
                    .proteins(dish.getProteins())
                    .vitamins(dish.getVitamins())
                    .isPopular(dish.isPopular())
                    .popularityScore(dish.getPopularityScore())
                    .build();

            dishes.add(dto);
        });

        return dishes;
    }
}
