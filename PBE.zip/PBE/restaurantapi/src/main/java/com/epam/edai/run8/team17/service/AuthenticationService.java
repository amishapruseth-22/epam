package com.epam.edai.run8.team17.service;


import com.epam.edai.run8.team17.dto.AuthenticationResponse;
import com.epam.edai.run8.team17.dto.SignInRequest;
import com.epam.edai.run8.team17.dto.SignUpRequest;
import com.epam.edai.run8.team17.dto.SignUpResonse;
import com.epam.edai.run8.team17.exception.CredentialsInvalidException;
import com.epam.edai.run8.team17.exception.authException.*;
import com.epam.edai.run8.team17.model.Role;
import com.epam.edai.run8.team17.model.User;
import com.epam.edai.run8.team17.repository.EmployeeRepository;
import com.epam.edai.run8.team17.repository.UserRepository;
import com.epam.edai.run8.team17.utils.SignInValidator;
import com.epam.edai.run8.team17.utils.SignUpValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

    private final UserRepository repository;
    private final JwtService service;
    private final PasswordEncoder encoder;
    private final EmployeeRepository employeeRepository;

    public SignUpResonse register(SignUpRequest request){
        SignUpValidator.validateSignUp(request);
        if(repository.findByEmail(request.getEmail()) != null){
            throw new UserAlreadyExists("User Already exists");
        }
        Role assignedRole = Role.CUSTOMER;
        if(employeeRepository.doesEmployeeExist(request.getEmail())){
            if(employeeRepository.getRoleByEmail(request.getEmail()).equalsIgnoreCase("waiter")){
                assignedRole = Role.WAITER;
            } else if(employeeRepository.getRoleByEmail(request.getEmail()).equalsIgnoreCase("admin")){
                assignedRole = Role.ADMIN;
            }
        }

        var user = User.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .password(encoder.encode(request.getPassword()))
                .role(assignedRole)
                .imageUrl("")
                .build();

        repository.saveUser(user);
        return SignUpResonse.builder()
                .idToken(service.generatedIdToken(user))
                .message("user registered successfully")
                .build();
    }

    public AuthenticationResponse authenticate(SignInRequest request) throws EmptyPasswordException, EmptyEmailException, InvalidEmailException {
        SignInValidator.validateSingIn(request);
        var user = repository.findByEmail(request.getEmail());

        if(user == null){
            throw new UserNotFoundException("User Not Found");
        }

        if (!encoder.matches(request.getPassword(), user.getPassword())) {
            throw new CredentialsInvalidException("Invalid credentials");
        }

        return AuthenticationResponse.builder()
                .accessToken(service.generateAccessToken(user))
                .idToken(service.generatedIdToken(user))
                .refreshToken(service.generateRefreshToken(user))
                .role(user.getRole().name())
                .username(user.getFirstName() + " " + user.getLastName())
                .email(user.getEmail())
                .build();
    }
}
