package com.epam.edai.run8.team17.model;


import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

import java.util.List;
import java.util.Map;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@DynamoDbBean
public class Waiter {

    private String id;
    private String locationId;
    private Map<String, List<String>> booked;
    private boolean isActive;
    private String shiftStart;
    private String shiftEnd;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("waiter_id")
    public String getId(){
        return id;
    }

    @DynamoDbSortKey
    @DynamoDbAttribute("location_id")
    public  String getLocationId(){
        return locationId;
    }

    @DynamoDbAttribute("shift_start")
    public String getShiftStart(){
        return shiftStart;
    }

    @DynamoDbAttribute("shift_end")
    public String getShiftEnd(){
        return shiftEnd;
    }

    @DynamoDbAttribute("isActive")
    public boolean isActive(){
        return isActive;
    }

    @DynamoDbAttribute("booked")
    public Map<String, List<String>> getBooked(){
        return booked;
    }

}
