package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.dto.DishDTO;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.DishResponseDTO;
import com.epam.edai.run8.team17.dto.DishSmallDTO;
import com.epam.edai.run8.team17.exception.DishNotFoundException;
import com.epam.edai.run8.team17.model.Dish;
import com.epam.edai.run8.team17.repository.DishRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.*;

@Service
@RequiredArgsConstructor
public class DishService {

    private final DishRepository dishRepository;
    private static final String ON_STOP_CONST = "On stop";

    public List<DishResponseDTO> getListOfAllDishes(String dishType, String sort) {
        return dishRepository.getListOfAllDishes(dishType, sort);
    }

    public List<DishInfoDTO> getListOfAllPopularDishes() {
        return dishRepository.getPopularDishes();
    }

    public DishDTO getDishById(String id) {
        return dishRepository.getDishDtoById(id);
    }

    private List<DishDTO> getFullDishDTOs() {
        return dishRepository.findAll().stream().map(dish -> {
            if (!dish.isAvailable()) {
                dish.setState(ON_STOP_CONST);
            }
            return DishDTO.builder()
                    .id(dish.getId())
                    .name(dish.getName())
                    .imageUrl(dish.getImage())
                    .price(dish.getPrice())
                    .weight(dish.getWeight())
                    .state(dish.getState())
                    .description(dish.getDescription())
                    .calories(dish.getCalories())
                    .carbohydrates(dish.getCarbs())
                    .fats(dish.getFats())
                    .proteins(dish.getProteins())
                    .vitamins(dish.getVitamins())
                    .dishType(dish.getDishType())
                    .isAvailable(dish.isAvailable())
                    .isPopular(dish.isPopular())
                    .popularityScore(dish.getPopularityScore())
                    .build();
        }).toList();
    }

    public List<DishSmallDTO> getAllDishes() {
        return convertToSmallDTO(getFullDishDTOs());
    }

    public DishDTO getDishesById(String dishId) {
        Dish dish = dishRepository.findById(dishId);
        if (dish == null) {
            throw new DishNotFoundException("Dish with id " + dishId + " not found");
        }
        if (!dish.isAvailable()) {
            dish.setState(ON_STOP_CONST);
        }

        return DishDTO.builder()
                .id(dish.getId())
                .name(dish.getName())
                .price(dish.getPrice())
                .weight(dish.getWeight())
                .imageUrl(dish.getImage())
                .description(dish.getDescription())
                .calories(dish.getCalories())
                .carbohydrates(dish.getCarbs())
                .dishType(dish.getDishType())
                .fats(dish.getFats())
                .proteins(dish.getProteins())
                .state(dish.getState())
                .vitamins(dish.getVitamins())
                .build();
    }

    public List<Dish> getDishCategorizedByType(String dishTypeFilter) {
        List<Dish> dishes = dishRepository.findAll();
        dishes.forEach(dish -> {
            if (!dish.isAvailable()) dish.setState(ON_STOP_CONST);
        });

        if (dishTypeFilter != null && !dishTypeFilter.isEmpty()) {
            List<Dish> filtered = dishes.stream()
                    .filter(d -> dishTypeFilter.equalsIgnoreCase(d.getDishType()))
                    .toList();
            if (!filtered.isEmpty()) return filtered;
        }
        return dishes;
    }

    public List<DishSmallDTO> sortDishes(String sort) {
        List<DishDTO> allDishes = getFullDishDTOs();
        if (sort == null || sort.isBlank()) {
            return convertToSmallDTO(allDishes);
        }
        String[] parts = sort.toLowerCase().split(",");
        if (parts.length != 2) {
            return convertToSmallDTO(allDishes);
        }
        String sortBy = parts[0];
        String sortOrder = parts[1];
        Comparator<DishDTO> comparator = null;
        switch (sortBy) {
            case "price":
                comparator = Comparator.comparingDouble(d -> Double.parseDouble(d.getPrice()));
                break;
            case "popularity":
                comparator = Comparator
                        .comparing(DishDTO::getIsPopular).reversed()
                        .thenComparing(Comparator.comparingInt(d-> Integer.parseInt(d.getPopularityScore()))).reversed();
                break;
            default:
                break;
        }
        if (comparator != null && "desc".equals(sortOrder) && !"popularity".equals(sortBy)) {
            comparator = comparator.reversed();
        }
        if (comparator != null) {
            allDishes.sort(comparator);
        }
        return convertToSmallDTO(allDishes);
    }

    private List<DishSmallDTO> convertToSmallDTO(List<DishDTO> fullDishes) {
        return fullDishes.stream()
                .map(dto -> DishSmallDTO.builder()
                        .id(dto.getId())
                        .name(dto.getName())
                        .imageUrl(dto.getImageUrl())
                        .price(dto.getPrice())
                        .weight(dto.getWeight())
                        .state(dto.getState())
                        .dishType(dto.getDishType())
                        .isPopular(dto.getIsPopular())
                        .popularityScore(dto.getPopularityScore())
                        .build())
                .toList();
    }
}
