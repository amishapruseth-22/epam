package com.epam.edai.run8.team17.controller;

import com.amazonaws.services.kms.model.NotFoundException;
import com.epam.edai.run8.team17.config.ApiResponse;
import com.epam.edai.run8.team17.dto.*;
import com.epam.edai.run8.team17.exception.ForbiddenException;
import com.epam.edai.run8.team17.model.TimeSlot;
import com.epam.edai.run8.team17.service.BookingService;
import com.epam.edai.run8.team17.service.ReservationService;
import com.epam.edai.run8.team17.service.TableService;
import com.epam.edai.run8.team17.service.TokenContextService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/bookings")
@RequiredArgsConstructor
@Slf4j
public class BookingController {
    private final BookingService bookingService;
    private final ReservationService reservationService;
    private final ObjectMapper objectMapper;
    private final TokenContextService tokenContext;

    private final TableService tableService;

    @PostMapping("/client")
    public ResponseEntity<ReservationDtoWithTableId> createBooking(@NotNull @RequestBody BookingRequestDto bookingRequestDto) {
        log.info("Processing booking creation request");
        String email = tokenContext.getEmailFromToken();
        bookingRequestDto.setUserEmail(email);

        ReservationDto reservationDto = bookingService.createReservation(bookingRequestDto, UUID.randomUUID().toString());
        ReservationDtoWithTableId response = objectMapper.convertValue(reservationDto, ReservationDtoWithTableId.class);
        response.setTableId(bookingRequestDto.getTableId());

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/waiter")
    public ResponseEntity<ReservationByWaiterDTO> createBookingByWaiter(@RequestBody WaiterBookingDTO waiterBookingDTO, @RequestHeader("Authorization") String token){
        log.info("Processing waiter booking creation request");
        String waiterEmail = tokenContext.getEmailFromToken();
        String role = tokenContext.getRoleFromToken();

        if (!role.equalsIgnoreCase("waiter")) {
            throw new ForbiddenException("Only waiters can perform this operation");
        }

        if (waiterBookingDTO.getClientType() == null) {
            throw new IllegalArgumentException("clientType is required");
        }

        String clientType = waiterBookingDTO.getClientType().toLowerCase();
        switch (clientType) {
            case "customer":
                if (waiterBookingDTO.getClientEmail() == null || waiterBookingDTO.getClientEmail().isBlank()) {
                    throw new IllegalArgumentException("Customer email is required for clientType 'customer'");
                }
                break;
            case "visitor":
                waiterBookingDTO.setClientEmail(null);
                break;
            default:
                throw new IllegalArgumentException("Invalid clientType. Must be 'customer' or 'visitor'");
        }

        ReservationByWaiterDTO reservation = reservationService.bookTable(waiterEmail, waiterBookingDTO, UUID.randomUUID().toString());
        return ResponseEntity.status(HttpStatus.CREATED).body(reservation);
    }

    @GetMapping("/tables")
    public ResponseEntity<Map<String, List<TableAvailableDTO>>> getAvailableTables(
            @RequestParam(value = "locationId") String locationId,
            @RequestParam(value = "date") String date,
            @RequestParam(value = "timeSlot") String timeSlot,
            @RequestParam(value = "guests") int guests
    )  {
        if (guests <= 0 || guests > 50) {
            throw new IllegalArgumentException("Invalid number of guests. Must be between 1 and 50.");
        }

        TimeSlot parsedTimeSlot = tableService.parseTimeSlot(timeSlot);
        if (parsedTimeSlot == null) {
            throw new IllegalArgumentException("Invalid time slot: " + timeSlot + ". Format must be 'HH:mm-HH:mm'.");
        }

        List<TableAvailableDTO> availableTables = tableService.getAvailableTables(locationId, date, parsedTimeSlot, guests);

        if (availableTables == null || availableTables.isEmpty()) {
            throw new NotFoundException("No available tables found for the specified criteria.");
        }

        return ResponseEntity.ok(Map.of("tables", availableTables));
    }
}