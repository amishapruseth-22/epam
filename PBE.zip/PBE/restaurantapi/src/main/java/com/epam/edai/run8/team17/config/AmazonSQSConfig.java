package com.epam.edai.run8.team17.config;

import com.epam.edai.run8.team17.exception.SqsEventException;
import io.awspring.cloud.sqs.config.SqsBootstrapConfiguration;
import io.awspring.cloud.sqs.config.SqsMessageListenerContainerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.GetQueueUrlRequest;
import software.amazon.awssdk.services.sts.auth.StsAssumeRoleCredentialsProvider;

import javax.inject.Named;

@Import(SqsBootstrapConfiguration.class)
@Configuration
public class AmazonSQSConfig {

    @Value("${aws.sqs.reportQueue}")
    private String queueName;

    @Value("${aws.region}")
    private String region;

    @Bean
    public SqsClient amazonSQS(@Autowired StsAssumeRoleCredentialsProvider stsAssumeRoleCredentialsProvider) {
        return SqsClient.builder()
                .region(Region.of(region))
                .credentialsProvider(stsAssumeRoleCredentialsProvider)
                .build();
    }

    @Bean
    @Named("sqsQueueURL")
    public String queueUrl(@Autowired SqsClient sqsClient) {
        try {
            GetQueueUrlRequest queueUrlRequest = GetQueueUrlRequest.builder()
                    .queueName(queueName)
                    .build();

            return sqsClient.getQueueUrl(queueUrlRequest).queueUrl();
        } catch (Exception e) {
            throw new SqsEventException("Error in generation of queue url", e);
        }
    }

    @Bean
    public SqsAsyncClient sqsAsyncClient(@Autowired StsAssumeRoleCredentialsProvider credentialsProvider) {
        return SqsAsyncClient.builder()
                .region(Region.of(region))
                .credentialsProvider(credentialsProvider)
                .build();
    }

    @Bean
    public SqsMessageListenerContainerFactory<Object> defaultSqsListenerContainerFactory(@Autowired SqsAsyncClient sqsAsyncClient) {
        return SqsMessageListenerContainerFactory.builder()
                .sqsAsyncClient(sqsAsyncClient)
                .build();
    }

}
