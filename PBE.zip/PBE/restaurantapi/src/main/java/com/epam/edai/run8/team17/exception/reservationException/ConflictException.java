package com.epam.edai.run8.team17.exception.reservationException;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}

