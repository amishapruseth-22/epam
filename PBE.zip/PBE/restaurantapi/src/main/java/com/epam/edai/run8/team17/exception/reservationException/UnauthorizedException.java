package com.epam.edai.run8.team17.exception.reservationException;

public class UnauthorizedException extends RuntimeException {
    public UnauthorizedException(String message) {
        super(message);
    }
}
