package com.epam.edai.run8.team17.dto;

import com.epam.edai.run8.team17.model.Feedback;
import lombok.Data;

@Data
public class FeedbackUpdate {
    private Feedback feedback;
    private Feedback previousFeedback;
}
