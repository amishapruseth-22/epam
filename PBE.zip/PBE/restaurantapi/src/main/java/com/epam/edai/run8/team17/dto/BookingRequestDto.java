package com.epam.edai.run8.team17.dto;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookingRequestDto {

    @NotNull
    @JsonProperty("locationId")
    private String locationId;

    @NotNull
    @JsonProperty("tableNumber")
    private String tableId;

    @NotNull
    @JsonProperty("date")
    private String date;

    @NotNull
    @JsonProperty("timeFrom")
    @Pattern(regexp = "\\d{2}:\\d{2}", message = "Enter a valid Time in the Format HH:mm")
    private String timeFrom;

    @NotNull
    @JsonProperty("timeTo")
    @Pattern(regexp = "\\d{2}:\\d{2}", message = "Enter a valid Time in the Format HH:mm")
    private String timeTo;

    @NotNull
    @JsonProperty("guestsNumber")
    private String guestsNumber;

    @JsonIgnore
    private String userEmail;
}

