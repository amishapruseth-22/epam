package com.epam.edai.run8.team17.dto;

import lombok.Data;

@Data
public class FeedbackModificationDto {
    private String feedbackId;
    private String cuisineComment;
    private String serviceComment;
    private String serviceRating;
    private String cuisineRating;
}
