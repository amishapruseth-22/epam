package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.model.Waiter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.*;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import java.util.*;
import java.util.stream.Collectors;

@Repository
@Slf4j
public class WaiterRepository {

    private final DynamoDbEnhancedClient enhancedClient;
    private final String waiterTable;

    @Autowired
    public WaiterRepository(DynamoDbEnhancedClient enhancedClient,
                            @Value("${dynamodb.tables.waiter}") String waiterTable) {
        this.enhancedClient = enhancedClient;
        this.waiterTable = waiterTable;
    }

    private DynamoDbTable<Waiter> getTable() {
        return enhancedClient.table(waiterTable, TableSchema.fromBean(Waiter.class));
    }

    public List<Waiter> getWaitersByLocation(String locationId) {
        // Scan the entire table
        List<Waiter> allWaiters = new ArrayList<>();
        getTable().scan().items().forEach(allWaiters::add);

        log.info(allWaiters.toString());

        // Filter in memory
        return allWaiters.stream()
                .filter(waiter -> waiter.getLocationId().equalsIgnoreCase(locationId) && waiter.isActive())
                .collect(Collectors.toList());
    }

    public Optional<Waiter> getWaiterByIdAndLocationId(String waiterId, String locationId) {

        log.info(waiterId + " " + locationId);
        Key key = Key.builder()
                .partitionValue(waiterId)
                .sortValue(locationId)
                .build();

        return Optional.ofNullable(getTable().getItem(r -> r.key(key)));
    }

    public void updateTimeSlotForWaiterWithId(String waiterId, String locationId, String date, String newTimeSlot) {
        Waiter waiter = getWaiterByIdAndLocationId(waiterId, locationId)
                .orElseThrow(() -> new RuntimeException("Waiter not found"));

        Map<String, List<String>> booked = waiter.getBooked();
        if (booked == null) {
            booked = new HashMap<>();
        }

        booked.computeIfAbsent(date, d -> new ArrayList<>()).add(newTimeSlot);
        waiter.setBooked(booked);
        getTable().updateItem(waiter);
    }

    public void removeTimeSlotFromWaiter(String waiterId, String locationId, String date, String timeSlot) {
        Waiter waiter = getWaiterByIdAndLocationId(waiterId, locationId)
                .orElseThrow(() -> new RuntimeException("Waiter not found"));

        Map<String, List<String>> booked = waiter.getBooked();
        if (booked != null && booked.containsKey(date)) {
            List<String> slots = booked.get(date);
            slots.remove(timeSlot);
            if (slots.isEmpty()) {
                booked.remove(date);
            } else {
                booked.put(date, slots);
            }
            waiter.setBooked(booked);
            getTable().updateItem(waiter);
        }
    }

    public int getTimeSlotIndex(String waiterId, String locationId, String date, String timeSlot) {
        return getWaiterByIdAndLocationId(waiterId, locationId)
                .map(waiter -> {
                    List<String> slots = waiter.getBooked() != null ? waiter.getBooked().get(date) : null;
                    if (slots != null) {
                        return slots.indexOf(timeSlot);
                    }
                    return -1;
                }).orElse(-1);
    }

    public boolean doesWaiterExistWithIdAndLocationId(String waiterId, String locationId) {
        return getWaiterByIdAndLocationId(waiterId, locationId).isPresent();
    }

    public Waiter getWaiterById(String waiterId) {
        return getTable()
                .scan()
                .items()
                .stream()
                .filter(waiter -> waiter.getId().equalsIgnoreCase(waiterId))
                .findFirst()
                .orElse(null);
    }
}
