package com.epam.edai.run8.team17.dto;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PutUsersProfileRequest {

    private String base64encodedImage;
    private String firstName;
    private String lastName;
}
