package com.epam.edai.run8.team17.service;

import com.amazonaws.services.kms.model.ConflictException;
import com.epam.edai.run8.team17.dto.WaiterBookingDTO;
import com.epam.edai.run8.team17.exception.ForbiddenException;
import com.epam.edai.run8.team17.exception.NotFoundException;
import com.epam.edai.run8.team17.model.Booking;
import com.epam.edai.run8.team17.model.Table;
import com.epam.edai.run8.team17.model.Waiter;
import com.epam.edai.run8.team17.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;



import java.util.List;
import java.util.Map;

import com.epam.edai.run8.team17.dto.ReservationByWaiterDTO;


@Service
@RequiredArgsConstructor
@Slf4j
public class ReservationService {
    private final BookingService bookingService;
    private final EmployeeRepository employeeRepository;
    private final WaiterRepository waiterRepository;
    private final TableRepository tableRepository;
    private final LocationService locationService;
    private final UserRepository userRepository;


    public ReservationByWaiterDTO bookTable(String email, WaiterBookingDTO waiterBookingDTO, String id) {
        String date = waiterBookingDTO.getDate();
        String from = waiterBookingDTO.getTimeFrom();
        String to = waiterBookingDTO.getTimeTo();
        Booking booking = new Booking();
        boolean flag = false;

        String waiterId = employeeRepository.getWaiterIdFromEmail(email);
        String locationId = employeeRepository.getLocationIdFromEmail(email);
        if (waiterAvailableOnDateAndTime(waiterId, date, from, to) && tableAvailableOnDateAndTime(waiterBookingDTO.getTableNumber(), date, from, to)) {
            if (waiterBookingDTO.getClientType().equalsIgnoreCase("visitor")) {
                booking = bookingService.makeBookingForVisitor(waiterBookingDTO, waiterId, id, locationId);
            } else if (waiterBookingDTO.getClientType().equalsIgnoreCase("customer")) {
                booking = bookingService.makeBookingForCustomer(waiterBookingDTO, waiterId, id, locationId);
                flag = true;
            } else {
                throw new ForbiddenException("Not allowed");
            }
        }

        waiterRepository.updateTimeSlotForWaiterWithId(waiterId, booking.getLocationId(), booking.getDate(), booking.getTimeFrom() + "-" + booking.getTimeTo());
        tableRepository.updateTimeSlotForTableWithId(booking.getTableId(), booking.getLocationId(), booking.getDate(), booking.getTimeFrom() + "-" + booking.getTimeTo());

        return convertToDTO(booking, flag, email);
    }

    private ReservationByWaiterDTO convertToDTO(Booking booking, boolean flag, String waiterEmail) {
        ReservationByWaiterDTO dto = new ReservationByWaiterDTO();
        dto.setDate(booking.getDate());
        dto.setGuestsNumber(booking.getGuestsNumber());
        dto.setId(booking.getReservationId());
        dto.setLocationAddress(locationService.getLocationAddressById(booking.getLocationId()));
        dto.setStatus(booking.getStatus());
        dto.setTableNumber(booking.getTableId());
        dto.setFeedbackId(booking.getFeedbackId());
        dto.setTimeSlot(booking.getTimeFrom() + "-" + booking.getTimeTo());
        if (flag) {
            dto.setUserInfo("Customer " + userRepository.getByName(booking.getUserEmail()));
        } else {
            dto.setUserInfo("Waiter " + employeeRepository.getName(waiterEmail));
        }

        return dto;
    }

    private boolean tableAvailableOnDateAndTime(String tableNumber, String date, String from, String to) {
        log.info("TableNumber: "+tableNumber);
        Table table = tableRepository.getTableById(tableNumber);
        if (table == null) {
            throw new NotFoundException("Table not found");
        }

        Map<String, List<String>> booked = table.getBooked();

        if (booked != null && booked.containsKey(date) && booked.get(date).contains(from + "-" + to)) {
            throw new ConflictException("Reservation Already at that time and date");
        }


        return true;

    }

    private boolean waiterAvailableOnDateAndTime(String waiterId, String date, String from, String to) {
        Waiter waiter = waiterRepository.getWaiterById(waiterId);
        if (waiter == null) {
            throw new NotFoundException("Waiter Not found");
        }

        Map<String, List<String>> booked = waiter.getBooked();

        if (booked != null && booked.containsKey(date) && booked.get(date).contains(from + "-" + to)) {
            throw new ConflictException("Reservation at that date and time already exists");
        }


        return true;
    }
}