package com.epam.edai.run8.team17.utils;

import com.epam.edai.run8.team17.dto.PutUsersProfileRequest;
import com.epam.edai.run8.team17.exception.CredentialsInvalidException;

public class PutUserProfileRequestValidator {
    public static void validate(PutUsersProfileRequest putUsersProfileRequest) {

        if (putUsersProfileRequest.getFirstName() == null) {
            throw new CredentialsInvalidException("First name is required.");
        }

        if (putUsersProfileRequest.getFirstName().trim().isEmpty()) {
            throw new CredentialsInvalidException("First name cannot be empty.");
        }

        if (putUsersProfileRequest.getLastName() == null) {
            throw new CredentialsInvalidException("Last name is required.");
        }

        if (putUsersProfileRequest.getLastName().trim().isEmpty()) {
            throw new CredentialsInvalidException("Last name cannot be empty.");
        }

        if (putUsersProfileRequest.getBase64encodedImage() == null) {
            throw new CredentialsInvalidException("Base64 encoded image cannot be null.");
        }

        if (!isValidBase64(putUsersProfileRequest.getBase64encodedImage())) {
            throw new CredentialsInvalidException("Base64 encoded image is invalid.");
        }
    }

    private static boolean isValidBase64(String base64String) {
        try {
            java.util.Base64.getDecoder().decode(base64String);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
