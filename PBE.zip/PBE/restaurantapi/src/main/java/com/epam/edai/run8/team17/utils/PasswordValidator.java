package com.epam.edai.run8.team17.utils;

import com.epam.edai.run8.team17.exception.CredentialsInvalidException;
import org.springframework.stereotype.Component;

@Component
public class PasswordValidator {

    private static final int MIN_LENGTH = 8;
    private static final int MAX_LENGTH = 16;

    public static void validatePassword(String password) {

        if (password.length() < 8) {
            throw new CredentialsInvalidException("Password must be at least 8 characters.");
        }

        if (password.length() > 16) {
            throw new CredentialsInvalidException("Password must be at most 16 characters.");
        }

        if (!password.matches(".*[a-z].*")) {
            throw new CredentialsInvalidException("Password must contain lowercase letters.");
        }

        if (!password.matches(".*[A-Z].*")) {
            throw new CredentialsInvalidException("Password must contain uppercase letters.");
        }

        if (!password.matches(".*\\d.*")) {
            throw new CredentialsInvalidException("Password must contain at least one number.");
        }

        if (!password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
            throw new CredentialsInvalidException("Password must contain special characters.");
        }

    }

}