package com.epam.edai.run8.team17.utils;

import lombok.RequiredArgsConstructor;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class Base64ImageHandler {

    @Value("${aws.s3.profileImageBucket}")
    private final String S3_BUCKET_NAME;

    private final S3Client s3Client;
    private final S3Presigner s3Presigner;

    private final Logger logger = LoggerFactory.getLogger(Base64ImageHandler.class);

    public String handleBase64Image(String base64Image) {
        String fileName = uploadBase64ImageToS3(base64Image);
        return  generatePresignedUrl(fileName);
    }

    private String uploadBase64ImageToS3(String base64Image) {
        try {
            logger.info("upload base 64 image to s3...");

            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            logger.info("image in bytes: {}", imageBytes);

            String fileName = UUID.randomUUID().toString() + ".jpg"; // Assuming the image is a JPEG
            logger.info("image file name: {}", fileName);

            Map<String, String> metadata = new HashMap<>();
            metadata.put("Content-Type", "image/jpeg"); // Adjust based on the image type
            metadata.put("Content-Length", String.valueOf(imageBytes.length));
            logger.info("put object request: {}", metadata);

            // Upload the image to S3
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(S3_BUCKET_NAME)
                    .key(fileName)
                    .contentType("image/jpeg")
                    .metadata(metadata)
                    .build();

            PutObjectResponse putObjectResponse = s3Client.putObject(putObjectRequest, RequestBody.fromBytes(imageBytes));

            logger.info("put object response: {}", putObjectResponse);
            return fileName;

        } catch (Exception e) {
            logger.error(e.toString());
            throw new RuntimeException(e.getMessage());
        }
    }

    private String generatePresignedUrl(String fileName) {
        // Create an S3Presigner instance
        try {
            // Generate the pre-signed URL with 12 hours expiration
            GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder()
                    .signatureDuration(Duration.ofHours(12))
                    .getObjectRequest(req -> req.bucket(S3_BUCKET_NAME).key(fileName))
                    .build();

            PresignedGetObjectRequest presignedGetObjectRequest = s3Presigner.presignGetObject(getObjectPresignRequest);

            return presignedGetObjectRequest.url().toString();
        } catch (Exception e) {
            logger.error(e.toString());
            throw new RuntimeException(e.getMessage());
        }
    }

}
