package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.exception.NotFoundException;
import com.epam.edai.run8.team17.model.Table;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import java.util.*;

@Repository
@RequiredArgsConstructor
public class TableRepository {

    private final DynamoDbTable<Table> dynamoDbTable;


    public Optional<Table> getTableByIdAndLocationId(String tableId, String locationId) {
        return Optional.ofNullable(dynamoDbTable.getItem(r -> r.key(
                Key.builder().partitionValue(tableId).sortValue(locationId).build()
        )));
    }


    public Table getTableDataById(String tableId, String locationId) {
        Key key = Key.builder()
                .partitionValue(tableId)
                .sortValue(locationId)
                .build();
        return dynamoDbTable.getItem(r -> r.key(key));
    }

    public boolean doesTableExist(String tableId, String locationId) {
        return getTableByIdAndLocationId(tableId, locationId).isPresent();
    }

    /**
     * Fetches all tables for a specific location ID.
     */
    public List<Table> getTablesByLocationId(String locationId) {
        return dynamoDbTable.scan()
                .items()
                .stream()
                .filter(table -> locationId.equals(table.getLocationId())) // In-memory filtering
                .toList();
    }

    /**
     * Updates a booked time slot for a specific table.
     */
    public void updateTimeSlotForTable(String tableId, String locationId, String date, String newTimeSlot) {
        getTableByIdAndLocationId(tableId, locationId).ifPresent(table -> {
            table.getBooked()
                    .computeIfAbsent(date, k -> new ArrayList<>()) // Add date if not present
                    .add(newTimeSlot); // Add time slot
            dynamoDbTable.updateItem(table); // Persist changes
        });
    }

    public void updateTimeSlotForTableWithId(String tableId, String locationId, String date, String newTimeSlot) {

        Table item = getTableDataById(tableId, locationId);

        if (item == null) {
            throw new NotFoundException("Table not found");
        }

        Map<String, List<String>> booked = item.getBooked();
        if (booked == null) {
            booked = new HashMap<>();
        }

        booked.computeIfAbsent(date, k -> new ArrayList<>()).add(newTimeSlot);
        item.setBooked(booked);

        getTable().updateItem(item);
    }
    /**
     * Fetches booked time slots for a specific table.
     */
    public Map<String, List<String>> getBookedTimeSlots(String tableId, String locationId) {
        return getTableByIdAndLocationId(tableId, locationId)
                .map(Table::getBooked)
                .orElse(Collections.emptyMap()); // Return empty map if no bookings
    }

    public int getTimeSlotIndex(String tableId, String locationId, String date, String timeSlot) {
        Table item = getTableDataById(tableId, locationId);

        if (item == null || item.getBooked() == null || !item.getBooked().containsKey(date)) {
            return -1;
        }

        List<String> slots = item.getBooked().get(date);
        return slots.indexOf(timeSlot);
    }

    /**
     * Removes a booked time slot for a specific table.
     */
    public void removeTimeSlotFromTable(String tableId, String locationId, String date, String timeSlot) {
        getTableByIdAndLocationId(tableId, locationId).ifPresent(table -> {
            List<String> bookedSlots = table.getBooked().getOrDefault(date, new ArrayList<>());
            if (bookedSlots.remove(timeSlot) && bookedSlots.isEmpty()) {
                table.getBooked().remove(date); // Remove date if no slots remain
            }
            dynamoDbTable.updateItem(table); // Persist changes
        });
    }

    public Table getTableById(String tableNumber) {
        DynamoDbTable<Table> table = getTable();
        List<Table> tables = new ArrayList<>();
        table.scan().items().forEach(tables::add);

        return tables.stream()
                .filter(t -> t.getId().equalsIgnoreCase(tableNumber))
                .findFirst()
                .orElse(null);
    }

    public DynamoDbTable<Table> getTable() {
        return dynamoDbTable;
    }

    public int getNumberOfGuestsForTableWithIdAndLocationId(String tableId, String locationId) {
        Table table = getTableDataById(tableId, locationId);

        if (table == null) {
            throw new NotFoundException("Table not found for ID: " + tableId + " and location: " + locationId);
        }

        return Integer.parseInt(table.getCapacity());
    }

    /**
     * Fetches the number of guests a table can accommodate.
     */
    public String getNumberOfGuestsForTable(String tableId, String locationId) {
        return getTableByIdAndLocationId(tableId, locationId)
                .map(Table::getCapacity)
                .orElseThrow(() -> new RuntimeException("Table not found for ID: " + tableId + " and location: " + locationId));
    }
}