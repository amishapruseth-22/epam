package com.epam.edai.run8.team17.exception;

public class FeedbackEventsException extends RuntimeException{

    public FeedbackEventsException(String message) {
        super(message);
    }

    public FeedbackEventsException(String message, Throwable cause) {
        super(message, cause);
    }

    public FeedbackEventsException(Throwable cause) {
        super(cause);
    }

    public FeedbackEventsException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
