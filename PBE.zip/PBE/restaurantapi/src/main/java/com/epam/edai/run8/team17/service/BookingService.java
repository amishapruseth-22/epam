package com.epam.edai.run8.team17.service;


import com.epam.edai.run8.team17.dto.BookingRequestDto;
import com.epam.edai.run8.team17.dto.ReservationDto;
import com.epam.edai.run8.team17.dto.WaiterBookingDTO;
import com.epam.edai.run8.team17.dto.WaiterReservationDto;
import com.epam.edai.run8.team17.exception.NotFoundException;
import com.epam.edai.run8.team17.exception.authException.BadRequestException;
import com.epam.edai.run8.team17.exception.reservationException.ConflictException;
import com.epam.edai.run8.team17.exception.reservationException.UnauthorizedException;
import com.epam.edai.run8.team17.model.Booking;
import com.epam.edai.run8.team17.repository.BookingRepository;
import com.epam.edai.run8.team17.repository.EmployeeRepository;
import jakarta.validation.ValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.function.UnaryOperator;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookingService {
    public static final String RESERVED = "RESERVED";
    public static final String CANCELLED = "CANCELLED";
    public static final String NO_FEEDBACK = "no_feedback";
    public static final String TIME_FROM = "timeFrom";
    public static final String TIME_TO = "timeTo";
    private final BookingRepository bookingRepository;
    private final TableService tableService;
    private final LocationService locationService;
    private final WaiterService waiterService;
    private final EmployeeRepository employeeRepository;
    private final UserService userService;


    // Existing methods remain unchanged
    public List<ReservationDto> getListReservationDto(String email) {
        log.info("Fetching reservations for email: " + email);
        if (email == null) {
            log.error("Authentication failed: email is null");
            throw new UnauthorizedException("Authentication required");
        }

        List<Booking> reservations = bookingRepository.getBookingsByEmail(email);
        log.info("Found " + reservations.size() + " reservations for email: " + email);
        return reservations.stream().map(this::toReservationDto).toList();
    }

    public ReservationDto toReservationDto(Booking booking) {
        if (booking == null) {
            return null;
        }

        ReservationDto reservationDto = new ReservationDto();
        try {
            UnaryOperator<String> locationIdToLocationAddress = locationService::getLocationAddressById;

            reservationDto.setId(booking.getReservationId()); // Assuming `Booking` has `getReservationId()`
            reservationDto.setLocationAddress(locationIdToLocationAddress.apply(booking.getLocationId())); // Assuming `Booking` has `getLocationId()`
            reservationDto.setDate(booking.getDate()); // Assuming `Booking` has `getDate()`

            // Build time slot from fields `timeFrom` and `timeTo`
            String timeFrom = booking.getTimeFrom(); // Assuming `Booking` has `getTimeFrom()`
            String timeTo = booking.getTimeTo(); // Assuming `Booking` has `getTimeTo()`
            reservationDto.setTimeSlot(timeFrom + "-" + timeTo);

            reservationDto.setGuestsNumber(String.valueOf(booking.getGuestsNumber())); // Assuming `guestsNumber` is an integer
            reservationDto.setStatus(booking.getStatus()); // Assuming `Booking` has `getStatus()`

            // Handle `preOrder`: Set to "N/A" or exclude this if Booking doesn't have an equivalent
            reservationDto.setPreOrder("N/A");

            reservationDto.setFeedbackId(booking.getFeedbackId()); // Assuming `Booking` has `getFeedbackId()`
            reservationDto.setWaiterName(employeeRepository.getNameFromId(booking.getWaiterId())); // Assuming `Booking` has `getWaiterId()`
            reservationDto.setWaiterRating("4.7"); // Static/hardcoded rating or replace with dynamic logic

            return reservationDto;
        } catch (Exception e) {
            log.error("Error converting booking to DTO: " + e.getMessage());
            throw new IllegalArgumentException("Invalid booking data: " + e.getMessage());
        }
    }

    public void deleteReservationWithId(String reservationId, String email, boolean isWaiter) {
        log.info("reservation_id: " + reservationId + " email: " + email + " in deleteMethod");

        if (email == null) {
            throw new UnauthorizedException("Authentication required");
        }

        // Get reservation based on access type
        Booking reservation = null;

        verifyBookingWithId(reservationId);

        if (isWaiter) {
            verifyBookingWithId(reservationId);
            reservation = getBooking(reservationId);
        } else {
            verifyUserAccess(reservationId, email);
            reservation = getBookingByIdAndEmail(reservationId, email);
        }

        validateReservationStatus(reservation);

        if (!isWaiter) {
            validateCancellationTimeLimit(reservation);
        }

        processCancellation(reservation);
    }

    private void validateReservationStatus(Booking booking) {
        if (CANCELLED.equals(booking.getStatus())) {
            throw new IllegalStateException("Reservation is already cancelled.");
        }
    }

    private void validateCancellationTimeLimit(Booking booking) {

        String reservationDate = booking.getDate(); // Access reservation date from Booking
        String reservationTimeFrom = booking.getTimeFrom(); // Access reservation time from Booking

        if (!canCancelReservation(reservationDate, reservationTimeFrom)) {
            throw new ValidationException("Reservations can only be canceled up to 30 minutes before the reservation time.");
        }
    }

    private void verifyUserAccess(String reservationId, String userEmail) {
        log.info("reservation_id: " + reservationId + " email: " + userEmail + " in VerifyUserAccess Method");

        if (!bookingRepository.doesBookingExistForUserWithEmailAndId(reservationId, userEmail)) {
            throw new UnauthorizedException("User can only cancel their own reservations");
        }
    }

    private void processCancellation(Booking booking) {
        try {
            log.info("IN processCancellation booking: " + booking);

            // Extract fields directly from Booking object
            String reservationId = booking.getReservationId();
            String tableId = booking.getTableId();
            String locationId = booking.getLocationId();
            String waiterId = booking.getWaiterId();
            String reservationDate = booking.getDate();
            String timeSlot = booking.getTimeFrom() + "-" + booking.getTimeTo();
            log.info("before email");
            String email = booking.getUserEmail(); // Assuming Booking has getUserEmail() method
            log.info("after email");

            // 1. Cancel the reservation
            bookingRepository.deleteUserBookingWithId(reservationId, email);
            log.info("After deleteReservationWithId");

            // 2. Remove time slot from table's schedule
            removeTimeSlotFromTable(tableId, locationId, reservationDate, timeSlot);
            log.info("after table time slot removal");

            // 3. Remove time slot from waiter's schedule
            removeTimeSlotFromWaiter(waiterId, locationId, reservationDate, timeSlot);
            log.info("after waiter time slot removal");
        } catch (Exception e) {
            e.printStackTrace();
            throw new ValidationException("Failed to cancel reservation: " + e.getMessage());
        }
    }

    public void verifyBookingWithId(String reservationId) {
        if (!bookingRepository.doesBookingExist(reservationId))
            throw new IllegalArgumentException("Booking with the Id: " + reservationId + " does not exists!");
    }

    private void removeTimeSlotFromTable(String tableId, String locationId, String date, String timeSlot) {
        try {
            tableService.removeTimeSlotFromTable(tableId, locationId, date, timeSlot);
        } catch (Exception e) {
            log.error("Error updating table schedule: " + e.getMessage());
            throw new ValidationException("Failed to update table schedule", e);
        }
    }

    private void removeTimeSlotFromWaiter(String waiterId, String locationId, String date, String timeSlot) {
        try {

            waiterService.removeTimeSlot(waiterId, locationId, date, timeSlot);
        } catch (Exception e) {
            log.error("Error updating waiter schedule: " + e.getMessage());
            throw new ValidationException("Failed to update waiter schedule", e);
        }
    }

    private boolean canCancelReservation(String date, String timeFrom) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
            LocalDateTime reservationDateTime = LocalDateTime.parse(date + "T" + timeFrom, formatter);

            LocalDateTime currentTime = LocalDateTime.now(ZoneId.of("Asia/Kolkata")).truncatedTo(ChronoUnit.MINUTES);

            log.info("Reservation time: " + reservationDateTime);
            log.info("Current time (IST): " + currentTime);

            long minutesUntilReservation = ChronoUnit.MINUTES.between(currentTime, reservationDateTime);
            return minutesUntilReservation > 30;
        } catch (Exception e) {
            log.error("Error parsing date/time: " + e.getMessage());
            return false;
        }
    }

    // New methods for existence and logical validation
    public void validateExistenceAndLogicalConstraints(BookingRequestDto booking) {

        validateBookingConstraints(booking);
        log.info("Before table val");
        validateTableAndLocationExistence(booking.getTableId(), booking.getLocationId());
        log.info("After Table val");
        validateTableLogicalConstraints(booking);
    }

    private void validateTableAndLocationExistence(String tableId, String locationId) {
        if (locationService.doesLocationExist(locationId)) {
            throw new NotFoundException("Location not found: " + locationId);
        }

        if (!tableService.doesTableExistsWithIdAndLocationId(tableId, locationId)) {
            throw new NotFoundException("Table not found: " + tableId + " in location: " + locationId);
        }

        log.info("Table Existence validation done");
    }

    private void validateTableLogicalConstraints(BookingRequestDto booking) {
        log.info("Validating logical constraints for booking");

        if (!tableService.isTableAvailableForBooking(booking.getTableId(), booking.getLocationId(), booking.getDate(), booking.getTimeFrom(), booking.getTimeTo())) {
            log.error("Table double booking attempt - Table: " + booking.getTableId() + ", Date: " + booking.getDate() + ", Time: " + booking.getTimeFrom() + "-" + booking.getTimeTo());
            throw new ConflictException("Table is already booked for this time slot");
        }

        tableService.verifyTableCanAccommodateGuestsWithIdAndLocationId(booking.getTableId(), booking.getLocationId(), booking.getGuestsNumber());


        log.info("Logical constraints validation passed");
    }

    public void validateBookingConstraints(BookingRequestDto booking) {
        try {
            validateGuestCount(booking.getGuestsNumber());
            validateDateTime(booking.getDate(), booking.getTimeFrom(), booking.getTimeTo());
        } catch (Exception e) {
            throw new ValidationException("Invalid booking details: " + e.getMessage());
        }

        log.info("Booking constraints validation completed");
    }

    private void validateGuestCount(String guestsNumber) {
        int guests = Integer.parseInt(guestsNumber);
        if (guests < 1 || guests > 20) {
            throw new ValidationException("Invalid party size (must be between 1 and 20)");
        }
    }

    private void validateDateTime(String date, String timeFrom, String timeTo) {
        LocalDate bookingDate = LocalDate.parse(date);
        LocalTime bookingTime = LocalTime.parse(timeFrom);
        LocalTime endTime = LocalTime.parse(timeTo);

        if (bookingTime.isAfter(endTime) || bookingTime.equals(endTime)) {
            throw new ValidationException("End time must be after start time");
        }

        if (bookingDate.atTime(bookingTime).isBefore(LocalDateTime.now())) {
            throw new ValidationException("Cannot book for past date/time");
        }
    }

    public ReservationDto createReservation(BookingRequestDto bookingRequestDto, String reservationId) {
        log.info("bookingRequestDto: " + bookingRequestDto);

        // Validate business rules
        validateExistenceAndLogicalConstraints(bookingRequestDto);
        log.info("All validations in creation are done");

        // Assign waiter
        String waiterId = assignWaiter(bookingRequestDto);
        log.info("Assigned waiter ID: " + waiterId);

        // Create and save booking
        Booking booking = createBookingObject(bookingRequestDto, reservationId, waiterId);
        Booking savedBooking = saveBooking(booking, reservationId);

        // Update schedules
        updateSchedules(waiterId, bookingRequestDto);

        log.info("Completed all updates for reservation: " + reservationId);
        return toReservationDto(savedBooking);
    }

    private String assignWaiter(BookingRequestDto bookingRequestDto) {
        return waiterService.getLeastBusyWaiter(bookingRequestDto.getLocationId(), bookingRequestDto.getDate(), bookingRequestDto.getTimeFrom(), bookingRequestDto.getTimeTo());
    }

    private Booking createBookingObject(BookingRequestDto bookingRequestDto, String reservationId, String waiterId) {
        Booking booking = new Booking();
        booking.setReservationId(reservationId);
        booking.setUserEmail(bookingRequestDto.getUserEmail());
        booking.setTableId(bookingRequestDto.getTableId());
        booking.setLocationId(bookingRequestDto.getLocationId());
        booking.setDate(bookingRequestDto.getDate());
        booking.setTimeFrom(bookingRequestDto.getTimeFrom());
        booking.setTimeTo(bookingRequestDto.getTimeTo());
        booking.setGuestsNumber(bookingRequestDto.getGuestsNumber());
        booking.setWaiterId(waiterId);
        booking.setStatus(RESERVED);
        booking.setByCustomer(true);
        booking.setFeedbackId(NO_FEEDBACK);
        return booking;
    }

    private Booking saveBooking(Booking booking, String reservationId) {
        log.info("Inserting booking into repository...");
        Booking savedBooking = bookingRepository.createBooking(booking);
        log.info("Successfully created reservation: " + reservationId);
        return savedBooking;
    }

    private void updateSchedules(String waiterId, BookingRequestDto bookingRequestDto) {
        log.info("Updating waiter schedule - Waiter: " + waiterId);
        updateWaiterSchedule(waiterId, bookingRequestDto);

        log.info("Updating table schedule - Table: " + bookingRequestDto.getTableId());
        updateTableSchedule(bookingRequestDto);
    }

    private void updateWaiterSchedule(String waiterId, BookingRequestDto booking) {
        try {
            waiterService.updateTimeSlotForWaiterWithIdAndLocationId(waiterId, booking.getLocationId(), booking.getDate(), booking.getTimeFrom() + "-" + booking.getTimeTo());
        } catch (Exception e) {
            log.error("Error updating waiter schedule: " + e.getMessage());
            throw new BadRequestException("Failed to update waiter schedule for waiter");
        }
    }

    private void updateTableSchedule(BookingRequestDto booking) {
        try {
            tableService.updateTimeSlotForTableWithIdAndLocationId(booking.getTableId(), booking.getLocationId(), booking.getDate(), booking.getTimeFrom() + "-" + booking.getTimeTo());
        } catch (Exception e) {
            log.error("Error updating table schedule: " + e.getMessage());
            throw new BadRequestException("Failed to update table schedule for table");
        }
    }

    public ReservationDto updateBookingDateAndTimeWithId(String bookingId, String userEmail, Map<String, String> bodyMap, boolean isWaiter) {
        // Validate the update body map
        if (bodyMap.isEmpty()) {
            throw new IllegalArgumentException("The update process must have at least one field to modify!");
        }
        if (bodyMap.containsKey(TIME_FROM) ^ bodyMap.containsKey(TIME_TO)) {
            throw new IllegalArgumentException("timeFrom and timeTo must be updated together");
        }

        // Fetch existing booking based on user type
        Booking existingBooking = !isWaiter ? getBookingByIdAndEmail(bookingId, userEmail) : getBooking(bookingId);


        log.info("Existing Booking: %s%n", existingBooking);

        // Validate the reservation status
        if (CANCELLED.equals(existingBooking.getStatus())) {
            throw new ValidationException("Reservation is already cancelled.");
        }

        // Prevent locationId and tableNumber updates for non-waiter users
        if (!isWaiter && (bodyMap.containsKey("locationId") || bodyMap.containsKey("tableNumber"))) {
            throw new ValidationException("Cannot change location or table for an existing booking. Please cancel and rebook.");
        }

        // Update mutable fields in the existing booking
        if (bodyMap.containsKey("date")) {
            existingBooking.setDate(bodyMap.get("date"));
        }
        if (bodyMap.containsKey(TIME_FROM)) {
            existingBooking.setTimeFrom(bodyMap.get(TIME_FROM));
        }
        if (bodyMap.containsKey(TIME_TO)) {
            existingBooking.setTimeTo(bodyMap.get(TIME_TO));
        }
        if (bodyMap.containsKey("guestsNumber")) {
            existingBooking.setGuestsNumber(bodyMap.get("guestsNumber")); // Assuming guestsNumber is a valid integer
        }

        // Save the updated booking
        bookingRepository.saveBooking(existingBooking);

        log.info("Updated Booking: %s%n", existingBooking);

        // Convert updated booking to ReservationDto and return
        return toReservationDto(existingBooking);
    }

    private BookingRequestDto convertToBookingRequestDto(Booking booking) {

        BookingRequestDto bookingRequestDto = new BookingRequestDto();
        bookingRequestDto.setLocationId(booking.getLocationId());
        bookingRequestDto.setTableId(booking.getTableId());
        bookingRequestDto.setDate(booking.getDate());
        bookingRequestDto.setTimeFrom(booking.getTimeFrom());
        bookingRequestDto.setTimeTo(booking.getTimeTo());
        bookingRequestDto.setGuestsNumber(booking.getGuestsNumber());
        bookingRequestDto.setUserEmail(booking.getUserEmail());
        return bookingRequestDto;
    }

    public ReservationDto updateBookingTableWithId(String bookingId, String tableId, String locationId) {
        // Fetch the booking
        Booking booking = getBooking(bookingId);

        // Update table and location details
        booking.setTableId(tableId);
        booking.setLocationId(locationId);

        BookingRequestDto bookingDto = convertToBookingRequestDto(booking);

        // Perform validation
        validateTableAndLocationExistence(bookingDto.getTableId(), bookingDto.getLocationId()); // Works with BookingDto
        validateTableLogicalConstraints(bookingDto);  // Works with BookingDto

        // Remove old time slot from table schedule
        removeTimeSlotFromTable(booking.getTableId(), booking.getLocationId(), booking.getDate(), booking.getTimeFrom() + "-" + booking.getTimeTo());

        // Update the new table's schedule
        updateTableSchedule(bookingDto);

        // Save the updated booking
        bookingRepository.saveBooking(booking);

        // Return the updated ReservationDto
        return toReservationDto(booking);
    }

    public List<WaiterReservationDto> getWaiterReservation(String email, String date, String time, String tableNumber) {
        String waiterID = employeeRepository.getWaiterIdFromEmail(email);
        log.info("Waiter id = {}", waiterID);
        log.info("Date: {}", date);

        List<Booking> bookings = filterBookingByTimeAndTable(bookingRepository.getBookingsByIdAndDate(waiterID, date), time, tableNumber);
        log.info("Filtered bookings: {}", bookings);

        String waiterName = userService.getNameByEmail(email); // Cache waiter name
        return bookings.stream().map(booking -> {
            String doneBy = booking.isByCustomer() ? "Customer " + userService.getNameByEmail(booking.getUserEmail()) : "Waiter " + waiterName;

            return new WaiterReservationDto(locationService.getLocationAddressById(booking.getLocationId()), booking.getTableId(), date, booking.getTimeFrom() + "-" + booking.getTimeTo(), doneBy, String.valueOf(booking.getGuestsNumber()), booking.getReservationId(), booking.getStatus(), waiterID);
        }).toList();
    }

    private List<Booking> filterBookingByTimeAndTable(List<Booking> bookings, String time, String tableNumber) {
        String startTime = time != null ? time.split("-")[0] : null;

        return bookings.stream().filter(booking -> startTime == null || booking.getTimeFrom().equalsIgnoreCase(startTime)).filter(booking -> tableNumber == null || booking.getTableId().equalsIgnoreCase(tableNumber)).toList();
    }

    public void updateBookings() {
        List<Booking> bookings = bookingRepository.getAllBookings();
        log.info("Fetched {} bookings for update", bookings.size());

        ZoneId zoneId = ZoneId.of("Asia/Kolkata");
        LocalDateTime now = LocalDateTime.now(zoneId);

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

        for (Booking booking : bookings) {
            try {
                if (CANCELLED.equalsIgnoreCase(booking.getStatus())) {
                    continue; // Skip cancelled bookings
                }

                LocalDateTime fromDateTime = LocalDateTime.of(LocalDate.parse(booking.getDate(), dateFormatter), LocalTime.parse(booking.getTimeFrom(), timeFormatter));
                LocalDateTime toDateTime = LocalDateTime.of(LocalDate.parse(booking.getDate(), dateFormatter), LocalTime.parse(booking.getTimeTo(), timeFormatter));

                if (toDateTime.isBefore(now)) {
                    booking.setStatus("FINISHED");
                } else if (!now.isBefore(fromDateTime) && !now.isAfter(toDateTime)) {
                    booking.setStatus("IN PROGRESS");
                } else {
                    continue; // Skip if no status change is needed
                }

                bookingRepository.saveBooking(booking);
                log.info("Updated booking ID: {} to status: {}", booking.getReservationId(), booking.getStatus());

            } catch (Exception e) {
                log.error("Error updating booking ID: {}", booking.getReservationId(), e);
            }
        }
    }

    public void setFeedbackIdWithId(String bookingId, String feedbackId) {
        Booking booking = getBooking(bookingId);
        booking.setFeedbackId(feedbackId);
        bookingRepository.saveBooking(booking);
    }

    private Booking getBooking(String bookingId) {
        verifyBookingWithId(bookingId);
        return bookingRepository.getBookingById(bookingId);

    }

    private Booking getBookingByIdAndEmail(String reservationId, String email) {
        validateUserBooking(reservationId, email);
        return bookingRepository.getBookingByIdAndEmail(reservationId, email);
    }

    private void validateUserBooking(String reservationId, String email) {
        if (!bookingRepository.doesBookingExistForUserWithEmailAndId(reservationId, email)) {
            throw new UnauthorizedException("User can only access their own reservations");
        }
    }

    public String getLocationIdByReservationId(String reservationId) {
        verifyBookingWithId(reservationId);
        return bookingRepository.getReservationLocationWithId(reservationId);
    }

    public Booking makeBookingForVisitor(WaiterBookingDTO waiterBookingDTO, String waiterId, String id, String locationId) {

        Booking booking = new Booking();

        booking.setReservationId(id);

        booking.setLocationId(locationId);

        booking.setTableId(waiterBookingDTO.getTableNumber());

        booking.setDate(waiterBookingDTO.getDate());

        booking.setWaiterId(waiterId);

        booking.setTimeFrom(waiterBookingDTO.getTimeFrom());

        booking.setTimeTo(waiterBookingDTO.getTimeTo());

        booking.setGuestsNumber(waiterBookingDTO.getGuestsNumber());

        booking.setUserEmail("dummy");

        booking.setByCustomer(false);

        booking.setStatus(RESERVED);

        booking.setFeedbackId(NO_FEEDBACK);

        bookingRepository.saveBooking(booking);

        return booking;

    }

    public Booking makeBookingForCustomer(WaiterBookingDTO waiterBookingDTO, String waiterId, String id, String locationId) {

        Booking booking = new Booking();

        booking.setReservationId(id);

        booking.setLocationId(locationId);

        booking.setTableId(waiterBookingDTO.getTableNumber());

        booking.setDate(waiterBookingDTO.getDate());

        booking.setWaiterId(waiterId);

        booking.setTimeFrom(waiterBookingDTO.getTimeFrom());

        booking.setTimeTo(waiterBookingDTO.getTimeTo());

        booking.setGuestsNumber(waiterBookingDTO.getGuestsNumber());

        booking.setUserEmail(waiterBookingDTO.getClientEmail());

        booking.setByCustomer(false);

        booking.setStatus(RESERVED);

        booking.setFeedbackId(NO_FEEDBACK);

        bookingRepository.saveBooking(booking);

        return booking;

    }


}

