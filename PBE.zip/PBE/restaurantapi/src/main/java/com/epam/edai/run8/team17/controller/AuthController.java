package com.epam.edai.run8.team17.controller;

import com.epam.edai.run8.team17.dto.AuthenticationResponse;
import com.epam.edai.run8.team17.dto.SignInRequest;
import com.epam.edai.run8.team17.dto.SignUpRequest;
import com.epam.edai.run8.team17.dto.SignUpResonse;
import com.epam.edai.run8.team17.exception.authException.EmptyEmailException;
import com.epam.edai.run8.team17.exception.authException.EmptyPasswordException;
import com.epam.edai.run8.team17.exception.authException.InvalidEmailException;
import com.epam.edai.run8.team17.service.AuthenticationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthenticationService authenticationService;

    @PostMapping("sign-up")
    public ResponseEntity<SignUpResonse> signUp(@RequestBody SignUpRequest request){
        SignUpResonse response = authenticationService.register(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("sign-in")
    public ResponseEntity<AuthenticationResponse> signIn(@RequestBody SignInRequest request) throws EmptyPasswordException, EmptyEmailException, InvalidEmailException {
        AuthenticationResponse response = authenticationService.authenticate(request);
        return ResponseEntity.ok(response);
    }
}