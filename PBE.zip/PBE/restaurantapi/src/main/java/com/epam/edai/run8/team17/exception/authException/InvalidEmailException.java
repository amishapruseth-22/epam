package com.epam.edai.run8.team17.exception.authException;

public class InvalidEmailException extends Exception {

    public InvalidEmailException(String message) {
        super(message);
    }
}
