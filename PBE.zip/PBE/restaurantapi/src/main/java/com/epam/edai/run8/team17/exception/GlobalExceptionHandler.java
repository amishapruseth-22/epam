package com.epam.edai.run8.team17.exception;

import com.epam.edai.run8.team17.exception.authException.*;
import com.epam.edai.run8.team17.exception.reservationException.ConflictException;
import com.epam.edai.run8.team17.exception.reservationException.ForbiddenException;
import com.epam.edai.run8.team17.exception.reservationException.NotFoundException;
import com.epam.edai.run8.team17.exception.reservationException.UnauthorizedException;
import jakarta.validation.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    private ResponseEntity<Object> createErrorResponse(HttpStatus status, String message, boolean isAuthError) {
        Map<String, Object> body = new HashMap<>();
        body.put("statusCode", status.value());
        body.put("message", message);
        return ResponseEntity.status(status).body(body);
    }

    @ExceptionHandler({UnauthorizedException.class, NotAuthorizedException.class,
            UserNotFoundException.class, CredentialsInvalidException.class})
    public ResponseEntity<Object> handleUnauthorized(Exception e) {
        return createErrorResponse(HttpStatus.UNAUTHORIZED, e.getMessage(), true);
    }

    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<Object> handleForbidden(ForbiddenException e) {
        return createErrorResponse(HttpStatus.FORBIDDEN, e.getMessage(), false);
    }

    @ExceptionHandler({NotFoundException.class, DishNotFoundException.class})
    public ResponseEntity<Object> handleNotFound(NotFoundException e) {
        return createErrorResponse(HttpStatus.NOT_FOUND, e.getMessage(), false);
    }

    @ExceptionHandler({ValidationException.class, IllegalArgumentException.class,
            EmptyPasswordException.class, EmptyEmailException.class,
            InvalidEmailException.class, BadRequestException.class})
    public ResponseEntity<Object> handleValidation(Exception e) {
        return createErrorResponse(HttpStatus.BAD_REQUEST, e.getMessage(), false);
    }

    @ExceptionHandler({ConflictException.class, UserAlreadyExists.class})
    public ResponseEntity<Object> handleConflict(ConflictException e) {
        return createErrorResponse(HttpStatus.CONFLICT, e.getMessage(), false);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleGeneral(Exception e, WebRequest request) {
        log.info("Exception type: " + e.getClass().getName());
        log.info("Exception message: " + e.getMessage());
        return createErrorResponse(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Internal server error: " + e.getClass().getSimpleName(),
                false
        );
    }
}


