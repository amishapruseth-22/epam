package com.epam.edai.run8.team17.utils;

import com.epam.edai.run8.team17.dto.SignUpRequest;
import com.epam.edai.run8.team17.exception.CredentialsInvalidException;
import org.springframework.stereotype.Component;

@Component
public class SignUpValidator {

    public static void validateSignUp(SignUpRequest signUp) {
        if (signUp.getFirstName() == null || signUp.getFirstName().trim().isEmpty()) {
            if (signUp.getFirstName() == null) {
                throw new CredentialsInvalidException("First name is required.");
            } else {
                throw new CredentialsInvalidException("First name cannot be empty.");
            }
        }

        if (signUp.getLastName() == null || signUp.getLastName().trim().isEmpty()) {
            if (signUp.getLastName() == null) {
                throw new CredentialsInvalidException("Last name is required.");
            } else {
                throw new CredentialsInvalidException("Last name cannot be empty.");
            }
        }

        if (signUp.getEmail() == null || signUp.getEmail().trim().isEmpty()) {
            if (signUp.getEmail() == null) {
                throw new CredentialsInvalidException("Email is required.");
            } else {
                throw new CredentialsInvalidException("Email cannot be empty.");
            }
        }

        if (!EmailValidator.validateEmail(signUp.getEmail())) {
            throw new CredentialsInvalidException("Invalid email format.");
        }

        if (signUp.getPassword() == null || signUp.getPassword().trim().isEmpty()) {
            if (signUp.getPassword() == null) {
                throw new CredentialsInvalidException("Password is required.");
            } else {
                throw new CredentialsInvalidException("Password cannot be empty.");
            }
        }

        PasswordValidator.validatePassword(signUp.getPassword());
    }
}
