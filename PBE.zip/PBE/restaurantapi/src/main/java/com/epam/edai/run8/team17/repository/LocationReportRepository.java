package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.model.LocationReport;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;

@Repository
@RequiredArgsConstructor
public class LocationReportRepository {

    private final DynamoDbTable<LocationReport> locationReportTable;


    public LocationReport getLocationReport(String date, String locationId) {
        Key key = Key.builder()
                .partitionValue(date)
                .sortValue(locationId)
                .build();

        return locationReportTable.getItem(item -> item.key(key));
    }

    public void save(LocationReport locationReport) {
        locationReportTable.putItem(locationReport);
    }

}
