package com.epam.edai.run8.team17.controller;

import com.epam.edai.run8.team17.dto.DishDTO;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.DishResponseDTO;
import com.epam.edai.run8.team17.service.DishService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class DishController {
    private final DishService dishService;


    //    here used Dish response DTO -> 6 fields requires
    @GetMapping("/dishes")
    public ResponseEntity<Map<String, List<DishResponseDTO>>> getDishes(@RequestParam(value = "dishType", required = false) String dishType,
                                                           @RequestParam(value = "sort", required = false) String sort) {
        return ResponseEntity.ok(Map.of("dishes", dishService.getListOfAllDishes(dishType, sort)));
    }

    //    here used Dish info DTO -> 4 fields required
    @GetMapping("/dishes/popular")
    public ResponseEntity<Map<String, List<DishInfoDTO>>> getAllPopularDishes() {
        return ResponseEntity.ok(Map.of("dishes", dishService.getListOfAllPopularDishes()));
    }

    // ✅ More generic mapping second
    @GetMapping("/dishes/{id}")
    public ResponseEntity<DishDTO> getDishById(@PathVariable("id") String id) {
        return ResponseEntity.ok(dishService.getDishById(id));
    }
}