package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.exception.DailyEventException;
import com.epam.edai.run8.team17.model.Booking;
import com.epam.edai.run8.team17.model.Employee;
import com.epam.edai.run8.team17.model.Feedback;
import com.epam.edai.run8.team17.model.WaiterReport;
import com.epam.edai.run8.team17.repository.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalTime;

@Service
@RequiredArgsConstructor
public class WaiterReportService {
    private static final Logger logger = LoggerFactory.getLogger(WaiterReportService.class);

    private final WaiterReportRepository waiterReportRepository;
    private final EmployeeRepository employeeRepository;
    private final WaiterRepository waiterRepository;
    
    public void processReportForWaiter(Booking booking, Feedback feedback, String waiterId) {
        logger.info("Processing Waiters and their reports...");

        WaiterReport waiterReport = waiterReportRepository.getWaiterReport(booking.getDate(), waiterId);
        logger.info("Waiter report: {}", waiterReport);

        logger.info("Fetching employee, if error might be in gsi");
        Employee employee = employeeRepository.getEmployeeWithId(waiterId);
        logger.info("Employee: {}", employee);

        if (waiterReport == null) {
            waiterReport = processIfWaiterReportNull(employee, booking, feedback);
        } else {
            processIfWaiterReportPresent(waiterReport, booking, feedback);
        }

        waiterReportRepository.save(waiterReport);
        logger.info("waiter report updated: {}", waiterReport);
    }

    private void processIfWaiterReportPresent(WaiterReport waiterReport, Booking booking, Feedback feedback)
    {
        logger.info("processing waiter report if report is already present...");
        String waiterId = booking.getWaiterId();
        String locationId = booking.getLocationId();

        int timeSlotIndex = waiterRepository.getTimeSlotIndex(waiterId, locationId, booking.getDate(), getTimeSlot(booking.getTimeFrom(), booking.getTimeTo()));
        logger.info("Time slot index: {}", timeSlotIndex);

        if (timeSlotIndex != -1) {
            waiterRepository.removeTimeSlotFromWaiter(waiterId, locationId, booking.getDate(), getTimeSlot(booking.getTimeFrom(), booking.getTimeTo()));
            logger.info("removing timeslot from waiter");

            float workingHours = waiterReport.getWorkingHours() + calculateHours(booking.getTimeFrom(), booking.getTimeTo());
            waiterReport.setWorkingHours(workingHours);
        }

        waiterReport.setOrderProcessed(waiterReport.getOrderProcessed() + 1);

        float avgFeedback = waiterReport.getAverageServiceFeedback();
        float minFeedback = waiterReport.getMinimumServiceFeedback();
        int feedbackCount = waiterReport.getFeedbackCount();
        float totalFeedback = avgFeedback * feedbackCount;

        if (feedback != null) {
            feedbackCount++;
            String serviceRating = feedback.getServiceRating();

            if (serviceRating != null && !serviceRating.isEmpty()) {
                try {
                    float serviceRatingFloat = Float.parseFloat(serviceRating);
                    minFeedback = Math.min(minFeedback, serviceRatingFloat);
                    avgFeedback = (totalFeedback + serviceRatingFloat) / feedbackCount;
                } catch (Exception e) {
                    throw new DailyEventException("Invalid service rating.");
                }
            }
        }

        waiterReport.setAverageServiceFeedback(roundOffTo2DecPlaces(avgFeedback));
        waiterReport.setMinimumServiceFeedback(roundOffTo2DecPlaces(minFeedback));
        waiterReport.setFeedbackCount(feedbackCount);

        logger.info(waiterReport.toString());
    }

    private WaiterReport processIfWaiterReportNull(
            Employee employee,
            Booking booking,
            Feedback feedback
    ) {
        logger.info("Waiter report does not exists for this waiter so creating one...");
        WaiterReport waiterReport = new WaiterReport();
        String waiterId = booking.getWaiterId();
        String locationId = booking.getLocationId();

        // set waiter's details
        waiterReport.setDate(booking.getDate());
        waiterReport.setEmail(employee.getEmail());
        waiterReport.setName(employee.getFirstName() + " " + employee.getLastName());
        waiterReport.setLocationId(locationId);
        waiterReport.setWaiterId(waiterId);

        // calculate working hours
        int timeSlotIndex = waiterRepository.getTimeSlotIndex(waiterId, locationId, booking.getDate(), getTimeSlot(booking.getTimeFrom(), booking.getTimeTo()));
        logger.info("time slot index: {}", timeSlotIndex);
        
        if (timeSlotIndex == -1) {
            throw new DailyEventException("This reservation is not assigned to waiter");
        }

        waiterRepository.removeTimeSlotFromWaiter(waiterId, locationId, booking.getDate(), getTimeSlot(booking.getTimeFrom(), booking.getTimeTo()));
        logger.info("removed time slot from waiter");

        float workingHours = calculateHours(booking.getTimeFrom(), booking.getTimeTo());
        logger.info("Working hours: {}", workingHours);
        waiterReport.setWorkingHours(workingHours);

        waiterReport.setOrderProcessed(1);

        float avgFeedback = 0.0f;
        float minFeedback = 0.0f;
        int feedbackCount = 0;

        if (feedback != null) {
            feedbackCount++;
            String serviceRating = feedback.getServiceRating();

            if (serviceRating != null && !serviceRating.isEmpty()) {
                try {
                    minFeedback = Float.parseFloat(serviceRating);
                    avgFeedback = minFeedback;
                } catch (Exception e) {
                    throw new DailyEventException("Invalid service rating");
                }
            }
        }

        waiterReport.setAverageServiceFeedback(roundOffTo2DecPlaces(avgFeedback));
        waiterReport.setMinimumServiceFeedback(roundOffTo2DecPlaces(minFeedback));
        waiterReport.setFeedbackCount(feedbackCount);

        return waiterReport;
    }

    private float calculateHours(String timeFrom, String timeTo) {
        LocalTime from = LocalTime.parse(timeFrom);
        LocalTime to = LocalTime.parse(timeTo);

        Duration duration = Duration.between(from, to);

        return duration.toMinutes() / 60.0f;
    }

    private String getTimeSlot(String timeFrom, String timeTo) {
        return timeFrom + "-" + timeTo;
    }

    private float roundOffTo2DecPlaces(float val) {
        String res = String.format("%.2f", val);
        return Float.parseFloat(res);
    }
}
