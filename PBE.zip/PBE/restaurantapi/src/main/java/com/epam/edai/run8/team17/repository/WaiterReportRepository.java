package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.model.WaiterReport;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;

@Repository
@RequiredArgsConstructor
public class WaiterReportRepository {

    private final DynamoDbTable<WaiterReport> waiterReportTable;

    public WaiterReport getWaiterReport(String date, String id) {
        Key key = Key.builder()
                .partitionValue(date)
                .sortValue(id)
                .build();

        return waiterReportTable.getItem(item -> item.key(key));
    }

    public void save(WaiterReport waiterReport) {
        waiterReportTable.putItem(waiterReport);
    }
}
