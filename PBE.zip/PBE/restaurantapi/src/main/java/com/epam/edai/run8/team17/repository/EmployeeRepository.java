package com.epam.edai.run8.team17.repository;


import com.epam.edai.run8.team17.model.Employee;
import com.epam.edai.run8.team17.model.Role;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;

import java.util.ArrayList;
import java.util.List;

@Repository
@RequiredArgsConstructor
@Slf4j
public class EmployeeRepository {

    private final DynamoDbTable<Employee> table;

    public String getRoleByEmail(String email){
        Key key = Key.builder()
                .partitionValue(email)
                .build();

        Employee employee = table.getItem(r -> r.key(key));
        return employee.getRole();
    }

    public boolean doesEmployeeExist(String email){
        Key key = Key.builder()
                .partitionValue(email)
                .build();

        Employee employee = table.getItem(r -> r.key(key));

        return employee != null;

    }

    public String getWaiterIdFromEmail(String email) {
        Key key = Key.builder().partitionValue(email).build();
        Employee employee = table.getItem(r -> r.key(key));
        return employee != null ? employee.getId() : null;
    }

    public String getName(String email) {
        Key key = Key.builder().partitionValue(email).build();
        Employee employee = table.getItem(r -> r.key(key));
        return employee != null ? employee.getFirstName() + " " + employee.getLastName() : null;
    }

    public String getNameFromId(String waiterId) {
        List<Employee> employees = new ArrayList<>();
        table.scan().items().forEach(employees::add);

        return employees.stream()
                .filter(emp -> "waiter".equalsIgnoreCase(emp.getRole()) && waiterId.equalsIgnoreCase(emp.getId()))
                .map(emp -> emp.getFirstName() + " " + emp.getLastName())
                .findFirst()
                .orElse(null);
    }

    public String getLocationIdFromEmail(String email) {
        List<Employee> employees = new ArrayList<>();
        table.scan().items().forEach(employees::add);

        return employees.stream()
                .filter(emp -> email.equalsIgnoreCase(emp.getEmail()))
                .map(Employee::getLocationId)
                .findFirst()
                .orElse(null);
    }

    public Employee getEmployeeWithId(String employeeId) {
        log.info("Searching for employee with ID: " + employeeId);

        DynamoDbIndex<Employee> employeeIdIndex = table.index("employee-id-index");

        Key key = Key.builder().partitionValue(employeeId).build();
        QueryConditional condition = QueryConditional.keyEqualTo(key);

        return employeeIdIndex.query(r -> r.queryConditional(condition))
                .stream()
                .flatMap(page -> page.items().stream())
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Employee not found for ID: " + employeeId));
    }

}