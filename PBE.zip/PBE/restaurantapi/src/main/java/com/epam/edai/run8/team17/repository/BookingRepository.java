package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.exception.NotFoundException;
import com.epam.edai.run8.team17.model.Booking;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import java.util.List;


@Repository
@RequiredArgsConstructor
public class BookingRepository {

    private final DynamoDbTable<Booking> table;

    public String getReservationLocationWithId(String reservationId) {
        Key key = Key.builder()
                .partitionValue(reservationId) // GSI Partition Key
                .build();

        return table.query(r -> r.queryConditional(QueryConditional.keyEqualTo(key))
                        .addAttributeToProject("locationId")) // Add projection for locationId
                .items()
                .stream()
                .findFirst()
                .map(Booking::getLocationId)
                .orElse(null);
    }

    public List<Booking> getBookingsByEmail(String userEmail) {
        Expression filterExpression = Expression.builder()
                .expression("#email = :userEmail")
                .putExpressionName("#email", "userEmail") // Map reserved keyword
                .putExpressionValue(":userEmail", AttributeValue.builder().s(userEmail).build())
                .build();

        return table.scan(r -> r.filterExpression(filterExpression))
                .items()
                .stream()
                .toList();
    }

    public void deleteUserBookingWithId(String reservationId, String email) {
        Key key = Key.builder()
                .partitionValue(reservationId)
                .sortValue(email) // Assuming email is the sort key
                .build();

        Booking booking = table.getItem(r -> r.key(key));
        booking.setStatus("CANCELLED");
        table.putItem(booking);
    }

    public Booking getBookingByIdAndEmail(String reservationId, String userEmail) {

        Key key = Key.builder()
                .partitionValue(reservationId)     // GSI Partition Key
                .sortValue(userEmail)     // GSI Sort Key
                .build();

        return table.getItem(r -> r.key(key));
    }

    public Booking createBooking(Booking booking) {
        saveBooking(booking);
        return booking;
    }

    public void saveBooking(Booking booking) {
        table.putItem(booking);
    }

    public List<Booking> getBookingsByIdAndDate(String waiterId, String date) {
        Expression filterExpression = Expression.builder()
                .expression("#w = :waiterId AND #d = :date")
                .putExpressionName("#w", "waiterId") // Map reserved keyword 'waiterId'
                .putExpressionName("#d", "date")    // Map reserved keyword 'date'
                .putExpressionValue(":waiterId", AttributeValue.builder().s(waiterId).build())
                .putExpressionValue(":date", AttributeValue.builder().s(date).build())
                .build();

        return table.scan(r -> r.filterExpression(filterExpression))
                .items()
                .stream()
                .toList();
    }

    public List<Booking> getAllBookings() {
        return table.scan().items().stream().toList();
    }

    public boolean doesBookingExist(String reservationId) {
        Key key = Key.builder()
                .partitionValue(reservationId) // Partition Key
                .build();

        // Query the table with a projection to only fetch the bookingId
        return table.query(r -> r.queryConditional(QueryConditional.keyEqualTo(key))
                        .addAttributeToProject("reservationId")) // Project only the bookingId
                .items()
                .stream()
                .findFirst()
                .isPresent();
    }

    public boolean doesBookingExistForUserWithEmailAndId(String reservationId, String email) {
        Key key = Key.builder()
                .partitionValue(reservationId)
                .sortValue(email) // Use sort key for efficient query
                .build();

        // Use getItem to directly fetch the item
        return table.getItem(r -> r.key(key)) != null;
    }

    public Booking getBookingById(String bookingId) {
        Key key = Key.builder()
                .partitionValue(bookingId) // Partition Key
                .build();


        return table.query(r -> r.queryConditional(QueryConditional.keyEqualTo(key))).items().stream().findFirst().orElse(null);

    }

    public Booking getBookingByFeedbackId(String id) {
        List<Booking> bookings = getAllBookings();
        return bookings.stream()
                .filter(booking -> booking.getFeedbackId().equals(id))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Booking not found with this feedbackId: " + id));
    }

}

