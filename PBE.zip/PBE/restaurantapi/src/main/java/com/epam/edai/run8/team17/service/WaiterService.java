package com.epam.edai.run8.team17.service;


import com.epam.edai.run8.team17.exception.NotFoundException;
import com.epam.edai.run8.team17.model.Waiter;
import com.epam.edai.run8.team17.repository.WaiterRepository;
import jakarta.validation.ValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class WaiterService {
    private final WaiterRepository waiterRepository;

    public String getLeastBusyWaiter(String locationId, String date, String timeFrom, String timeTo) {
        log.info("Finding least busy waiter for location: " + locationId);

        // Validate input parameters
        if (locationId == null || date == null || timeFrom == null || timeTo == null) {
            throw new IllegalArgumentException("All parameters are required");
        }

        // Fetch waiters by location
        List<Waiter> waiters = waiterRepository.getWaitersByLocation(locationId);
        log.info(waiters.toString());

        if (waiters.isEmpty()) {
            throw new ValidationException("No waiters available for the selected location");
        }

        // Filter eligible waiters who are available for the time slot
        List<Waiter> eligibleWaiters = waiters.stream()
                .filter(waiter -> isWaiterAvailable(waiter, date, timeFrom, timeTo))
                .toList();

        log.info("Eligible waiters: " + eligibleWaiters);

        if (eligibleWaiters.isEmpty()) {
            throw new ValidationException("No eligible waiters available for the selected time slot");
        }

        try {
            // Calculate scores and find the least busy waiter
            Map<String, Double> waiterScores = calculateWaiterScores(eligibleWaiters, date, timeFrom, timeTo);
            log.info("Waiter scores: " + waiterScores);

            return waiterScores.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .orElseThrow(() -> new ValidationException("No suitable waiter found"))
                    .getKey(); // Return the ID of the least busy waiter
        } catch (Exception e) {
            log.error("Error calculating waiter scores: " + e.getMessage());
            throw new ValidationException("Failed to find suitable waiter: " + e.getMessage());
        }
    }

    private Map<String, Double> calculateWaiterScores(List<Waiter> waiters, String date, String timeFrom, String timeTo) {
        Map<String, Double> scores = new HashMap<>();

        for (Waiter waiter : waiters) {
            Map<String, List<String>> bookedSlotss = waiter.getBooked();
            log.info("bookedslotsss: "+bookedSlotss);
            if(bookedSlotss == null){
                bookedSlotss = new HashMap<>();
            }
            List<String> bookedSlots = bookedSlotss.get(date);
            if(bookedSlots == null){
                bookedSlots = new ArrayList<>();
            }
            else bookedSlots = new ArrayList<>(bookedSlots);

            log.info("bookesslots: "+bookedSlots);
            try {
                double score = calculateClumsinessScore(bookedSlots, timeFrom, timeTo);
                scores.put(waiter.getId(), score);
                log.info("Score for Waiter " + waiter.getId() + ": " + score);
            } catch (Exception e) {
                e.printStackTrace();
                log.error("Error calculating score for Waiter " + waiter.getId() + ": " + e);
            }
        }

        log.info(scores.toString());

        return scores;
    }

    private boolean isWaiterAvailable(Waiter waiter, String date, String timeFrom, String timeTo) {
        String shiftStart = waiter.getShiftStart();
        String shiftEnd = waiter.getShiftEnd();

        log.info(shiftEnd + " " + shiftStart + " " + timeFrom + " " + timeTo);

        // Ensure the time slot falls within the waiter's shift
        boolean withinShift = timeFrom.compareTo(shiftStart) >= 0 && timeTo.compareTo(shiftEnd) <= 0;

        if (!withinShift) {
            log.info("Waiter not within shift hours: " + waiter.getId());
            return false;
        }

        // Check for bookings on the given date
        Map<String, List<String>> bookedMap = waiter.getBooked();
        List<String> bookedSlots = (bookedMap != null && bookedMap.containsKey(date)) ? bookedMap.get(date) : new ArrayList<>();

        for (String slot : bookedSlots) {
            String[] parts = slot.split("-");
            String bookedFrom = parts[0];
            String bookedTo = parts[1];

            if (timeFrom.compareTo(bookedTo) < 0 && timeTo.compareTo(bookedFrom) > 0) {
                log.info("Waiter already booked: " + waiter.getId());
                return false;
            }
        }

        return true; // Waiter is available
    }

    public void updateTimeSlotForWaiterWithIdAndLocationId(String waiterId, String locationId, String date, String timeslot) {
        log.info("Updating time slot for waiter: " + waiterId);

        if (waiterId == null || locationId == null || date == null || timeslot == null) {
            throw new IllegalArgumentException("All parameters are required");
        }

        if (!doesWaiterExistWithIdAndLocationId(waiterId, locationId)) {
            throw new NotFoundException("Waiter not found");
        }

        try {
            waiterRepository.updateTimeSlotForWaiterWithId(waiterId, locationId, date, timeslot);
            log.info("Successfully updated time slot for waiter: " + waiterId);
        } catch (Exception e) {
            log.error("Failed to update waiter time slot: " + e.getMessage());
            throw new ValidationException("Failed to update waiter schedule: " + e.getMessage());
        }
    }

    public void removeTimeSlot(String waiterId, String locationId, String date, String timeSlot) {
        waiterRepository.removeTimeSlotFromWaiter(waiterId, locationId, date, timeSlot);
    }

    public boolean doesWaiterExistWithIdAndLocationId(String waiterId, String locationId) {
        return waiterRepository.doesWaiterExistWithIdAndLocationId(waiterId, locationId);
    }

    private double calculateClumsinessScore(List<String> bookedTimeSlots, String timeFrom, String timeTo) {
        if (bookedTimeSlots == null || bookedTimeSlots.isEmpty()) {
            log.info("Booked Time Slots are empty or null, returning high availability.");
            return Double.MAX_VALUE; // No bookings: High availability
        }

        bookedTimeSlots.sort(Comparator.naturalOrder());

        // Find the last booking before the requested time slot
        String lastBooking = bookedTimeSlots.stream()
                .filter(slot -> slot.split("-")[1].compareTo(timeFrom) <= 0)
                .reduce((first, second) -> second)
                .orElse(null);

        // Find the next booking after the requested time slot
        String nextBooking = bookedTimeSlots.stream()
                .filter(slot -> slot.split("-")[0].compareTo(timeTo) >= 0)
                .findFirst()
                .orElse(null);

        // Compute time gaps
        double gapBefore = (lastBooking != null)
                ? calculateTimeDifference(lastBooking.split("-")[1], timeFrom)
                : Double.MAX_VALUE;
        double gapAfter = (nextBooking != null)
                ? calculateTimeDifference(timeTo, nextBooking.split("-")[0])
                : Double.MAX_VALUE;

        return gapBefore + gapAfter;
    }

    private double calculateTimeDifference(String time1, String time2) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime t1 = LocalTime.parse(time1, formatter);
        LocalTime t2 = LocalTime.parse(time2, formatter);

        return Duration.between(t1, t2).toMinutes();
    }
}