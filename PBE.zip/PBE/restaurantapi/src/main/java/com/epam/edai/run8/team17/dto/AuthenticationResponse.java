package com.epam.edai.run8.team17.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class AuthenticationResponse {

    private String idToken;
    private String role;
    private String accessToken;
    private String refreshToken;
    private String username;
    private String email;
}
