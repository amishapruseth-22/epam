package com.epam.edai.run8.team17.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Entity;
import lombok.Builder;
import lombok.Data;

@Data
@Entity
@Builder
public class DishSmallDTO {
    private String id;
    private String name;
    private String imageUrl;
    private String price;
    private String weight;
    private String state;
    private String dishType;
    private Boolean isPopular;
    private String popularityScore;

}
