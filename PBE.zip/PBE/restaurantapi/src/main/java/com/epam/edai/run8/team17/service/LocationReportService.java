package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.exception.DailyEventException;
import com.epam.edai.run8.team17.model.Booking;
import com.epam.edai.run8.team17.model.Feedback;
import com.epam.edai.run8.team17.model.LocationReport;
import com.epam.edai.run8.team17.repository.LocationReportRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LocationReportService {
    private static final Logger logger = LoggerFactory.getLogger(LocationReportService.class);
    private final LocationReportRepository locationReportRepository;
    
    public void processReportForLocation(Booking booking, Feedback feedback, String locationId) {

        logger.info("Processing Location and their reports...");

        LocationReport locationReport = locationReportRepository.getLocationReport(booking.getDate(), locationId);
        logger.info("Location Report: {}", locationReport);

        if (locationReport == null) {
            locationReport = processIfLocationReportIsNull(booking, feedback, locationId);
        } else {
            processIfLocationReportIsPresent(feedback, locationReport);
        }

        locationReportRepository.save(locationReport);
        logger.info("location report updated: {}", locationReport);
    }

    private void processIfLocationReportIsPresent(Feedback feedback, LocationReport locationReport) {
        logger.info("processing location report if report is already present...");

        locationReport.setOrderProcessed(locationReport.getOrderProcessed() + 1);

        float avgCuisineFeedback = locationReport.getAverageCuisineFeedback();
        float minCuisineFeedback = locationReport.getMinimumCuisineFeedback();
        int feedbackCount = locationReport.getFeedbackCount();

        float totalFeedback = avgCuisineFeedback * feedbackCount;

        if (feedback != null) {
            feedbackCount++;
            String cuisineRating = feedback.getCuisineRating();

            if (cuisineRating != null && !cuisineRating.isEmpty()) {
                try {
                    float rating = Float.parseFloat(cuisineRating);
                    minCuisineFeedback = Math.min(minCuisineFeedback, rating);
                    avgCuisineFeedback = (totalFeedback + rating) / feedbackCount;
                } catch (Exception e) {
                    throw new DailyEventException("Invalid cuisine rating");
                }
            }
        }

        locationReport.setAverageCuisineFeedback(roundOffTo2DecPlaces(avgCuisineFeedback));
        locationReport.setMinimumCuisineFeedback(roundOffTo2DecPlaces(minCuisineFeedback));
        locationReport.setFeedbackCount(feedbackCount);

        // Todo -> process revenue
        locationReport.setRevenue(locationReport.getRevenue() + 10);
    }

    private LocationReport processIfLocationReportIsNull(Booking booking, Feedback feedback, String locationId) {

        logger.info("Location report does not exists for this Location so creating one...");
        LocationReport locationReport = new LocationReport();

        locationReport.setLocationId(locationId);
        locationReport.setDate(booking.getDate());
        locationReport.setOrderProcessed(1);

        float avgCuisineFeedback = 0.0f;
        float minCuisineFeedback = 0.0f;
        int feedbackCount = 0;

        if (feedback != null) {
            feedbackCount++;
            String cuisineRating = feedback.getCuisineRating();

            if (cuisineRating != null && !cuisineRating.isEmpty()) {
                try {
                    minCuisineFeedback = Float.parseFloat(cuisineRating);
                    avgCuisineFeedback = minCuisineFeedback;
                } catch (Exception e) {
                    throw new RuntimeException("Invalid cuisine rating");
                }
            }
        }

        locationReport.setAverageCuisineFeedback(roundOffTo2DecPlaces(avgCuisineFeedback));
        locationReport.setMinimumCuisineFeedback(roundOffTo2DecPlaces(minCuisineFeedback));
        locationReport.setFeedbackCount(feedbackCount);

        // Todo -> process revenue
        locationReport.setRevenue(10);
        return locationReport;
    }

    private float roundOffTo2DecPlaces(float val) {
        String res = String.format("%.2f", val);
        return Float.parseFloat(res);
    }
}
