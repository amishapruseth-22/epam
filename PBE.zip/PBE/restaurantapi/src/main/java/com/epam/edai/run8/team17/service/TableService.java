package com.epam.edai.run8.team17.service;
import com.amazonaws.services.kms.model.ConflictException;
import com.amazonaws.services.kms.model.NotFoundException;
import com.epam.edai.run8.team17.dto.TableAvailableDTO;
import com.epam.edai.run8.team17.exception.ForbiddenException;
import com.epam.edai.run8.team17.model.Location;
import com.epam.edai.run8.team17.model.Table;
import com.epam.edai.run8.team17.model.TimeSlot;
import com.epam.edai.run8.team17.repository.TableRepository;
import com.epam.edai.run8.team17.repository.TimeSlotRepository;
import com.epam.edai.run8.team17.utils.TableFilter;
import jakarta.validation.ValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class TableService {


    private final LocationService locationService;
    private final TableRepository tableRepository;
    private final TimeSlotRepository timeSlotRepository;


    /**
     * Fetch available tables based on location, date, time slot, and number of guests.
     */
    public List<TableAvailableDTO> getAvailableTables(String locationId, String date, TimeSlot timeSlot, int guests) {
        log.info("[getAvailableTables] Location ID: " + locationId + ", Date: " + date + ", TimeSlot: " + timeSlot + ", Guests: " + guests);

        // Fetch tables for the specified location
        List<Table> allTables = fetchTablesByLocation(locationId);
        if (allTables == null || allTables.isEmpty()) {
            log.info("list is null");
            return null;
        }

        // Fetch the location image URL
        String imageUrl = fetchImageUrlByLocation(locationId);

        // Create DTOs for available tables
        return feedData(allTables, date, imageUrl);
    }

    private String fetchImageUrlByLocation(String locationId) {
        Location location = locationService.getLocationById(locationId);
        return location.getImage();
    }

    /**
     * Fetches all tables associated with a given location ID.
     *
     * @param locationId The ID of the location.
     * @return A list of tables associated with the location ID.
     */
    private List<Table> fetchTablesByLocation(String locationId) {


        // Check if the location exists using locationService
        if (locationService.doesLocationExist(locationId)) {
            log.info("loaction does not exist at "+locationId);
            throw new NotFoundException("Location not found for ID: " + locationId);
        }

        log.info("table exist");
        // Use the tableRepository to fetch all tables
        return tableRepository.getTablesByLocationId(locationId);


    }

    private List<TableAvailableDTO> feedData(List<Table> tables, String date, String imageUrl) {
        List<TableAvailableDTO> availableDTOS = new ArrayList<>();

        // Iterate over tables and populate DTOs with available slots
        for (Table table : tables) {
            TableAvailableDTO availableDTO = new TableAvailableDTO();
            availableDTO.setLocationId(table.getLocationId());
            availableDTO.setCapacity(Integer.parseInt(table.getCapacity()));
            availableDTO.setTableNumber(table.getId());
            availableDTO.setLocationAddress(locationService.getLocationAddressByLocationId(table.getLocationId()));

            List<String> availableTimeSlots = TableFilter.getAvailableTimeSlot(table.getBooked().get(date), date);
            availableDTO.setAvailableSlots(availableTimeSlots);
            availableDTO.setImageUrl(imageUrl);

            availableDTOS.add(availableDTO);
        }

        return availableDTOS;
    }

    private boolean isTimeSlotAvailable(List<String> existingSlots, String timeFrom, String timeTo) {
        for (String slot : existingSlots) {
            String[] times = slot.split("-");
            if (timeFrom.compareTo(times[1]) < 0 && timeTo.compareTo(times[0]) > 0) {
                return false; // Time slot conflicts
            }
        }
        return true;
    }

    public void updateTimeSlotForTableWithIdAndLocationId(String tableId, String locationId, String date, String timeslot) {
        try {
            // Check for time slot conflicts before updating
            if (!isTimeSlotAvailable(
                    tableRepository.getBookedTimeSlots(tableId, locationId).getOrDefault(date, List.of()),
                    timeslot.split("-")[0],
                    timeslot.split("-")[1]
            )) {
                throw new ConflictException("Table already booked for the given time slot.");
            }

            tableRepository.updateTimeSlotForTable(tableId, locationId, date, timeslot);

        } catch (Exception e) {
            throw new ConflictException("Unable to update time slot: " + e.getMessage());
        }
    }

    public boolean doesTableExist(String tableId, String locationId) {
        return tableRepository.doesTableExist(tableId, locationId);
    }

    public Optional<Table> getTableDataById(String tableId, String locationId) {
        Optional<Table> data = tableRepository.getTableByIdAndLocationId(tableId, locationId);
        if (data.isEmpty()) {
            throw new NotFoundException("[getTableDataById] Table not found for ID: " + tableId);
        }
        return data;
    }

    public boolean isTableAvailableForBooking(String tableId, String locationId, String date, String timeFrom, String timeTo) {
        try {
            if (!doesTableExistsWithIdAndLocationId(tableId, locationId)) {
                return false;
            }

            Map<String, List<String>> bookedTimeSlots = tableRepository.getBookedTimeSlots(tableId,locationId);
            if (bookedTimeSlots.isEmpty() || !bookedTimeSlots.containsKey(date)) {
                return true; // No bookings on this date
            }

            return isTimeSlotAvailable(
                    bookedTimeSlots.get(date),
                    timeFrom,
                    timeTo
            );
        } catch (Exception e) {
            throw new ValidationException("Availability check failed: " + e.getMessage());
        }
    }

    public boolean doesTableExistsWithIdAndLocationId(String tableId, String locationId) {
        return tableRepository.doesTableExist(tableId, locationId);
    }

    public void verifyTableCanAccommodateGuestsWithIdAndLocationId(String tableId, String locationId, String guests) {
        String tableCapacity = getNumberOfGuestsForTableWithIdAndLocationId(tableId, locationId);

        try {
            int guestCount = Integer.parseInt(guests);
            int capacity = Integer.parseInt(tableCapacity);

            if (guestCount > capacity) {
                throw new ValidationException("Table cannot accommodate " + guests + " guests. Maximum capacity is " + tableCapacity);
            }

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number format for guests or table capacity.");
        }
    }

    private String getNumberOfGuestsForTableWithIdAndLocationId(String tableId, String locationId) {
        String numberOfGuests = tableRepository.getNumberOfGuestsForTable(tableId, locationId);
        if (numberOfGuests == null) {
            throw new ForbiddenException("The table does not contain a capacity attribute.");
        }
        return numberOfGuests;
    }

    public void removeTimeSlotFromTable(String tableId, String locationId, String date, String timeSlot) {
        try {
            // Fetch the Table object for the given tableId and locationId
            Optional<Table> optionalTable = getTableDataById(tableId, locationId);
            if (optionalTable.isEmpty()) {
                return;
            }

            Table table = optionalTable.get();
            if (table.getBooked() == null || !table.getBooked().containsKey(date)) {
                log.info("No bookings found for table '%s' on date '%s'.%n", tableId, date);
                return;
            }

            // Fetch the list of time slots for the given date
            List<String> timeSlots = table.getBooked().get(date);

            // Remove the specific time slot
            if (!timeSlots.remove(timeSlot)) {
                log.info("Time slot '%s' does not exist for table '%s' on date '%s'.%n", timeSlot, tableId, date);
                return;
            }

            // If time slots are empty after removal, remove the entire date entry
            if (timeSlots.isEmpty()) {
                table.getBooked().remove(date);
            }

            // Save the updated table back to the database using the repository
            tableRepository.removeTimeSlotFromTable(tableId, locationId, date, timeSlot);
            log.info("Time slot '%s' successfully removed for table '%s' on date '%s'.%n", timeSlot, tableId, date);
        } catch (Exception e) {
            log.error("Error while removing a time slot: " + e.getMessage());
            throw new ValidationException("Failed to update table schedule", e);
        }
    }


    public TimeSlot parseTimeSlot(String startTime) {
        return timeSlotRepository.getTimeSlot(startTime);
    }
}