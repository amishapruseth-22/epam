package com.epam.edai.run8.team17.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
@Data
public class WaiterReservationDto {
    private String locationName;
    private String tableNumber;
    private String date;
    private String time;
    private String bookingDoneBy;
    private String guests;
    private String reservationId;
    private String status;
    private String waiter_id;
}
