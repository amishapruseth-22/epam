package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.dto.FeedbackUpdate;
import com.epam.edai.run8.team17.exception.FeedbackEventsException;
import com.epam.edai.run8.team17.model.Booking;
import com.epam.edai.run8.team17.model.Feedback;
import com.epam.edai.run8.team17.model.LocationReport;
import com.epam.edai.run8.team17.model.WaiterReport;
import com.epam.edai.run8.team17.repository.BookingRepository;
import com.epam.edai.run8.team17.repository.LocationReportRepository;
import com.epam.edai.run8.team17.repository.WaiterReportRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class FeedbackEventService {


    private final ObjectMapper objectMapper;
    private final BookingRepository bookingRepository;
    private final WaiterReportRepository waiterReportRepository;
    private final LocationReportRepository locationReportRepository;
    
    private static final Logger logger = LoggerFactory.getLogger(FeedbackEventService.class);
    
    public void newFeedbackEventProcessing(String body) {
        try {

            Feedback newFeedback = objectMapper.readValue(body, Feedback.class);

            if (newFeedback == null) {
                throw new FeedbackEventsException("New feedback is null");
            }

            Booking booking = bookingRepository.getBookingByFeedbackId(newFeedback.getId());
            logger.info("Booking: {}",booking);

            WaiterReport waiterReport = waiterReportRepository.getWaiterReport(booking.getDate(), booking.getWaiterId());
            logger.info("waiter report: {}", waiterReport);

            if (waiterReport == null) return;

            float avgFeedback = waiterReport.getAverageServiceFeedback();
            float minFeedback = waiterReport.getMinimumServiceFeedback() == 0 ? 10f: waiterReport.getMinimumServiceFeedback();
            int feedbackCount = waiterReport.getFeedbackCount();
            float totalFeedback = avgFeedback * feedbackCount;

            feedbackCount++;
            String serviceRating = newFeedback.getServiceRating();

            if (serviceRating != null && !serviceRating.isEmpty()) {
                try {
                    float serviceRatingFloat = Float.parseFloat(serviceRating);

                    minFeedback = Math.min(minFeedback, serviceRatingFloat);
                    avgFeedback = (totalFeedback + serviceRatingFloat) / feedbackCount;
                } catch (Exception e) {
                    throw new FeedbackEventsException("Invalid service rating.", e);
                }
            }

            waiterReport.setAverageServiceFeedback(roundOffTo2DecPlaces(avgFeedback));
            waiterReport.setMinimumServiceFeedback(roundOffTo2DecPlaces(minFeedback));
            waiterReport.setFeedbackCount(feedbackCount);
            logger.info(waiterReport.toString());


            LocationReport locationReport = locationReportRepository.getLocationReport(booking.getDate(), booking.getLocationId());

            if (locationReport == null) return;
            logger.info(locationReport.toString());

            float avgCuisineFeedback = locationReport.getAverageCuisineFeedback();
            float minCuisineFeedback = locationReport.getMinimumCuisineFeedback() == 0 ? 10f : locationReport.getMinimumCuisineFeedback();
            int feedbackCountLocation = locationReport.getFeedbackCount();
            float totalFeedbackLocation = avgCuisineFeedback * feedbackCount;

            feedbackCountLocation++;
            String cuisineRating = newFeedback.getCuisineRating();

            if (cuisineRating != null && !cuisineRating.isEmpty()) {
                try {
                    float rating = Float.parseFloat(cuisineRating);
                    minCuisineFeedback = Math.min(minCuisineFeedback, rating);
                    avgCuisineFeedback = (totalFeedbackLocation + rating) / feedbackCountLocation;
                } catch (Exception e) {
                    throw new FeedbackEventsException("Invalid cuisine rating", e);
                }
            }

            locationReport.setAverageCuisineFeedback(roundOffTo2DecPlaces(avgCuisineFeedback));
            locationReport.setMinimumCuisineFeedback(roundOffTo2DecPlaces(minCuisineFeedback));
            locationReport.setFeedbackCount(feedbackCountLocation);

            waiterReportRepository.save(waiterReport);
            locationReportRepository.save(locationReport);

        } catch (Exception e) {
            logger.error("Error in processing new feedback creation event");
            throw new FeedbackEventsException(e);
        }

    }

    public void feedbackUpdateEventProcessing(String body) {
        
        try {
            FeedbackUpdate feedbackUpdate = objectMapper.readValue(body, FeedbackUpdate.class);

            if (feedbackUpdate == null) {
                throw new FeedbackEventsException("Feedback update dto is null");
            }

            Feedback prevFeedback = feedbackUpdate.getPreviousFeedback();
            Feedback newFeedback = feedbackUpdate.getFeedback();
            
            if (prevFeedback == null) {
                throw new FeedbackEventsException("Previous feedback is null");
            }
            logger.info("prev feedback: {}", prevFeedback);

            if (newFeedback == null) {
                throw new FeedbackEventsException("new feedback is null");
            }

            logger.info("new feedback: {}", newFeedback);

            Booking booking = bookingRepository.getBookingByFeedbackId(prevFeedback.getId());
            logger.info("Booking with the feedback Id {}: {}", prevFeedback.getId(), booking);

            WaiterReport waiterReport = waiterReportRepository.getWaiterReport(booking.getDate(), booking.getWaiterId());
            logger.info("Water Report: {}", waiterReport);
            
            if (waiterReport == null) return;

            LocationReport locationReport = locationReportRepository.getLocationReport(booking.getDate(), booking.getLocationId());
            logger.info("Location Report: {}", locationReport);
            
            if (locationReport == null) return;

            float avgFeedback = waiterReport.getAverageServiceFeedback();
            float minFeedback = waiterReport.getMinimumServiceFeedback();
            int feedbackCount = waiterReport.getFeedbackCount();
            float totalFeedback = avgFeedback * feedbackCount;


            if (feedbackCount == 0) {
                throw new FeedbackEventsException("feedback count is 0, error might be when feedback is created it is not updated");
            }

            logger.info("waiter initial calc: {} {} {} {}", avgFeedback, minFeedback, feedbackCount, totalFeedback);
            
            String prevServiceRating = prevFeedback.getServiceRating();
            if (prevServiceRating != null && !prevServiceRating.isEmpty()) {
                try {
                    float prevServiceRatingFloat = Float.parseFloat(prevServiceRating);
                    totalFeedback -= prevServiceRatingFloat;

                    // If the minimum feedback was this one, we need to recalculate the minimum
                    if (Math.abs(minFeedback - prevServiceRatingFloat) < 0.001) {
                        minFeedback = Float.MAX_VALUE;
                    }

                } catch (Exception e) {
                    logger.error("Invalid previous service rating.");
                    throw new FeedbackEventsException(e);
                }
            }

            logger.info("waiter calc: {} {} {} {}", avgFeedback, minFeedback, feedbackCount, totalFeedback);

            String newServiceRating = newFeedback.getServiceRating();
            if (newServiceRating != null && !newServiceRating.isEmpty()) {
                try {
                    float newServiceRatingFloat = Float.parseFloat(newServiceRating);
                    totalFeedback += newServiceRatingFloat;
                    minFeedback = Math.min(minFeedback, newServiceRatingFloat);
                    avgFeedback = totalFeedback / feedbackCount;
                } catch (Exception e) {
                    logger.error("Invalid new service rating.");
                    throw new FeedbackEventsException(e);
                }
            }

            logger.info("waiter calc: {} {} {} {}", avgFeedback, minFeedback, feedbackCount, totalFeedback);

            waiterReport.setAverageServiceFeedback(roundOffTo2DecPlaces(avgFeedback));
            waiterReport.setMinimumServiceFeedback(roundOffTo2DecPlaces(minFeedback));

            float avgCuisineFeedback = locationReport.getAverageCuisineFeedback();
            float minCuisineFeedback = locationReport.getMinimumCuisineFeedback();
            int feedbackCountLocation = locationReport.getFeedbackCount();
            float totalCuisineFeedback = avgCuisineFeedback * feedbackCountLocation;
            logger.info("location calc: {} {} {} {}", avgFeedback, minFeedback, feedbackCount, totalFeedback);

            String prevCuisineRating = prevFeedback.getCuisineRating();
            if (prevCuisineRating != null && !prevCuisineRating.isEmpty()) {
                try {
                    float prevCuisineRatingFloat = Float.parseFloat(prevCuisineRating);
                    totalCuisineFeedback -= prevCuisineRatingFloat;

                    // If the minimum feedback was this one, we need to recalculate the minimum
                    if (Math.abs(minCuisineFeedback - prevCuisineRatingFloat) < 0.001) {
                        minCuisineFeedback = Float.MAX_VALUE;
                    }
                } catch (Exception e) {
                    logger.error("Invalid previous cuisine rating.");
                    throw new FeedbackEventsException(e);
                }
            }
            logger.info("location initial calc: {} {} {} {}", avgFeedback, minFeedback, feedbackCount, totalFeedback);

            // Now add the new feedback
            String newCuisineRating = newFeedback.getCuisineRating();
            if (newCuisineRating != null && !newCuisineRating.isEmpty()) {
                try {
                    float newCuisineRatingFloat = Float.parseFloat(newCuisineRating);
                    totalCuisineFeedback += newCuisineRatingFloat;
                    minCuisineFeedback = Math.min(minCuisineFeedback, newCuisineRatingFloat);
                    avgCuisineFeedback = totalCuisineFeedback / feedbackCountLocation;
                } catch (Exception e) {
                    logger.error("Invalid new cuisine rating.");
                    throw new FeedbackEventsException(e);
                }
            }

            logger.info("location calc: {} {} {} {}", avgFeedback, minFeedback, feedbackCount, totalFeedback);

            locationReport.setAverageCuisineFeedback(roundOffTo2DecPlaces(avgCuisineFeedback));
            locationReport.setMinimumCuisineFeedback(roundOffTo2DecPlaces(minCuisineFeedback));

            logger.info("Waiter Report after updating: {}", waiterReport);
            logger.info("Location Report after updating: {}", locationReport);

            waiterReportRepository.save(waiterReport);
            locationReportRepository.save(locationReport);
        } catch (Exception e) {
            logger.error("Error in processing feedback update event.");
            throw new FeedbackEventsException(e);
        }
    }
    private float roundOffTo2DecPlaces(float val) {
        String res = String.format("%.2f", val);
        return Float.parseFloat(res);
    }
}
