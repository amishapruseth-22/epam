package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.model.Location;
import lombok.RequiredArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;

@Repository
@RequiredArgsConstructor
public class LocationRepository {

    private final DynamoDbTable<Location> locationTable;

    public Optional<Location> getLocationDataById(String locationId) {
        return Optional.ofNullable(locationTable.getItem(r -> r.key(k -> k.partitionValue(locationId))));
    }

    public Location getLocationById(String locationId) {
        Key key = Key.builder()
                .partitionValue(locationId)
                .build();
        return locationTable.getItem(r -> r.key(key));
    }
    public String getLocationAddress(String locationId) {
        return getLocationDataById(locationId)
                .map(Location::getAddress)
                .orElse(null);
    }


    public void saveLocation(Location location) {
        locationTable.putItem(location);
    }

    public void deleteLocation(String locationId) {
        locationTable.deleteItem(r -> r.key(k -> k.partitionValue(locationId)));
    }

    public List<Location> getAllLocationsList() {
        List<Location> locations = new ArrayList<>();
        locationTable.scan().items().forEach(locations::add);

        return locations;
    }

    public String getLocationAddressById(String locationId) {

        Location locationData = getLocationById(locationId);
        if (locationData != null && locationData.getAddress()!= null && !locationData.getAddress().isEmpty()) {
            return locationData.getAddress();
        }
        return null;
    }


    public boolean doesLocationExistsWithId(String locationId){
        return getLocationDataById(locationId) != null;
    }

}