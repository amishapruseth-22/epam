package com.epam.edai.run8.team17.controller;

import com.epam.edai.run8.team17.dto.FeedbackCreationDto;
import com.epam.edai.run8.team17.dto.FeedbackModificationDto;
import com.epam.edai.run8.team17.model.Feedback;
import com.epam.edai.run8.team17.service.FeedbackService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/feedbacks")
@RequiredArgsConstructor
public class FeedbackController {
    private final Logger logger = LoggerFactory.getLogger(FeedbackController.class);

    private final FeedbackService feedbackService;

    @PostMapping
    public ResponseEntity<?> createFeedback(@RequestBody FeedbackCreationDto feedbackCreationDto) {
        logger.info("POST /feedbacks");
        return  feedbackService.createFeedback(feedbackCreationDto);
    }

    @PutMapping
    public ResponseEntity<?> updateFeedback(@RequestBody FeedbackModificationDto feedbackModificationDto) {
        logger.info("PUT /feedbacks");
        return feedbackService.updateFeedback(feedbackModificationDto);
    }
}