package com.epam.edai.run8.team17.repository;

import com.epam.edai.run8.team17.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;

import java.util.ArrayList;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class UserRepository {

    private final DynamoDbTable<User> userTable;

    public String getByName(String userEmail) {
        List<User> users = new ArrayList<>();
        userTable.scan().items().forEach(users::add);

        User user = users.stream()
                .filter(user1 -> user1.getEmail().equalsIgnoreCase(userEmail))
                .findFirst()
                .orElse(null);

        assert user != null;
        return user.getFirstName() + " " + user.getLastName();
    }

    public User findByEmail(String email){
        Key key = Key.builder()
                .partitionValue(email)
                .build();
        return userTable.getItem(r -> r.key(key));
    }

    public void saveUser(User user){
        userTable.putItem(user);
    }

}