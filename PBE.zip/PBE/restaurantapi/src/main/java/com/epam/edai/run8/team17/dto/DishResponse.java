package com.epam.edai.run8.team17.dto;

import lombok.Data;

@Data
public class DishResponse {
    private String name;
    private String price;
    private String weight;
    private String imageUrl;
}