package com.epam.edai.run8.team17.config;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponse<T> {
    private int statusCode;
    private T data;
    private String message;

    public static ApiResponse<Void> error(int statusCode, String message) {
        return new ApiResponse<>(statusCode, null, message);
    }
}

