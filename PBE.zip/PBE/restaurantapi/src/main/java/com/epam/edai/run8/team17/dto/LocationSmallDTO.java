package com.epam.edai.run8.team17.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class LocationSmallDTO {

    private String id;
    private String address;
}
