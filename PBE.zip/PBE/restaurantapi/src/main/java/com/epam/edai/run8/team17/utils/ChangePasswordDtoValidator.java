package com.epam.edai.run8.team17.utils;

import com.epam.edai.run8.team17.dto.ChangePassword;
import com.epam.edai.run8.team17.exception.CredentialsInvalidException;

public class ChangePasswordDtoValidator {

    public static void validate(ChangePassword changePassword) {

        if (changePassword.getOldPassword() == null) {
            throw new CredentialsInvalidException("Old Password is required");
        }

        if (changePassword.getOldPassword().isEmpty()) {
            throw new CredentialsInvalidException("Old Password cannot be empty");
        }

        if (changePassword.getNewPassword() == null) {
            throw new CredentialsInvalidException("New Password is required");
        }

        if (changePassword.getNewPassword().isEmpty()) {
            throw new CredentialsInvalidException("New Password cannot be empty");
        }

        if (changePassword.getOldPassword().equals(changePassword.getNewPassword())) {
            throw new CredentialsInvalidException("Old password and new password cannot be same.");
        }

        PasswordValidator.validatePassword(changePassword.getNewPassword());
    }
}
