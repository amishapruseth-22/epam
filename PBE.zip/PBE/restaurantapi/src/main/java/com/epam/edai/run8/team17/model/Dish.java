package com.epam.edai.run8.team17.model;

import lombok.*;


import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
@Setter
@Builder
public class Dish {
    private String id;
    private String name;
    private String price;
    private String weight;
    private String image;
    private String state;
    private String calories;
    private String carbs;
    private String description;
    private String dishType;
    private String fats;
    private String proteins;
    private String vitamins;
    private boolean isSpecial;
    private String feedbackId;
    private boolean isAvailable;
    private boolean isPopular;
    private String popularityScore;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("dish_id")
    public String getId() {
        return id;
    }

    @DynamoDbAttribute("name")
    public String getName() {
        return name;
    }

    @DynamoDbAttribute("price")
    public String getPrice() {
        return price;
    }

    @DynamoDbAttribute("weight")
    public String getWeight() {
        return weight;
    }

    @DynamoDbAttribute("image")
    public String getImage() {
        return image;
    }

    @DynamoDbAttribute("state")
    public String getState() {
        return state;
    }

    @DynamoDbAttribute("calories")
    public String getCalories() {
        return calories;
    }

    @DynamoDbAttribute("carbs")
    public String getCarbs() {
        return carbs;
    }

    @DynamoDbAttribute("description")
    public String getDescription() {
        return description;
    }

    @DynamoDbAttribute("dishType")
    public String getDishType() {
        return dishType;
    }

    @DynamoDbAttribute("fats")
    public String getFats() {
        return fats;
    }

    @DynamoDbAttribute("proteins")
    public String getProteins() {
        return proteins;
    }

    @DynamoDbAttribute("vitamins")
    public String getVitamins() {
        return vitamins;
    }

    @DynamoDbAttribute("isSpecial")
    public boolean isSpecial() {
        return isSpecial;
    }

    @DynamoDbAttribute("feedback_id")
    public String getFeedbackId() {
        return feedbackId;
    }

    @DynamoDbAttribute("isAvailable")
    public boolean isAvailable() {
        return isAvailable;
    }

    @DynamoDbAttribute("isPopular")
    public boolean isPopular() {
        return isPopular;
    }

    @DynamoDbAttribute("popularityScore")
    public String getPopularityScore() {
        return popularityScore;
    }

    public void setIsPopular(boolean b) {
        this.isPopular = b ;
    }
}