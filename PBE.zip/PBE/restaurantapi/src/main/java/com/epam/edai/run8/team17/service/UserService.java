package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.model.User;
import com.epam.edai.run8.team17.repository.UserRepository;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public String getNameByEmail(String userEmail) {
        try {
            return userRepository.getByName(userEmail);
        }catch (Exception e){
            log.error("Error in Fetching the name from Email: {}",userEmail);
            throw e;
        }
    }

}