package com.epam.edai.run8.team17.exception;

public class ReportsException extends RuntimeException{
    public ReportsException(String message) {
        super(message);
    }

    public ReportsException(Throwable cause) {
        super(cause);
    }

    public ReportsException(String message, Throwable cause) {
        super(message, cause);
    }
}
