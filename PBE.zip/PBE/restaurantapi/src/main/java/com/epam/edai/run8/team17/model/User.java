package com.epam.edai.run8.team17.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Data
@DynamoDbBean
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class User {

    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String imageUrl;
    @Enumerated(EnumType.STRING)
    private Role role;

    @DynamoDbPartitionKey
    public String getEmail() {
        return email;
    }
}