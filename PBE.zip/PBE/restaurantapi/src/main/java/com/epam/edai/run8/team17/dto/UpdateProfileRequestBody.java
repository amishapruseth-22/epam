package com.epam.edai.run8.team17.dto;

import lombok.Data;

@Data
public class UpdateProfileRequestBody {
    private String base64encodedImage;
    private String firstName;
    private String lastName;
}