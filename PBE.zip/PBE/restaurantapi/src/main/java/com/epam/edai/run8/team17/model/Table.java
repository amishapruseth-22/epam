package com.epam.edai.run8.team17.model;

import lombok.*;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class Table {
    private String id;
    private String locationId;
    private String capacity;

    // Change TimeSlot to a String key (e.g., "10:30-12:00")
    private Map<String, List<String>> booked;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("table_id")
    public String getId() {
        return id;
    }

    @DynamoDbSortKey
    @DynamoDbAttribute("location_id")
    public String getLocationId() {
        return locationId;

    }
}
