package com.epam.edai.run8.team17.service;

import com.epam.edai.run8.team17.exception.ReportsException;
import com.epam.edai.run8.team17.model.Booking;
import com.epam.edai.run8.team17.model.Feedback;
import com.epam.edai.run8.team17.model.LocationReport;
import com.epam.edai.run8.team17.model.WaiterReport;
import com.epam.edai.run8.team17.repository.BookingRepository;
import com.epam.edai.run8.team17.repository.FeedbackRepository;
import com.epam.edai.run8.team17.repository.LocationReportRepository;
import com.epam.edai.run8.team17.repository.WaiterReportRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsClient;

@Service
@RequiredArgsConstructor
public class ReportsGenerationService {

    private final WaiterReportService waiterReportService;
    private final LocationReportService locationReportService;
    private final ObjectMapper objectMapper;
    private final FeedbackRepository feedbackRepository;
    private final FeedbackEventService feedbackEventService;

    private static final Logger logger = LoggerFactory.getLogger(ReportsGenerationService.class);

    public void dailyEventProcessing(String payload) {
        try {
            logger.info("Processing daily event...");

            Booking booking = objectMapper.readValue(payload, Booking.class);

            if (booking == null) {
                throw new ReportsException("Booking is null");
            }

            logger.info("Booking:{}", booking);

            String waiterId = booking.getWaiterId();
            String locationId = booking.getLocationId();
            String feedbackId = booking.getFeedbackId();
            logger.info("waiterId: {}", waiterId);
            logger.info("locationId: {}", locationId);
            logger.info("feedbackId: {}", feedbackId);

            logger.info("Fetching feedback ...");
            Feedback feedback = null;
            if (!feedbackId.equalsIgnoreCase("no_feedback")) {
                feedback = feedbackRepository.getFeedbackById(feedbackId);
                logger.info("Feedback: {}", feedback);
            }

            waiterReportService.processReportForWaiter(booking, feedback, waiterId);
            locationReportService.processReportForLocation(booking, feedback, locationId);

        } catch (Exception e) {
            logger.error("Error processing daily event");
            throw new ReportsException(e);
        }
    }

    public void feedbackEventProcessing(String payload) {
        try {
            logger.info("Processing feedback event: {}", payload);
            feedbackEventService.feedbackUpdateEventProcessing(payload);
        } catch (Exception e) {
            logger.error("Error processing feedback event");
            throw new ReportsException(e);
        }
    }

    public void newFeedbackEventProcessing(String payload) {
        try {
            logger.info("Processing new feedback event: {}", payload);
            feedbackEventService.newFeedbackEventProcessing(payload);
        } catch (Exception e) {
            logger.error("Error processing new feedback event");
            throw new ReportsException(e);
        }
    }

    
}
