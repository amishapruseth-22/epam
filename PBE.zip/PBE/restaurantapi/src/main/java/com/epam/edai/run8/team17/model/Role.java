package com.epam.edai.run8.team17.model;

public enum Role {
    ADMIN,
    WAITER,
    CUSTOMER
}
