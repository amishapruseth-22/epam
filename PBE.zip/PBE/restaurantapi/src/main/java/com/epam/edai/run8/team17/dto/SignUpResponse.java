package com.epam.edai.run8.team17.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class SignUpResponse {

    private String idToken;
    private String message;
}

