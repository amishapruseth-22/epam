package com.epam.edai.run8.team17.controller;

import com.amazonaws.services.kms.model.NotFoundException;
import com.epam.edai.run8.team17.dto.DishInfoDTO;
import com.epam.edai.run8.team17.dto.LocationSmallDTO;
import com.epam.edai.run8.team17.dto.FeedbackDTO;
import com.epam.edai.run8.team17.dto.PaginatedResponse;
import com.epam.edai.run8.team17.model.Location;
import com.epam.edai.run8.team17.service.FeedbackService;
import com.epam.edai.run8.team17.service.LocationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/locations")
@RequiredArgsConstructor
public class LocationController {

    private final LocationService locationService;
    private final FeedbackService feedbackService;

    @GetMapping
    public ResponseEntity<Map<String, List<Location>>> getAllAvailableLocations() {
        List<Location> locationSmallDTOS = locationService.getAllLocationsList();

        if (locationSmallDTOS.isEmpty()) {
            throw new NotFoundException("No locations available at the moment.");
        }

        return ResponseEntity.ok(Map.of("locations", locationSmallDTOS));
    }

    @GetMapping("/{id}/speciality-dishes")
    public ResponseEntity<Map<String, DishInfoDTO>> getSpecialityDishes(@PathVariable("id") String id) {
        DishInfoDTO dishInfo = locationService.getSpecialityDishesByLocationId(id);

        if (dishInfo == null) {
            throw new NotFoundException(String.format("No speciality dishes found for location ID: %s", id));
        }

        return ResponseEntity.ok(Map.of("specialityDishes", dishInfo));
    }

    @GetMapping("/select-options")
    public ResponseEntity<Map<String, List<LocationSmallDTO>>> getLocationsForSelectOptions() {
        List<LocationSmallDTO> locations = locationService.getAllLocations();

        if (locations.isEmpty()) {
            throw new NotFoundException("No locations available to display as select options.");
        }

        return ResponseEntity.ok(Map.of("locations", locations));
    }

    @GetMapping("/{id}/feedbacks")
    public ResponseEntity<PaginatedResponse<FeedbackDTO>> getFeedbacksForLocation(
            @PathVariable("id") String locationId,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "10") int limit,
            @RequestParam(value = "type", required = false) String type,
            @RequestParam(value = "sortBy", defaultValue = "asc") String sortBy
    ) {
        if (locationService.doesLocationExist(locationId)) {
            throw new NotFoundException("Invalid Location");
        }

        PaginatedResponse<FeedbackDTO> feedbackPage =
                feedbackService.getFeedbackByLocationWithPagination(locationId, limit, page, type, sortBy);

        return ResponseEntity.ok(feedbackPage);
    }
}