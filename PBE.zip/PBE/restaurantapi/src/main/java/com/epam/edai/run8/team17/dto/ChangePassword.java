package com.epam.edai.run8.team17.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ChangePassword {

    private String newPassword;
    private String oldPassword;
}

