package com.epam.edai.run8.team17.exception;

public class SqsEventException extends RuntimeException{

    public SqsEventException(String message) {
        super(message);
    }

    public SqsEventException(Throwable cause) {
        super(cause);
    }

    public SqsEventException(String message, Throwable cause) {
        super(message, cause);
    }
}
