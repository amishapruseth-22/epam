package com.epam.edai.run8.team17.dto;

import lombok.Data;

@Data
public class FeedbackCreationDto {
    private String cuisineComment;
    private String serviceComment;
    private String serviceRating;
    private String cuisineRating;
    private String reservationId;
}
